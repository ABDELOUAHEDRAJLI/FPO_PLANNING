-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 20 mars 2024 à 16:33
-- Version du serveur :  8.0.21
-- Version de PHP : 7.2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET FOREIGN_KEY_CHECKS=0;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;



-- --------------------------------------------------------

--
-- Structure de la table `absences_etudiants`
--

CREATE TABLE `absences_etudiants` (
  `codeAbsence` int NOT NULL,
  `codeRessource` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL,
  `codeJustification` int NOT NULL,
  `typeAbsence` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `absences_justifications`
--

CREATE TABLE `absences_justifications` (
  `codeJustification` int NOT NULL,
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `libelle` varchar(250) NOT NULL DEFAULT '',
  `typeJustification` smallint NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `absences_justifications`
--

INSERT INTO `absences_justifications` (`codeJustification`, `codeProprietaire`, `deleted`, `dateModif`, `libelle`, `typeJustification`, `dateCreation`) VALUES
(2, 0, 0, '2017-03-23 11:02:42', 'CONGE DE MALADIE', 1, '2017-01-01 00:00:01'),
(3, 0, 0, '2017-03-23 11:02:45', 'CONGE DE LONGUE MALADIE OU DE LONGUE DUREE', 1, '2017-01-01 00:00:01'),
(4, 0, 0, '2017-03-23 11:02:46', 'CONGE DE MATERNITE OU D ADOPTION', 1, '2017-01-01 00:00:01'),
(5, 0, 0, '2017-03-23 11:02:46', 'CONGE DE PATERNITE', 1, '2017-01-01 00:00:01'),
(6, 0, 0, '2017-03-23 11:02:47', 'CONGE DE FORMATION PROFESSIONNELLE', 1, '2017-01-01 00:00:01'),
(7, 0, 0, '2017-03-23 11:02:47', 'CONGE POUR VALIDATION DES ACQUIS D EXPERIENCE', 1, '2017-01-01 00:00:01'),
(8, 0, 0, '2017-03-23 11:02:47', 'CONGE POUR BILAN DE COMPETENCES', 1, '2017-01-01 00:00:01'),
(9, 0, 0, '2017-03-23 11:02:48', 'CONGE POUR FORMATION SYNDICALE', 1, '2017-01-01 00:00:01'),
(10, 0, 0, '2017-03-23 11:02:48', 'CONGE POUR CHSCT', 1, '2017-01-01 00:00:01'),
(12, 0, 0, '2017-03-23 11:02:49', 'CONGE POUR PERIODE MILITAIRE', 1, '2017-01-01 00:00:01'),
(13, 0, 0, '2017-03-23 11:02:50', 'CONGE POUR DECES OU DE MALADIE TRES GRAVE DU CONJOINT, D UN ASCENDANT OU D UN DESCENDANT', 2, '2017-01-01 00:00:01'),
(14, 0, 0, '2017-03-23 11:02:55', 'CONGE DE SOLIDARITE FAMILIALE', 2, '2017-01-01 00:00:01'),
(16, 0, 0, '2017-03-23 11:02:54', 'CONGE POUR SOIGNER UN ENFANT MALADE', 2, '2017-01-01 00:00:01'),
(17, 0, 0, '2017-03-23 11:02:54', 'CONGE POUR EVENEMENT FAMILIAL EN CAS DE MARIAGE OU DE PACS', 2, '2017-01-01 00:00:01'),
(18, 0, 0, '2017-03-23 11:02:53', 'CONGE POUR EVENEMENT FAMILIAL EN CAS DE COHABITATION AVEC UNE PERSONNE ATTEINTE DE MALADIE CONTAGIEUSE', 2, '2017-01-01 00:00:01'),
(19, 0, 0, '2017-03-23 11:02:53', 'CONGE POUR EXAMENS MEDICAUX OBLIGATOIRES', 2, '2017-01-01 00:00:01'),
(20, 0, 0, '2017-03-23 11:02:53', 'CONGE POUR PREPARER UN EXAMEN OU UN CONCOURS', 2, '2017-01-01 00:00:01'),
(21, 0, 0, '2017-03-23 11:02:52', 'CONGE POUR PARTICIPER A UN JURY DE COUR D ASSISES', 2, '2017-01-01 00:00:01'),
(22, 0, 0, '2017-03-23 11:02:52', 'CONGE EN QUALITE DE CANDIDAT A UNE FONCTION PUBLIQUE ELECTIVE', 2, '2017-01-01 00:00:01'),
(24, 0, 0, '2017-03-23 11:03:05', 'CONGE POUR MOTIF SYNDICAL', 2, '2017-01-01 00:00:01'),
(25, 0, 0, '2017-03-23 11:03:05', 'CONGE POUR PARTICIPER A UN JURY D EXAMEN OU DE CONCOURS', 2, '2017-01-01 00:00:01'),
(26, 0, 0, '2017-03-23 11:03:06', 'CONGE POUR PARTICIPER AUX ORGANISMES CONSULTATIFS', 2, '2017-01-01 00:00:01'),
(27, 0, 0, '2017-03-23 11:03:06', 'CONGE POUR EFFECTUER UN DEPLACEMENT HORS DE FRANCE', 2, '2017-01-01 00:00:01'),
(28, 0, 0, '2017-03-23 11:03:07', 'CONGE POUR FETES RELIGIEUSE', 2, '2017-01-01 00:00:01'),
(29, 0, 0, '2017-03-23 11:03:08', 'CONGE EN QUALITE DE SAPEUR POMPIER VOLONTAIRE', 2, '2017-01-01 00:00:01'),
(30, 0, 0, '2017-03-23 11:03:08', 'AUTRE', 3, '2017-01-01 00:00:01'),
(31, 0, 0, '2017-03-23 11:03:08', 'CERTIFICAT MEDICAL', 3, '2017-01-01 00:00:01'),
(32, 0, 0, '2017-03-23 11:03:08', 'CONVOCATION ADMINISTRATIVE', 3, '2017-01-01 00:00:01'),
(33, 0, 0, '2017-03-23 11:03:08', 'CONVOCATION CONCOURS', 3, '2017-01-01 00:00:01'),
(34, 0, 0, '2017-03-23 11:03:08', 'CONVOCATION PERMIS', 3, '2017-01-01 00:00:01'),
(35, 0, 0, '2017-03-23 11:03:08', 'DECES FAMILIAL', 3, '2017-01-01 00:00:01'),
(36, 0, 0, '2017-03-23 11:03:08', 'ENTERTIEN STAGE', 3, '2017-01-01 00:00:01'),
(37, 0, 0, '2017-03-23 11:03:08', 'FETE RELIGIEUSE', 3, '2017-01-01 00:00:01'),
(38, 0, 0, '2017-03-23 11:03:08', 'JAPD', 3, '2017-01-01 00:00:01'),
(39, 0, 0, '2017-03-23 11:03:08', 'TRANSPORT', 3, '2017-01-01 00:00:01');

-- --------------------------------------------------------

--
-- Structure de la table `absences_periodes_etudiants`
--

CREATE TABLE `absences_periodes_etudiants` (
  `codeAbsence` int NOT NULL,
  `codeRessource` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `absences_periodes_profs`
--

CREATE TABLE `absences_periodes_profs` (
  `codeAbsence` int NOT NULL,
  `codeRessource` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `absences_profs`
--

CREATE TABLE `absences_profs` (
  `codeAbsence` int NOT NULL,
  `codeRessource` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL,
  `codeJustification` int NOT NULL,
  `typeAbsence` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `absences_validations`
--

CREATE TABLE `absences_validations` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeProf` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `codeValidation` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `bilans_profs_archives`
--

CREATE TABLE `bilans_profs_archives` (
  `numeroBilan` int NOT NULL,
  `archive` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `commentaire` varchar(255) NOT NULL,
  `avecSeances` tinyint(1) NOT NULL DEFAULT '0',
  `avecForfaits` tinyint(1) NOT NULL DEFAULT '0',
  `avecSyntheses` tinyint(1) NOT NULL DEFAULT '0',
  `methodeDeCalcul` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `bilans_profs_forfaits`
--

CREATE TABLE `bilans_profs_forfaits` (
  `codeEnseignement` int NOT NULL,
  `nomEnseignement` varchar(150) NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dureeForfaitaire` int NOT NULL,
  `codeProf` int NOT NULL,
  `public` varchar(5) NOT NULL,
  `dureeStatutaire` int NOT NULL,
  `dureeComplementaire` int NOT NULL,
  `numeroBilan` int NOT NULL,
  `archive` tinyint(1) NOT NULL,
  `nbEtudiants` int NOT NULL,
  `typeActivite` varchar(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `nomComposante` varchar(150) NOT NULL,
  `nomProf` varchar(150) NOT NULL,
  `nomDiplome` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `bilans_profs_previsionnels`
--

CREATE TABLE `bilans_profs_previsionnels` (
  `codeEnseignement` int NOT NULL,
  `dureeForfaitaire` int NOT NULL,
  `public` varchar(5) NOT NULL,
  `dureePrevisionnelle` int NOT NULL,
  `nbEtudiants` int NOT NULL,
  `typeActivite` varchar(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `libelleComposante` varchar(150) NOT NULL,
  `libelleProf` varchar(150) NOT NULL,
  `libelleDiplome` varchar(150) NOT NULL,
  `libelleMatiere` varchar(150) NOT NULL,
  `numeroBilan` int NOT NULL,
  `codeProf` int NOT NULL,
  `codeProprietaire` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `bilans_profs_seances`
--

CREATE TABLE `bilans_profs_seances` (
  `codeSeance` int NOT NULL,
  `dateSeance` date NOT NULL,
  `heureSeance` int NOT NULL,
  `dureeSeance` int NOT NULL,
  `numeroBilan` int NOT NULL,
  `archive` tinyint(1) NOT NULL,
  `nomMatiere` varchar(150) NOT NULL,
  `typeActivite` varchar(5) NOT NULL,
  `nbEtudiants` int NOT NULL,
  `codeMatiere` int NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dureeStatutaire` int NOT NULL,
  `dureeComplementaire` int NOT NULL,
  `public` varchar(5) NOT NULL,
  `codeProf` int NOT NULL,
  `nomComposante` varchar(150) NOT NULL,
  `nomProf` varchar(150) NOT NULL,
  `nomDiplome` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `bilans_profs_syntheses`
--

CREATE TABLE `bilans_profs_syntheses` (
  `dureeStatutaire` int DEFAULT NULL,
  `dureeComplementaire` int DEFAULT NULL,
  `dureeForfaitaire` int DEFAULT NULL,
  `dureeNonRemuneree` int DEFAULT NULL,
  `numeroBilan` int NOT NULL,
  `archive` tinyint(1) NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProf` int NOT NULL,
  `nomProf` varchar(150) NOT NULL,
  `codeGrade` int DEFAULT NULL,
  `commentaire` varchar(255) NOT NULL,
  `nomComposante` varchar(150) DEFAULT NULL,
  `dateServiceRealise` date DEFAULT NULL,
  `methodeCalcul` varchar(150) NOT NULL,
  `dureeTotale` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_commentaires`
--

CREATE TABLE `calendriers_commentaires` (
  `codeRessource` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date` date NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_enseignements`
--

CREATE TABLE `calendriers_enseignements` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_filieres`
--

CREATE TABLE `calendriers_filieres` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_groupes`
--

CREATE TABLE `calendriers_groupes` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_materiels`
--

CREATE TABLE `calendriers_materiels` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_profs`
--

CREATE TABLE `calendriers_profs` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `calendriers_salles`
--

CREATE TABLE `calendriers_salles` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `cnu`
--

CREATE TABLE `cnu` (
  `codeCNU` int NOT NULL,
  `section` int NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'CNU?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `identifiant` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `cnu`
--

INSERT INTO `cnu` (`codeCNU`, `section`, `nom`, `dateModif`, `dateCreation`, `deleted`, `codeProprietaire`, `commentaire`, `couleurFond`, `couleurPolice`, `alias`, `identifiant`) VALUES
(0, 0, 'AUCUNE', '2017-07-07 08:41:58', '2000-01-01 00:00:00', 0, 0, '', 0, 0, '', ''),
(188, 1, 'DROIT PRIVE ET SCIENCES CRIMINELLES', '2011-01-31 16:25:04', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(189, 2, 'DROIT PUBLIC', '2011-01-31 16:25:04', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(190, 3, 'HISTOIRE DU DROIT ET DES INSTITUTIONS', '2011-01-31 16:25:04', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(191, 4, 'SCIENCE POLITIQUE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(192, 5, 'SCIENCES ECONOMIQUES', '2011-01-31 16:28:48', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(193, 6, 'SCIENCES DE GESTION', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(194, 7, 'SCIENCES DU LANGAGE  : LINGUISTIQUE ET PHONETIQUE GENERALES', '2011-01-31 16:31:31', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(195, 8, 'LANGUES ET LITTERATURES ANCIENNES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(196, 9, 'LANGUE ET LITTERATURE FRANCAISES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(197, 10, 'LITTERATURES COMPAREES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(198, 11, 'LANGUES ET LITTERATURES ANGLAISES ET ANGLO-SAXONNES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(199, 12, 'LANGUES ET LITTERATURES GERMANIQUES ET SCANDINAVES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(200, 13, 'LANGUES ET LITTERATURES SLAVES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(201, 14, 'LANGUES ET LITTERATURES ROMANES  ESPAGNOL ITALIEN PORTUGAIS AUTRES LANGUES ROMANES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(202, 15, 'LANGUES ET LITTÉRATURES ARABES CHINOISES JAPONAISES HÉBRAIQUE D\'AUTRES DOMAINES LINGUISTIQUES', '2011-01-31 16:33:04', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(203, 16, 'PSYCHOLOGIE PSYCHOLOGIE CLINIQUE PSYCHOLOGIE SOCIALE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(204, 17, 'PHILOSOPHIE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(205, 18, 'ARCHITECTURE  ARTS APPLIQUÉS ARTS PLASTIQUES ARTS DU SPECTACLE ÉPISTÉMOLOGIE DES ENSEIGNEMENTS ARTISTIQUES ESTHÉTIQUE MUSICOLOGIE MUSIQUE SCIENCES DE ', '2011-01-31 16:33:50', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(206, 19, 'SOCIOLOGIE DEMOGRAPHIE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(207, 20, 'ANTHROPOLOGIE ETHNOLOGIE PREHISTOIRE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(208, 21, 'HISTOIRE ET CIVILISATIONS  HISTOIRE ET ARCHOLOGIE DES MONDES ANCIENS ET DES MONDES MEDIEVAUX', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(209, 22, 'HISTOIRE ET CIVILISATIONS  HISTOIRE DES MONDES MODERNES HISTOIRE DU MONDE CONTEMPORAIN', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(210, 23, 'GEOGRAPHIE PHYSIQUE HUMAINE ECONOMIQUE ET REGIONALE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(211, 24, 'AMENAGEMENT DE LESPACE URBANISME', '2011-01-31 16:25:42', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(212, 25, 'MATHEMATIQUES', '2011-01-31 16:25:42', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(213, 26, 'MATHEMATIQUES APPLIQUEES ET APPLICATIONS DES MATHMATIQUES', '2011-01-31 16:25:42', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(214, 27, 'INFORMATIQUE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(215, 28, 'MILIEUX DENSES ET MATRIAUX', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(216, 29, 'CONSTITUANTS ELEMENTAIRES', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(217, 30, 'MILIEUX DILUES ET OPTIQUE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(218, 31, 'CHIMIE THEORIQUE PHYSIQUE ANALYTIQUE', '2011-01-31 16:27:33', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(219, 32, 'CHIMIE ORGANIQUE MINERALE INDUSTRIELLE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(220, 33, 'CHIMIE DES MATRIAUX', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(221, 34, 'ASTRONOMIE ASTROPHYSIQUE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(222, 35, 'STRUCTURE ET EVOLUTION DE LA TERRE ET DES AUTRES PLANTES', '2011-01-31 16:27:33', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(223, 36, 'TERRE SOLIDE  GEODYNAMIQUE DES ENVELOPPES SUPRIEURES PALEOBIOSPHERE', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(224, 37, 'METEOROLOGIE OCANOGRAPHIE PHYSIQUE ET PHYSIQUE DE L ENVIRONNEMENT', '2011-01-31 16:35:38', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(225, 39, 'SCIENCES PHYSICO-CHIMIQUES ET TECHNOLOGIES PHARMACEUTIQUES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(226, 40, 'SCIENCES DU MEDICAMENT', '2011-01-31 16:28:33', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(227, 41, 'SCIENCES BIOLOGIQUES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(228, 60, 'MECANIQUE GENIE MECANIQUE GENIE CIVIL', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(229, 61, 'GENIE INFORMATIQUE AUTOMATIQUE ET TRAITEMENT DU SIGNAL', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(230, 62, 'ENERGTIQUE GENIE DES PROCEDES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(231, 63, 'GÉNIE ÉLECTRIQUE ÉLECTRONIQUE PHOTONIQUE ET SYSTÈMES', '2011-01-31 16:36:59', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(232, 64, 'BIOCHIMIE ET BIOLOGIE MOLECULAIRE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(233, 65, 'BIOLOGIE CELLULAIRE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(234, 66, 'PHYSIOLOGIE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(235, 67, 'BIOLOGIE DES POPULATIONS ET ECOLOGIE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(236, 68, 'BIOLOGIE DES ORGANISMES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(237, 69, 'NEUROSCIENCES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(238, 70, 'SCIENCES DE L EDUCATION', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(239, 71, 'SCIENCES DE L INFORMATION ET DE LA COMMUNICATION', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(240, 72, 'EPISTEMOLOGIE HISTOIRE DES SCIENCES ET DES TECHNIQUES', '2011-01-31 16:28:33', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(241, 73, 'CULTURES ET LANGES REGIONALES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(242, 74, 'SCIENCES ET TECHNIQUES DES ACTIVITES PHYSIQUES ET SPORTIVES', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', ''),
(243, 75, 'THEOLOGIE CATHOLIQUE', '2011-01-31 16:23:58', '2010-05-22 06:23:43', 0, 0, '', 0, 0, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `composantes`
--

CREATE TABLE `composantes` (
  `codeComposante` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'MATERIEL?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `typeComposante` tinyint NOT NULL DEFAULT '2',
  `volMaxFI` int NOT NULL DEFAULT '0',
  `volMaxFC` int NOT NULL DEFAULT '0',
  `volMaxFA` int NOT NULL DEFAULT '0',
  `volMaxAUTRE` int NOT NULL DEFAULT '0',
  `reference` int NOT NULL DEFAULT '0',
  `referencePonderee` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `composantes`
--

INSERT INTO `composantes` (`codeComposante`, `couleurFond`, `couleurPolice`, `nom`, `dateModif`, `dateCreation`, `deleted`, `codeProprietaire`, `alias`, `commentaire`, `identifiant`, `typeComposante`, `volMaxFI`, `volMaxFC`, `volMaxFA`, `volMaxAUTRE`, `reference`, `referencePonderee`) VALUES
(1, 16777088, 0, 'COMPOSANTE', '2017-07-16 08:29:48', '2010-07-07 17:10:47', 0, 0, 'COMPOSANTE', '', 'COMPOSANTE', 2, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `composantes_directeurs`
--

CREATE TABLE `composantes_directeurs` (
  `codeComposante` int NOT NULL DEFAULT '0',
  `codeDirecteur` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `compteur`
--

CREATE TABLE `compteur` (
  `id_compteur` int UNSIGNED NOT NULL,
  `valeur` bigint UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Statistiques du nombre de visiteurs';

--
-- Déchargement des données de la table `compteur`
--

INSERT INTO `compteur` (`id_compteur`, `valeur`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `diplomes`
--

CREATE TABLE `diplomes` (
  `codeDiplome` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int NOT NULL DEFAULT '0',
  `codeNiveau` int NOT NULL DEFAULT '0',
  `codeResponsable` int NOT NULL DEFAULT '0',
  `typePublic` tinyint(1) NOT NULL DEFAULT '1',
  `public` tinyint(1) NOT NULL DEFAULT '1',
  `codeSuper` int DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `reference` int NOT NULL DEFAULT '0',
  `referencePonderee` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `disciplines`
--

CREATE TABLE `disciplines` (
  `codeDiscipline` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `disciplines_profs`
--

CREATE TABLE `disciplines_profs` (
  `codeDiscipline` int NOT NULL,
  `codeProf` int NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements`
--

CREATE TABLE `enseignements` (
  `codeEnseignement` int NOT NULL,
  `nom` varchar(150) NOT NULL DEFAULT 'ENS?',
  `codeMatiere` int NOT NULL DEFAULT '0',
  `dureeTotale` int NOT NULL DEFAULT '2000',
  `dureeSeance` int NOT NULL DEFAULT '100',
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `alias` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'ENS?',
  `codeTypeSalle` int NOT NULL DEFAULT '0',
  `codeZoneSalle` int NOT NULL DEFAULT '0',
  `nbSeancesHebdo` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `forfaitaire` tinyint(1) NOT NULL DEFAULT '0',
  `dureeForfaitaire` int NOT NULL DEFAULT '0',
  `typePublic` tinyint NOT NULL DEFAULT '0',
  `volumeReparti` int NOT NULL DEFAULT '0',
  `codeTypeActivite` int NOT NULL DEFAULT '2',
  `codeComposante` int NOT NULL DEFAULT '-1',
  `codeNiveau` int NOT NULL,
  `dateDebut` date NOT NULL DEFAULT '2014-01-01',
  `dateFin` date NOT NULL DEFAULT '2030-01-01',
  `codeTypeMateriel` int NOT NULL DEFAULT '0',
  `dureeAjoutee` int NOT NULL DEFAULT '0',
  `codeDiplome` int NOT NULL DEFAULT '0',
  `operateurTypesSalles` tinyint(1) NOT NULL DEFAULT '0',
  `operateurTypesMateriels` tinyint(1) NOT NULL DEFAULT '0',
  `asynchrone` tinyint(1) NOT NULL DEFAULT '0',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1',
  `diffusionCommentaire` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_groupes`
--

CREATE TABLE `enseignements_groupes` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_historique`
--

CREATE TABLE `enseignements_historique` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'ENS?',
  `codeMatiere` int NOT NULL DEFAULT '0',
  `dureeTotale` int NOT NULL DEFAULT '0',
  `dureeSeance` int NOT NULL DEFAULT '0',
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT 'ENS?',
  `codeTypeSalle` int NOT NULL DEFAULT '0',
  `codeZoneSalle` int NOT NULL DEFAULT '0',
  `nbSeancesHebdo` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) DEFAULT NULL,
  `codeProprietaireModifieur` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_materiels`
--

CREATE TABLE `enseignements_materiels` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_prerequis`
--

CREATE TABLE `enseignements_prerequis` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codePrerequis` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `typePrerequis` tinyint NOT NULL DEFAULT '1',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_profs`
--

CREATE TABLE `enseignements_profs` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_salles`
--

CREATE TABLE `enseignements_salles` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_types_materiels`
--

CREATE TABLE `enseignements_types_materiels` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeTypeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enseignements_types_salles`
--

CREATE TABLE `enseignements_types_salles` (
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `codeTypeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `etudiants_diplomes`
--

CREATE TABLE `etudiants_diplomes` (
  `codeEtudiant` int NOT NULL,
  `codeDiplome` int NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `filieres`
--

CREATE TABLE `filieres` (
  `codeFiliere` int NOT NULL,
  `nom` varchar(150) NOT NULL DEFAULT 'FILIERE?',
  `derniereConsultation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `heureDebut` int NOT NULL DEFAULT '0',
  `heureFin` int NOT NULL DEFAULT '0',
  `finesseTemps` int NOT NULL DEFAULT '0',
  `tailleFont` bigint NOT NULL DEFAULT '8',
  `font` varchar(50) NOT NULL DEFAULT 'ARIAL',
  `dateDebut` date NOT NULL DEFAULT '2015-01-01',
  `dateFin` date NOT NULL DEFAULT '2015-01-01',
  `hauteurCellule` bigint NOT NULL DEFAULT '10',
  `largeurCellule` bigint NOT NULL DEFAULT '15',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `nomType1` varchar(10) NOT NULL DEFAULT 'CR',
  `nomType2` varchar(10) NOT NULL DEFAULT 'TD',
  `nomType3` varchar(10) NOT NULL DEFAULT 'TP',
  `nomType4` varchar(10) NOT NULL DEFAULT 'PRO',
  `nomType5` varchar(10) NOT NULL DEFAULT 'SEMI',
  `nomType6` varchar(10) NOT NULL DEFAULT 'STAGE',
  `nomType7` varchar(10) NOT NULL DEFAULT 'ADMIN',
  `nomType8` varchar(10) NOT NULL DEFAULT 'JURY',
  `nomType9` varchar(10) NOT NULL DEFAULT 'DS',
  `nomType10` varchar(10) NOT NULL DEFAULT 'APP',
  `nomType11` varchar(10) NOT NULL DEFAULT 'APP1',
  `nomType12` varchar(10) NOT NULL DEFAULT 'APP2',
  `nomType13` varchar(10) NOT NULL DEFAULT 'FC',
  `nomType14` varchar(10) NOT NULL DEFAULT 'FC1',
  `nomType15` varchar(10) NOT NULL DEFAULT 'FC2',
  `nbJoursPourCalculAbsences` int NOT NULL DEFAULT '10',
  `nbSemainesEnseignementAnnuel` int NOT NULL DEFAULT '32',
  `nbJoursEnseignementHebdo` int NOT NULL DEFAULT '5',
  `dureeQuotidienneLegale` int NOT NULL DEFAULT '420',
  `dureeAnnuelleLegale` int NOT NULL DEFAULT '96420',
  `normalisation` tinyint(1) NOT NULL DEFAULT '1',
  `heureDebutPauseMidi` int NOT NULL DEFAULT '720',
  `heureFinPauseMidi` int NOT NULL DEFAULT '840',
  `dureePauseMidi` int NOT NULL DEFAULT '30',
  `dureeMaxTravail` int NOT NULL DEFAULT '360',
  `dureeMinPause` int NOT NULL DEFAULT '30',
  `HostNameDocument` varchar(100) NOT NULL DEFAULT '',
  `PortDocument` int NOT NULL DEFAULT '21',
  `UsernameDocument` varchar(100) NOT NULL DEFAULT '',
  `PasswordDocument` varchar(100) NOT NULL DEFAULT '',
  `RepertoireDocument` varchar(200) NOT NULL DEFAULT '',
  `httpDocument` varchar(200) NOT NULL DEFAULT '',
  `modeDocument` tinyint(1) NOT NULL DEFAULT '1',
  `HostNameEDT` varchar(100) NOT NULL DEFAULT '',
  `PortEDT` int NOT NULL DEFAULT '21',
  `UsernameEDT` varchar(100) NOT NULL DEFAULT '',
  `PasswordEDT` varchar(100) NOT NULL DEFAULT '',
  `RepertoireEDT` varchar(200) NOT NULL DEFAULT '',
  `httpEDT` varchar(200) NOT NULL DEFAULT '',
  `modeEDT` tinyint(1) NOT NULL DEFAULT '1',
  `organisation` tinyint(1) NOT NULL DEFAULT '0',
  `organisationDateDebut1` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin1` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut2` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin2` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut3` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin3` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut4` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin4` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `sequenceEchap` varchar(5) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `filieres`
--

INSERT INTO `filieres` (`codeFiliere`, `nom`, `derniereConsultation`, `heureDebut`, `heureFin`, `finesseTemps`, `tailleFont`, `font`, `dateDebut`, `dateFin`, `hauteurCellule`, `largeurCellule`, `dateModif`, `deleted`, `codeProprietaire`, `dateCreation`, `nomType1`, `nomType2`, `nomType3`, `nomType4`, `nomType5`, `nomType6`, `nomType7`, `nomType8`, `nomType9`, `nomType10`, `nomType11`, `nomType12`, `nomType13`, `nomType14`, `nomType15`, `nbJoursPourCalculAbsences`, `nbSemainesEnseignementAnnuel`, `nbJoursEnseignementHebdo`, `dureeQuotidienneLegale`, `dureeAnnuelleLegale`, `normalisation`, `heureDebutPauseMidi`, `heureFinPauseMidi`, `dureePauseMidi`, `dureeMaxTravail`, `dureeMinPause`, `HostNameDocument`, `PortDocument`, `UsernameDocument`, `PasswordDocument`, `RepertoireDocument`, `httpDocument`, `modeDocument`, `HostNameEDT`, `PortEDT`, `UsernameEDT`, `PasswordEDT`, `RepertoireEDT`, `httpEDT`, `modeEDT`, `organisation`, `organisationDateDebut1`, `organisationDateFin1`, `organisationDateDebut2`, `organisationDateFin2`, `organisationDateDebut3`, `organisationDateFin3`, `organisationDateDebut4`, `organisationDateFin4`, `sequenceEchap`) VALUES
(1, 'FILIERE', '2016-06-01 01:01:01', 800, 2030, 15, 0, '', '2017-08-28', '2018-08-26', 10, 15, '2022-10-09 10:08:12', 0, 0, '2007-09-01 10:10:10', 'CM', 'TD', 'TP', 'PRO', 'SEMI', 'STAGE', 'ADMIN', 'JURY', 'DS', 'APP', 'APP1', 'APP2', 'FC', 'FC1', 'FC2', 0, 32, 5, 420, 96420, 1, 720, 840, 30, 360, 30, '', 21, '', '', '', '', 1, '', 21, '', '', '', '', 1, 0, '2000-01-01 00:00:01', '2100-01-01 00:00:01', '2000-01-01 00:00:01', '2100-01-01 00:00:01', '2000-01-01 00:00:01', '2100-01-01 00:00:01', '2000-01-01 00:00:01', '2100-01-01 00:00:01', '');

-- --------------------------------------------------------

--
-- Structure de la table `filieres_reservations`
--

CREATE TABLE `filieres_reservations` (
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `deleted` tinyint NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `dateModif` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `codeFiliere` int NOT NULL DEFAULT '0',
  `codeReservation` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `filieres_seances`
--

CREATE TABLE `filieres_seances` (
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `deleted` tinyint NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `dateModif` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `codeFiliere` int NOT NULL DEFAULT '0',
  `codeSeance` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `grades`
--

CREATE TABLE `grades` (
  `codeGrade` int NOT NULL,
  `grade` varchar(150) NOT NULL DEFAULT 'GRADE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaires` varchar(50) DEFAULT NULL,
  `identifiant` varchar(50) NOT NULL,
  `heuresStatutaires` int NOT NULL DEFAULT '0',
  `heuresComplementaires` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `couleurFond` int NOT NULL DEFAULT '96420',
  `couleurPolice` int NOT NULL DEFAULT '78',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `heuresHebdomadaires` int NOT NULL DEFAULT '16800'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `grades`
--

INSERT INTO `grades` (`codeGrade`, `grade`, `dateModif`, `deleted`, `codeProprietaire`, `dateCreation`, `commentaires`, `identifiant`, `heuresStatutaires`, `heuresComplementaires`, `commentaire`, `couleurFond`, `couleurPolice`, `alias`, `heuresHebdomadaires`) VALUES
(690001, 'ATER', '2013-03-27 19:49:53', 0, 0, '2007-09-01 10:10:10', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(690002, 'MAITRE DE CONFERENCES', '2016-07-11 17:46:08', 0, 0, '2007-09-01 10:10:10', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(690003, 'PRAG', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 38400, 99900, '', 96420, 78, '', 2400),
(690004, 'VACATAIRE', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 38400, 99900, '', 96420, 78, '', 2400),
(690005, 'PU', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(690006, 'PRCE', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 38400, 99900, '', 96420, 78, '', 2400),
(5832099, 'PREN', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 38400, 99900, '', 96420, 78, '', 2400),
(12434171, 'MONITEUR', '2012-05-09 07:26:43', 0, 0, '2007-09-01 10:10:10', NULL, '', 6400, 99900, '', 96420, 78, '', 2400),
(12434172, 'ADMINISTRATIF', '2012-05-09 07:26:43', 0, 0, '2011-01-23 18:52:02', NULL, '', 0, 99900, '', 96420, 78, '', 2400),
(12434173, 'LECTEUR', '2012-05-09 07:26:43', 0, 0, '2011-09-06 15:42:44', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(12434174, 'PAST', '2012-05-09 07:26:43', 0, 0, '2011-09-08 17:33:06', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(12434175, 'CONTRACTUEL', '2012-05-09 07:26:43', 0, 0, '2011-09-09 13:05:03', NULL, '', 38400, 99900, '', 96420, 78, '', 2400),
(12434176, 'MAST', '2014-01-17 13:28:05', 0, 0, '2014-01-17 14:28:05', NULL, '', 19200, 99900, '', 96420, 78, '', 2400),
(12434177, 'TECHNICIEN', '2017-01-19 12:04:54', 0, 0, '2017-01-19 13:04:54', NULL, '', 0, 99900, '', 96420, 78, '', 2400);

-- --------------------------------------------------------

--
-- Structure de la table `grades_ponderations`
--

CREATE TABLE `grades_ponderations` (
  `codeGrade` int NOT NULL,
  `codeTypeActivite` int NOT NULL,
  `ponderation` float(10,9) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `ponderationSUP` float(10,9) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `grades_ponderations`
--

INSERT INTO `grades_ponderations` (`codeGrade`, `codeTypeActivite`, `ponderation`, `deleted`, `ponderationSUP`, `dateCreation`, `dateModif`, `codeProprietaire`) VALUES
(690001, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690003, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690004, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690005, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690006, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(5832099, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434171, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434172, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434173, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434174, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434175, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690001, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690003, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690004, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690005, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690006, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(5832099, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434171, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434172, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434173, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434174, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434175, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690001, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690003, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690004, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690005, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690006, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(5832099, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434171, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434172, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434173, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434174, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434175, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690001, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690003, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690004, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690005, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690006, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(5832099, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434171, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434172, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434173, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434174, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434175, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434176, 1, 1.500000000, 0, 1.500000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434176, 2, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434176, 3, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(12434176, 9, 1.000000000, 0, 1.000000000, '2016-01-01 01:01:01', '2016-07-05 15:13:53', 0),
(690002, 1, 1.500000000, 0, 1.500000000, '2016-07-11 19:46:08', '2016-07-11 17:46:08', 0),
(690002, 2, 1.000000000, 0, 1.000000000, '2016-07-11 19:46:08', '2016-07-11 17:46:08', 0),
(690002, 3, 1.000000000, 0, 1.000000000, '2016-07-11 19:46:08', '2016-07-11 17:46:08', 0),
(690002, 9, 1.000000000, 0, 1.000000000, '2016-07-11 19:46:08', '2016-07-11 17:46:08', 0),
(12434177, 1, 1.500000000, 0, 1.500000000, '2017-01-19 13:04:54', '2017-01-19 12:04:54', 0),
(12434177, 2, 1.000000000, 0, 1.000000000, '2017-01-19 13:04:54', '2017-01-19 12:04:54', 0),
(12434177, 3, 1.000000000, 0, 1.000000000, '2017-01-19 13:04:54', '2017-01-19 12:04:54', 0),
(12434177, 9, 1.000000000, 0, 1.000000000, '2017-01-19 13:04:54', '2017-01-19 12:04:54', 0);

-- --------------------------------------------------------

--
-- Structure de la table `hierarchies_composantes`
--

CREATE TABLE `hierarchies_composantes` (
  `code` int NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `codeRessourceFille` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hierarchies_groupes`
--

CREATE TABLE `hierarchies_groupes` (
  `code` bigint NOT NULL,
  `codeRessource` int NOT NULL DEFAULT '0',
  `codeRessourceFille` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

CREATE TABLE `historique` (
  `id` int UNSIGNED NOT NULL,
  `login` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `contenu` varchar(1000) NOT NULL,
  `ip` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lignes_budgetaires`
--

CREATE TABLE `lignes_budgetaires` (
  `codeLigneBudgetaire` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'LIGNE?',
  `alias` varchar(50) NOT NULL DEFAULT 'LIGNE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lignes_budgetaires_enseignements`
--

CREATE TABLE `lignes_budgetaires_enseignements` (
  `codeLigneBudgetaire` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lignes_budgetaires_groupes`
--

CREATE TABLE `lignes_budgetaires_groupes` (
  `codeLigneBudgetaire` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `login_prof`
--

CREATE TABLE `login_prof` (
  `codeProf` int UNSIGNED NOT NULL,
  `login` varchar(60) NOT NULL,
  `motPasse` varchar(60) NOT NULL,
  `horizontal` int UNSIGNED NOT NULL DEFAULT '0',
  `selecGroupe` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `selecProf` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `selecSalle` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `selecMateriel` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `weekend` int NOT NULL DEFAULT '1',
  `couleur_groupe` int NOT NULL DEFAULT '0',
  `couleur_prof` int NOT NULL DEFAULT '0',
  `couleur_salle` int NOT NULL DEFAULT '0',
  `couleur_materiel` int NOT NULL DEFAULT '0',
  `heureDebut` float NOT NULL DEFAULT '8',
  `heureFin` float NOT NULL DEFAULT '19',
  `reservation` int UNSIGNED NOT NULL DEFAULT '1',
  `module` int UNSIGNED NOT NULL DEFAULT '1',
  `bilan_heure` int UNSIGNED NOT NULL DEFAULT '1',
  `configuration` int UNSIGNED NOT NULL DEFAULT '1',
  `rss` int UNSIGNED NOT NULL DEFAULT '1',
  `bilan_heure_global` int UNSIGNED NOT NULL DEFAULT '0',
  `bilan_formation` int UNSIGNED NOT NULL DEFAULT '0',
  `pdf` int UNSIGNED NOT NULL DEFAULT '1',
  `seance_clicable` int UNSIGNED NOT NULL DEFAULT '1',
  `ose` int UNSIGNED NOT NULL DEFAULT '0',
  `bouton1Debut` float NOT NULL DEFAULT '8.25',
  `bouton1Fin` float NOT NULL DEFAULT '10.25',
  `bouton2Debut` float NOT NULL DEFAULT '10.5',
  `bouton2Fin` float NOT NULL DEFAULT '12.5',
  `bouton3Debut` float NOT NULL DEFAULT '13.75',
  `bouton3Fin` float NOT NULL DEFAULT '15.75',
  `bouton4Debut` float NOT NULL DEFAULT '16',
  `bouton4Fin` float NOT NULL DEFAULT '18',
  `salle` int NOT NULL DEFAULT '0',
  `mes_droits` int NOT NULL DEFAULT '1',
  `admin` int NOT NULL DEFAULT '0',
  `dialogue` int NOT NULL DEFAULT '0',
  `planning_etudiant` int NOT NULL DEFAULT '1',
  `planning_prof` int NOT NULL DEFAULT '1',
  `voir_prof` int NOT NULL DEFAULT '0',
  `ajouter_prof` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Structure de la table `matieres`
--

CREATE TABLE `matieres` (
  `codeMatiere` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'MATIERE?',
  `type` int NOT NULL DEFAULT '0',
  `codeCNU` int NOT NULL DEFAULT '0',
  `alias` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'MATIERE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeDiscipline` int NOT NULL DEFAULT '0',
  `periode` tinyint(1) NOT NULL DEFAULT '0',
  `codeComposante` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `matieres_diplomes`
--

CREATE TABLE `matieres_diplomes` (
  `codeMatiere` int NOT NULL,
  `codeDiplome` int NOT NULL,
  `codeProprietaire` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `matieres_diplomes_durees`
--

CREATE TABLE `matieres_diplomes_durees` (
  `codeDiplome` int NOT NULL,
  `codeMatiere` int NOT NULL,
  `codeTypeActivite` int NOT NULL,
  `duree` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nbGroupes` int NOT NULL DEFAULT '0',
  `taux` int NOT NULL DEFAULT '100',
  `reference` int NOT NULL DEFAULT '0',
  `referencePonderee` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `modifications`
--

CREATE TABLE `modifications` (
  `code` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int NOT NULL,
  `typeAction` int NOT NULL,
  `typeObjet` int NOT NULL,
  `numeroAction` int NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `niveaux`
--

CREATE TABLE `niveaux` (
  `codeNiveau` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `identifiant` varchar(50) NOT NULL,
  `typeElement` tinyint(1) NOT NULL DEFAULT '0',
  `dateDebut` date NOT NULL DEFAULT '2015-01-01',
  `dateFin` date NOT NULL DEFAULT '2050-01-01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `periodes`
--

CREATE TABLE `periodes` (
  `codePeriode` int NOT NULL,
  `codeProprietaire` int NOT NULL,
  `nom` varchar(150) NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `periodes`
--

INSERT INTO `periodes` (`codePeriode`, `codeProprietaire`, `nom`, `deleted`, `dateModif`, `dateCreation`) VALUES
(1, 41, 'PERIODE', 0, '2017-07-05 15:54:21', '3000-01-01 01:01:01'),
(16124522, 52, 'PERIODE', 0, '2017-06-10 15:20:02', '2016-01-01 00:00:00'),
(16124523, 52, 'PERIODE 1', 0, '2017-06-10 15:22:37', '2016-01-01 00:00:00'),
(16124524, 52, 'Mercredi', 0, '2017-06-10 15:23:38', '2016-01-01 00:00:00'),
(16124525, 50, 'PERIODE', 0, '2017-07-04 12:59:43', '2016-01-01 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `periodes_dates`
--

CREATE TABLE `periodes_dates` (
  `codePeriode` int NOT NULL,
  `date` date NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

CREATE TABLE `reservations` (
  `codeReservation` int NOT NULL,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateDemande` date NOT NULL DEFAULT '3001-01-01',
  `heureDemande` bigint NOT NULL DEFAULT '0',
  `dateReservation` date NOT NULL DEFAULT '2000-01-01',
  `heureReservation` int NOT NULL DEFAULT '0',
  `dureeReservation` int NOT NULL DEFAULT '0',
  `accord` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_enseignements`
--

CREATE TABLE `reservations_enseignements` (
  `codeReservation` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_filieres`
--

CREATE TABLE `reservations_filieres` (
  `codeReservation` int NOT NULL,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateReservation` date NOT NULL DEFAULT '2015-01-01',
  `heureReservation` int NOT NULL DEFAULT '0',
  `dureeReservation` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_groupes`
--

CREATE TABLE `reservations_groupes` (
  `codeReservation` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_historique`
--

CREATE TABLE `reservations_historique` (
  `codeReservation` int NOT NULL,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateReservation` date NOT NULL DEFAULT '2015-01-01',
  `heureReservation` int NOT NULL DEFAULT '0',
  `dureeReservation` int NOT NULL DEFAULT '0',
  `accord` tinyint NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `codeProprietaireModifieur` int NOT NULL,
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_materiels`
--

CREATE TABLE `reservations_materiels` (
  `codeReservation` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_profs`
--

CREATE TABLE `reservations_profs` (
  `codeReservation` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reservations_salles`
--

CREATE TABLE `reservations_salles` (
  `codeReservation` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_etudiants`
--

CREATE TABLE `ressources_etudiants` (
  `codeEtudiant` int NOT NULL,
  `nom` varchar(100) NOT NULL DEFAULT 'NOM?',
  `prenom` varchar(100) NOT NULL DEFAULT 'PRENOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `identifiant` varchar(50) NOT NULL DEFAULT '',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `diplome` varchar(130) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `typePublic` tinyint(1) NOT NULL DEFAULT '0',
  `codeComposante` int NOT NULL DEFAULT '-1',
  `codeDiplome` int NOT NULL DEFAULT '0',
  `prenom2` varchar(100) NOT NULL,
  `boursier` tinyint(1) NOT NULL DEFAULT '0',
  `dateNaissance` date NOT NULL DEFAULT '1900-01-01',
  `reel` tinyint NOT NULL DEFAULT '1',
  `idNational` varchar(50) NOT NULL DEFAULT '',
  `handicap` tinyint(1) NOT NULL DEFAULT '0',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `consultation` tinyint(1) NOT NULL DEFAULT '1',
  `sexe` tinyint(1) NOT NULL DEFAULT '0',
  `remediation` tinyint(1) NOT NULL DEFAULT '0',
  `dateInscription` datetime NOT NULL DEFAULT '2000-01-01 00:00:01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_groupes`
--

CREATE TABLE `ressources_groupes` (
  `codeGroupe` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `quantite` bigint NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaire` varchar(250) NOT NULL,
  `departement` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `identifiant` varchar(50) NOT NULL,
  `typePublic` tinyint NOT NULL DEFAULT '0',
  `detail_nom` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `codeComposante` int NOT NULL DEFAULT '-1',
  `codeNiveau` int NOT NULL,
  `codeDiplome` int NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_groupes_etudiants`
--

CREATE TABLE `ressources_groupes_etudiants` (
  `code` bigint NOT NULL,
  `codeGroupe` int NOT NULL,
  `codeEtudiant` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_groupes_etudiants_exceptions`
--

CREATE TABLE `ressources_groupes_etudiants_exceptions` (
  `codeEtudiant` int NOT NULL,
  `codeGroupe` int NOT NULL,
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_materiels`
--

CREATE TABLE `ressources_materiels` (
  `codeMateriel` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int NOT NULL DEFAULT '0',
  `codeSalle` int NOT NULL DEFAULT '0',
  `mobile` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_profs`
--

CREATE TABLE `ressources_profs` (
  `codeProf` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `prenom` varchar(150) NOT NULL DEFAULT 'PRENOM?',
  `codeGrade` int NOT NULL DEFAULT '0',
  `numero` int NOT NULL DEFAULT '0',
  `rue` varchar(50) NOT NULL DEFAULT '',
  `codePostal` int NOT NULL DEFAULT '0',
  `ville` varchar(50) NOT NULL DEFAULT 'VALENCIENNES',
  `pays` varchar(50) NOT NULL DEFAULT 'FRANCE',
  `telephone1` varchar(10) NOT NULL DEFAULT '327511234',
  `telephone2` varchar(10) NOT NULL DEFAULT '0',
  `codeCnu` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `identifiant` varchar(50) NOT NULL,
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `commentaire` varchar(250) NOT NULL,
  `codeComposante` int NOT NULL DEFAULT '-1',
  `titulaire` tinyint(1) NOT NULL,
  `dateValidationDossier` date NOT NULL DEFAULT '2500-01-01',
  `volStatSpecif` int NOT NULL,
  `volCompSpecif` int NOT NULL,
  `identifiantNational` varchar(50) NOT NULL,
  `prenom2` varchar(150) NOT NULL,
  `dateNaissance` date NOT NULL,
  `dateDebutContrat` date NOT NULL DEFAULT '2000-01-01',
  `dateFinContrat` date NOT NULL DEFAULT '5000-01-01',
  `sexe` tinyint(1) NOT NULL DEFAULT '0',
  `volSpecif` tinyint(1) NOT NULL DEFAULT '0',
  `volHebdoSpecif` int NOT NULL DEFAULT '2460'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ressources_salles`
--

CREATE TABLE `ressources_salles` (
  `codeSalle` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `codeZoneSalle` int NOT NULL DEFAULT '0',
  `capacite` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `surface` int NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int NOT NULL DEFAULT '-1',
  `handicap` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances`
--

CREATE TABLE `seances` (
  `codeSeance` int NOT NULL,
  `dateSeance` date NOT NULL DEFAULT '2000-01-01',
  `heureSeance` int NOT NULL DEFAULT '800',
  `dureeSeance` int NOT NULL DEFAULT '100',
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` char(250) NOT NULL DEFAULT '',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `annulee` tinyint(1) NOT NULL DEFAULT '0',
  `controle` tinyint(1) NOT NULL DEFAULT '0',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_documents`
--

CREATE TABLE `seances_documents` (
  `codeSeance` int NOT NULL,
  `nomFichier` varchar(200) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateDebutAcces` datetime NOT NULL,
  `dateFinAcces` datetime NOT NULL,
  `codeProprietaire` int NOT NULL,
  `commentaire` varchar(150) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_groupes`
--

CREATE TABLE `seances_groupes` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_historique`
--

CREATE TABLE `seances_historique` (
  `codeSeance` int NOT NULL,
  `dateSeance` date NOT NULL DEFAULT '2000-01-01',
  `heureSeance` int NOT NULL DEFAULT '800',
  `dureeSeance` int NOT NULL DEFAULT '100',
  `codeEnseignement` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `commentaire` char(250) NOT NULL DEFAULT '',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `codeProprietaireModifieur` int NOT NULL,
  `annulee` tinyint(1) NOT NULL DEFAULT '0',
  `controle` tinyint(1) NOT NULL DEFAULT '0',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_materiels`
--

CREATE TABLE `seances_materiels` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_profs`
--

CREATE TABLE `seances_profs` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_profs_non_comptabilisees`
--

CREATE TABLE `seances_profs_non_comptabilisees` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_profs_payees`
--

CREATE TABLE `seances_profs_payees` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `seances_salles`
--

CREATE TABLE `seances_salles` (
  `codeSeance` int NOT NULL DEFAULT '0',
  `codeRessource` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `typage_materiels`
--

CREATE TABLE `typage_materiels` (
  `codeMateriel` int NOT NULL DEFAULT '0',
  `codeType` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `typage_salles`
--

CREATE TABLE `typage_salles` (
  `codeSalle` int NOT NULL DEFAULT '0',
  `codeType` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `types_activites`
--

CREATE TABLE `types_activites` (
  `codeTypeActivite` int NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `couleurFond` bigint NOT NULL,
  `couleurPolice` bigint NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `ponderation` float(10,9) DEFAULT '1.000000000',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `forfaitPossible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `types_activites`
--

INSERT INTO `types_activites` (`codeTypeActivite`, `identifiant`, `nom`, `alias`, `commentaire`, `couleurFond`, `couleurPolice`, `dateModif`, `deleted`, `codeProprietaire`, `ponderation`, `dateCreation`, `forfaitPossible`) VALUES
(1, '1', 'Cours', 'CM', '', 8421631, 0, '2015-06-24 08:32:36', 0, 0, 1.000000000, '2000-01-01 00:00:00', 1),
(2, '2', 'TD', 'TD', '', 16744576, 0, '2015-06-24 08:26:30', 0, 0, 1.000000000, '2000-01-01 00:00:00', 1),
(3, '3', 'TP', 'TP', '', 8454016, 0, '2016-09-30 13:00:36', 0, 0, 1.000000000, '2000-01-01 00:00:00', 1),
(9, '9', 'DS', 'DS', '', 255, 16777215, '2015-06-24 08:26:27', 0, 0, 1.000000000, '2000-01-01 00:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `types_materiels`
--

CREATE TABLE `types_materiels` (
  `codeTypeMateriel` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `types_salles`
--

CREATE TABLE `types_salles` (
  `codeTypeSalle` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `codeUtilisateur` int NOT NULL,
  `login` varchar(50) NOT NULL DEFAULT 'NOM?',
  `password` varchar(50) NOT NULL DEFAULT 'PASS?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `arret` tinyint(1) NOT NULL,
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `version` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `intervalleSynchronisation` int NOT NULL DEFAULT '600000',
  `estConnecte` tinyint(1) NOT NULL DEFAULT '0',
  `nom` varchar(100) NOT NULL DEFAULT '',
  `prenom` varchar(100) NOT NULL DEFAULT 'PRENOM?',
  `commentaire` varchar(250) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `historique` tinyint(1) NOT NULL,
  `estUnProfilUtilisateur` int NOT NULL DEFAULT '0',
  `droits` varchar(250) NOT NULL DEFAULT '0',
  `delaiModification` int NOT NULL DEFAULT '9999',
  `versionImposee` varchar(10) NOT NULL,
  `initParam` int NOT NULL DEFAULT '-1',
  `estModele` tinyint(1) NOT NULL DEFAULT '0',
  `fonctionnel` tinyint(1) NOT NULL DEFAULT '0',
  `dureeMaxConnexion` int NOT NULL DEFAULT '999999',
  `adresseMAC` varchar(20) NOT NULL,
  `methodeDeCalcul` tinyint(1) NOT NULL DEFAULT '1',
  `verifNouvelleVersion` tinyint(1) NOT NULL DEFAULT '1',
  `codeComposante` int NOT NULL DEFAULT '0',
  `alarme1` int NOT NULL DEFAULT '-1',
  `alarme2` int NOT NULL DEFAULT '-1',
  `dateDebut` date NOT NULL DEFAULT '2000-01-01',
  `dateFin` date NOT NULL DEFAULT '3000-01-01',
  `HostNameDocument` varchar(100) NOT NULL DEFAULT '',
  `PortDocument` int NOT NULL DEFAULT '21',
  `UsernameDocument` varchar(100) NOT NULL DEFAULT '',
  `PasswordDocument` varchar(100) NOT NULL DEFAULT '',
  `RepertoireDocument` varchar(200) NOT NULL DEFAULT '',
  `httpDocument` varchar(200) NOT NULL DEFAULT '',
  `modeDocument` tinyint(1) NOT NULL DEFAULT '1',
  `consultationWeb` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`codeUtilisateur`, `login`, `password`, `dateModif`, `deleted`, `arret`, `codeProprietaire`, `email`, `version`, `intervalleSynchronisation`, `estConnecte`, `nom`, `prenom`, `commentaire`, `dateCreation`, `historique`, `estUnProfilUtilisateur`, `droits`, `delaiModification`, `versionImposee`, `initParam`, `estModele`, `fonctionnel`, `dureeMaxConnexion`, `adresseMAC`, `methodeDeCalcul`, `verifNouvelleVersion`, `codeComposante`, `alarme1`, `alarme2`, `dateDebut`, `dateFin`, `HostNameDocument`, `PortDocument`, `UsernameDocument`, `PasswordDocument`, `RepertoireDocument`, `httpDocument`, `modeDocument`, `consultationWeb`) VALUES
(0, 'root', 'miW2Ue7YXCzOSF0mOn5u8A==', '2017-07-16 16:15:29', 0, 0, 0, '', '2017-06-27', 2100000, 0, 'NOM', 'PRENOM', '', '2007-09-01 10:10:10', 1, 0, '1111111111110111111101111111111111111111111111111111111011000000101111111100111111111111111001100000111111111110111111111', 365, '', 0, 0, 0, 600, '', 2, 1, 1, -1, -1, '2000-01-01', '3000-01-01', '', 21, '', '', '', '', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_actions`
--

CREATE TABLE `utilisateurs_actions` (
  `codeAction` int NOT NULL,
  `dateDebut` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateFin` datetime NOT NULL,
  `achevee` tinyint(1) NOT NULL DEFAULT '0',
  `typeAction` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = ajout; 2 = modification; 3 = destruction',
  `codeUtilisateur` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `numeroCommande` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_appartenances_groupes`
--

CREATE TABLE `utilisateurs_appartenances_groupes` (
  `codeUtilisateur` int NOT NULL DEFAULT '0',
  `codeGroupeUtilisateurs` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_calendriers_enseignements`
--

CREATE TABLE `utilisateurs_calendriers_enseignements` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_calendriers_groupes`
--

CREATE TABLE `utilisateurs_calendriers_groupes` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_calendriers_materiels`
--

CREATE TABLE `utilisateurs_calendriers_materiels` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_calendriers_profs`
--

CREATE TABLE `utilisateurs_calendriers_profs` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_calendriers_salles`
--

CREATE TABLE `utilisateurs_calendriers_salles` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_composantes`
--

CREATE TABLE `utilisateurs_composantes` (
  `codeComposante` int NOT NULL DEFAULT '0',
  `codeUtilisateur` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateurs_composantes`
--

INSERT INTO `utilisateurs_composantes` (`codeComposante`, `codeUtilisateur`, `deleted`) VALUES
(1, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_composantes_defaut`
--

CREATE TABLE `utilisateurs_composantes_defaut` (
  `codeUtilisateur` int NOT NULL DEFAULT '0',
  `codeComposante` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `typeDonnee` tinyint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_connexions`
--

CREATE TABLE `utilisateurs_connexions` (
  `codeUtilisateur` int NOT NULL DEFAULT '0',
  `dateConnexion` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `dateDeconnexion` datetime NOT NULL DEFAULT '2000-01-01 01:01:01',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `numeroSession` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `adresseMac` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_domaines`
--

CREATE TABLE `utilisateurs_domaines` (
  `codeDomaine` int NOT NULL,
  `nom` varchar(150) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_domaines_groupes`
--

CREATE TABLE `utilisateurs_domaines_groupes` (
  `codeDomaine` int NOT NULL,
  `codeGroupeUtilisateurs` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages`
--

CREATE TABLE `utilisateurs_filtrages` (
  `codeFiltrage` int NOT NULL,
  `nomFiltrage` varchar(150) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL,
  `typeDeDonnees` tinyint NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `selectionDefaut` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_composantes`
--

CREATE TABLE `utilisateurs_filtrages_composantes` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_diplomes`
--

CREATE TABLE `utilisateurs_filtrages_diplomes` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_enseignements`
--

CREATE TABLE `utilisateurs_filtrages_enseignements` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_etudiants`
--

CREATE TABLE `utilisateurs_filtrages_etudiants` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_groupes`
--

CREATE TABLE `utilisateurs_filtrages_groupes` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_materiels`
--

CREATE TABLE `utilisateurs_filtrages_materiels` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_matieres`
--

CREATE TABLE `utilisateurs_filtrages_matieres` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_niveaux`
--

CREATE TABLE `utilisateurs_filtrages_niveaux` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_profs`
--

CREATE TABLE `utilisateurs_filtrages_profs` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_filtrages_salles`
--

CREATE TABLE `utilisateurs_filtrages_salles` (
  `codeProprietaire` int NOT NULL,
  `codeRessource` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_groupes`
--

CREATE TABLE `utilisateurs_groupes` (
  `codeGroupeUtilisateurs` int NOT NULL,
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `droits` varchar(250) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `dateDebut` date NOT NULL DEFAULT '2000-01-01',
  `dateFin` date NOT NULL DEFAULT '3000-01-01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_groupeutilisateurs_droits`
--

CREATE TABLE `utilisateurs_groupeutilisateurs_droits` (
  `codeUtilisateur` int NOT NULL,
  `codeGroupeUtilisateurs` int NOT NULL,
  `droits` varchar(250) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateDebut` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateFin` datetime NOT NULL DEFAULT '3000-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_messages`
--

CREATE TABLE `utilisateurs_messages` (
  `codeMessage` bigint NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dateModification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `debutDiffusion` datetime NOT NULL,
  `finDiffusion` datetime NOT NULL,
  `message` text NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaireRedacteur` bigint NOT NULL,
  `objet` varchar(255) NOT NULL DEFAULT '',
  `nbAffichages` int NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_messages_lectures`
--

CREATE TABLE `utilisateurs_messages_lectures` (
  `codeProprietaireLecteur` bigint NOT NULL,
  `codeMessage` bigint NOT NULL,
  `dateLecture` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `nbAffichagesFaits` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_modeles`
--

CREATE TABLE `utilisateurs_modeles` (
  `codeUtilisateur` int NOT NULL,
  `codeModele` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_numeros_commandes`
--

CREATE TABLE `utilisateurs_numeros_commandes` (
  `numeroCommande` int NOT NULL,
  `dateCreation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `typeCommande` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = ajout; 2 = modification; 3 = destruction',
  `codeUtilisateur` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_parametres`
--

CREATE TABLE `utilisateurs_parametres` (
  `nomParametre` int NOT NULL,
  `valeurParametre` varchar(50) NOT NULL DEFAULT '',
  `commentaireParametre` varchar(250) NOT NULL DEFAULT '',
  `codeUtilisateur` int NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rubriqueParametre` int NOT NULL,
  `champParametre` varchar(50) NOT NULL,
  `adresseMAC` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs_synchronisations`
--

CREATE TABLE `utilisateurs_synchronisations` (
  `codeUtilisateur` int NOT NULL,
  `dateSynchronisation` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vacances`
--

CREATE TABLE `vacances` (
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `volumes_composantes_profs`
--

CREATE TABLE `volumes_composantes_profs` (
  `codeProf` int NOT NULL,
  `codeComposante` int NOT NULL,
  `volume` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `codeProprietaire` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Structure de la table `zones_salles`
--

CREATE TABLE `zones_salles` (
  `codeZoneSalle` int NOT NULL,
  `couleurFond` bigint NOT NULL DEFAULT '0',
  `couleurPolice` bigint NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'ZONE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `zones_temps`
--

CREATE TABLE `zones_temps` (
  `codeZoneSalle1` int NOT NULL DEFAULT '0',
  `codeZoneSalle2` int NOT NULL DEFAULT '0',
  `tempsInterZone` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2007-09-01 10:10:10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `absences_etudiants`
--
ALTER TABLE `absences_etudiants`
  ADD PRIMARY KEY (`codeAbsence`),
  ADD KEY `absences_etudiants_del` (`deleted`),
  ADD KEY `absences_etudiants_dateModif` (`dateModif`),
  ADD KEY `absences_etudiants_ibfk_1` (`codeRessource`),
  ADD KEY `absences_etudiants_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `absences_justifications`
--
ALTER TABLE `absences_justifications`
  ADD PRIMARY KEY (`codeJustification`),
  ADD KEY `absences_justifications_del` (`deleted`);

--
-- Index pour la table `absences_periodes_etudiants`
--
ALTER TABLE `absences_periodes_etudiants`
  ADD PRIMARY KEY (`codeAbsence`);

--
-- Index pour la table `absences_periodes_profs`
--
ALTER TABLE `absences_periodes_profs`
  ADD PRIMARY KEY (`codeAbsence`);

--
-- Index pour la table `absences_profs`
--
ALTER TABLE `absences_profs`
  ADD PRIMARY KEY (`codeAbsence`),
  ADD KEY `absences_profs_del` (`deleted`),
  ADD KEY `absences_profs_dateModif` (`dateModif`),
  ADD KEY `absences_profs_ibfk_1` (`codeRessource`),
  ADD KEY `absences_profs_ibfk_2` (`codeProprietaire`),
  ADD KEY `absences_profs_ibfk_3` (`codeJustification`);

--
-- Index pour la table `absences_validations`
--
ALTER TABLE `absences_validations`
  ADD PRIMARY KEY (`codeValidation`),
  ADD KEY `absences_validations_del` (`deleted`),
  ADD KEY `absences_validations_ibfk_1` (`codeProf`),
  ADD KEY `absences_validations_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `bilans_profs_archives`
--
ALTER TABLE `bilans_profs_archives`
  ADD PRIMARY KEY (`numeroBilan`);

--
-- Index pour la table `calendriers_commentaires`
--
ALTER TABLE `calendriers_commentaires`
  ADD KEY `calendriers_commentaires_ibfk_1` (`codeProprietaire`);

--
-- Index pour la table `calendriers_enseignements`
--
ALTER TABLE `calendriers_enseignements`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_enseignements_del` (`deleted`),
  ADD KEY `calendriers_enseignements_dateModif` (`dateModif`),
  ADD KEY `calendriers_enseignements_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_enseignements_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `calendriers_filieres`
--
ALTER TABLE `calendriers_filieres`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_filieres_del` (`deleted`),
  ADD KEY `calendriers_filieres_dateModif` (`dateModif`),
  ADD KEY `calendriers_filieres_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_filieres_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `calendriers_groupes`
--
ALTER TABLE `calendriers_groupes`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_groupes_del` (`deleted`),
  ADD KEY `calendriers_groupes_dateModif` (`dateModif`),
  ADD KEY `calendriers_groupes_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_groupes_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `calendriers_materiels`
--
ALTER TABLE `calendriers_materiels`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_materiels_del` (`deleted`),
  ADD KEY `calendriers_materiels_dateModif` (`dateModif`),
  ADD KEY `calendriers_materiels_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_materiels_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `calendriers_profs`
--
ALTER TABLE `calendriers_profs`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_profs_del` (`deleted`),
  ADD KEY `calendriers_profs_dateModif` (`dateModif`),
  ADD KEY `calendriers_profs_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_profs_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `calendriers_salles`
--
ALTER TABLE `calendriers_salles`
  ADD PRIMARY KEY (`code`),
  ADD KEY `calendriers_salles_del` (`deleted`),
  ADD KEY `calendriers_salles_dateModif` (`dateModif`),
  ADD KEY `calendriers_salles_ibfk_1` (`codeRessource`),
  ADD KEY `calendriers_salles_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `cnu`
--
ALTER TABLE `cnu`
  ADD PRIMARY KEY (`codeCNU`),
  ADD KEY `cnu_del` (`deleted`),
  ADD KEY `cnu_dateModif` (`dateModif`),
  ADD KEY `cnu_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `composantes`
--
ALTER TABLE `composantes`
  ADD PRIMARY KEY (`codeComposante`),
  ADD KEY `composantes_del` (`deleted`),
  ADD KEY `composantes_dateModif` (`dateModif`),
  ADD KEY `composantes_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `composantes_directeurs`
--
ALTER TABLE `composantes_directeurs`
  ADD KEY `composantes_directeurs_del` (`deleted`),
  ADD KEY `composantes_directeurs_dateModif` (`dateModif`),
  ADD KEY `composantes_directeurs_ibfk_1` (`codeDirecteur`),
  ADD KEY `composantes_directeurs_ibfk_2` (`codeComposante`),
  ADD KEY `composantes_directeurs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `compteur`
--
ALTER TABLE `compteur`
  ADD PRIMARY KEY (`id_compteur`);

--
-- Index pour la table `diplomes`
--
ALTER TABLE `diplomes`
  ADD PRIMARY KEY (`codeDiplome`),
  ADD KEY `diplomes_del` (`deleted`),
  ADD KEY `diplomes_dateModif` (`dateModif`),
  ADD KEY `diplomes_ibfk_1` (`codeComposante`),
  ADD KEY `diplomes_ibfk_4` (`codeProprietaire`);

--
-- Index pour la table `disciplines`
--
ALTER TABLE `disciplines`
  ADD PRIMARY KEY (`codeDiscipline`),
  ADD KEY `disciplines_del` (`deleted`),
  ADD KEY `disciplines_dateModif` (`dateModif`),
  ADD KEY `disciplines_ibfk_2` (`codeProprietaire`);

--
-- Index pour la table `disciplines_profs`
--
ALTER TABLE `disciplines_profs`
  ADD KEY `disciplines_profs_del` (`deleted`),
  ADD KEY `disciplines_profs_dateModif` (`dateModif`),
  ADD KEY `disciplines_profs_ibfk_1` (`codeDiscipline`),
  ADD KEY `disciplines_profs_ibfk_2` (`codeProf`),
  ADD KEY `disciplines_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements`
--
ALTER TABLE `enseignements`
  ADD PRIMARY KEY (`codeEnseignement`),
  ADD KEY `enseignements_del` (`deleted`),
  ADD KEY `enseignements_dateModif` (`dateModif`),
  ADD KEY `enseignements_ibfk_1` (`codeMatiere`),
  ADD KEY `enseignements_ibfk_4` (`codeTypeActivite`),
  ADD KEY `enseignements_ibfk_5` (`codeComposante`),
  ADD KEY `enseignements_ibfk_8` (`codeProprietaire`);

--
-- Index pour la table `enseignements_groupes`
--
ALTER TABLE `enseignements_groupes`
  ADD KEY `enseignements_groupes_del` (`deleted`),
  ADD KEY `enseignements_groupes_dateModif` (`dateModif`),
  ADD KEY `enseignements_groupes_ibfk_1` (`codeEnseignement`),
  ADD KEY `enseignements_groupes_ibfk_2` (`codeRessource`),
  ADD KEY `enseignements_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements_historique`
--
ALTER TABLE `enseignements_historique`
  ADD KEY `enseignements_historique_del` (`deleted`),
  ADD KEY `enseignements_historique_dateModif` (`dateModif`),
  ADD KEY `enseignements_historique_ibfk_1` (`codeMatiere`),
  ADD KEY `enseignements_historique_ibfk_2` (`codeTypeSalle`),
  ADD KEY `enseignements_historique_ibfk_3` (`codeZoneSalle`),
  ADD KEY `enseignements_historique_ibfk_8` (`codeProprietaire`);

--
-- Index pour la table `enseignements_materiels`
--
ALTER TABLE `enseignements_materiels`
  ADD KEY `enseignements_materiels_del` (`deleted`),
  ADD KEY `enseignements_materiels_dateModif` (`dateModif`),
  ADD KEY `enseignements_materiels_ibfk_1` (`codeEnseignement`),
  ADD KEY `enseignements_materiels_ibfk_2` (`codeRessource`),
  ADD KEY `enseignements_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements_prerequis`
--
ALTER TABLE `enseignements_prerequis`
  ADD KEY `enseignements_prerequis_del` (`deleted`),
  ADD KEY `enseignements_prerequis_dateModif` (`dateModif`),
  ADD KEY `enseignements_prerequis_ibfk_1` (`codeEnseignement`),
  ADD KEY `enseignements_prerequis_ibfk_2` (`codePrerequis`),
  ADD KEY `enseignements_prerequis_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements_profs`
--
ALTER TABLE `enseignements_profs`
  ADD KEY `enseignements_profs_del` (`deleted`),
  ADD KEY `enseignements_profs_dateModif` (`dateModif`),
  ADD KEY `enseignements_profs_ibfk_1` (`codeEnseignement`),
  ADD KEY `enseignements_profs_ibfk_2` (`codeRessource`),
  ADD KEY `enseignements_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements_salles`
--
ALTER TABLE `enseignements_salles`
  ADD KEY `enseignements_salles_del` (`deleted`),
  ADD KEY `enseignements_salles_dateModif` (`dateModif`),
  ADD KEY `enseignements_salles_ibfk_1` (`codeEnseignement`),
  ADD KEY `enseignements_salles_ibfk_2` (`codeRessource`),
  ADD KEY `enseignements_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `enseignements_types_materiels`
--
ALTER TABLE `enseignements_types_materiels`
  ADD KEY `enseignements_types_materiels_del` (`deleted`) USING BTREE,
  ADD KEY `enseignements_types_materiels_dateModif` (`dateModif`) USING BTREE,
  ADD KEY `enseignements_types_materiels_ibfk_1` (`codeEnseignement`) USING BTREE,
  ADD KEY `enseignements_types_materiels_ibfk_2` (`codeTypeRessource`) USING BTREE,
  ADD KEY `enseignements_types_materiels_ibfk_3` (`codeProprietaire`) USING BTREE;

--
-- Index pour la table `enseignements_types_salles`
--
ALTER TABLE `enseignements_types_salles`
  ADD KEY `enseignements_types_salles_del` (`deleted`) USING BTREE,
  ADD KEY `enseignements_types_salles_dateModif` (`dateModif`) USING BTREE,
  ADD KEY `enseignements_types_salles_ibfk_1` (`codeEnseignement`) USING BTREE,
  ADD KEY `enseignements_types_salles_ibfk_2` (`codeTypeRessource`) USING BTREE,
  ADD KEY `enseignements_types_salles_ibfk_3` (`codeProprietaire`) USING BTREE;

--
-- Index pour la table `etudiants_diplomes`
--
ALTER TABLE `etudiants_diplomes`
  ADD KEY `etudiants_diplomes_del` (`deleted`),
  ADD KEY `etudiants_diplomes_dateModif` (`dateModif`),
  ADD KEY `etudiants_diplomes_ibfk_1` (`codeDiplome`),
  ADD KEY `etudiants_diplomes_ibfk_2` (`codeEtudiant`),
  ADD KEY `etudiants_diplomes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `filieres`
--
ALTER TABLE `filieres`
  ADD PRIMARY KEY (`codeFiliere`);

--
-- Index pour la table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`codeGrade`),
  ADD KEY `grades_del` (`deleted`),
  ADD KEY `grades_dateModif` (`dateModif`),
  ADD KEY `grades_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `grades_ponderations`
--
ALTER TABLE `grades_ponderations`
  ADD KEY `grades_ponderations_del` (`deleted`),
  ADD KEY `grades_ponderations_dateModif` (`dateModif`),
  ADD KEY `grades_ponderations_ibfk_1` (`codeGrade`),
  ADD KEY `grades_ponderations_ibfk_2` (`codeTypeActivite`),
  ADD KEY `grades_ponderations_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `hierarchies_composantes`
--
ALTER TABLE `hierarchies_composantes`
  ADD PRIMARY KEY (`code`),
  ADD KEY `hierarchies_composantes_del` (`deleted`),
  ADD KEY `hierarchies_composantes_dateModif` (`dateModif`),
  ADD KEY `hierarchies_composantes_ibfk_1` (`codeRessource`),
  ADD KEY `hierarchies_composantes_ibfk_2` (`codeRessourceFille`),
  ADD KEY `hierarchies_composantes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `hierarchies_groupes`
--
ALTER TABLE `hierarchies_groupes`
  ADD PRIMARY KEY (`code`),
  ADD KEY `hierarchies_groupe_del` (`deleted`),
  ADD KEY `hierarchies_groupes_dateModif` (`dateModif`),
  ADD KEY `hierarchies_groupes_ibfk_1` (`codeRessource`),
  ADD KEY `hierarchies_groupes_ibfk_2` (`codeRessourceFille`),
  ADD KEY `hierarchies_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `historique`
--
ALTER TABLE `historique`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `lignes_budgetaires`
--
ALTER TABLE `lignes_budgetaires`
  ADD PRIMARY KEY (`codeLigneBudgetaire`),
  ADD KEY `lignes_budgetaires_del` (`deleted`),
  ADD KEY `lignes_budgetaires_dateModif` (`dateModif`),
  ADD KEY `lignes_budgetaires_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `lignes_budgetaires_enseignements`
--
ALTER TABLE `lignes_budgetaires_enseignements`
  ADD KEY `lignes_budgetaires_enseignements_del` (`deleted`),
  ADD KEY `lignes_budgetaires_enseignements_dateModif` (`dateModif`),
  ADD KEY `lignes_budgetaires_enseignements_ibfk_1` (`codeLigneBudgetaire`),
  ADD KEY `lignes_budgetaires_enseignements_ibfk_2` (`codeRessource`),
  ADD KEY `lignes_budgetaires_enseignements_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `lignes_budgetaires_groupes`
--
ALTER TABLE `lignes_budgetaires_groupes`
  ADD KEY `lignes_budgetaires_groupes_del` (`deleted`),
  ADD KEY `lignes_budgetaires_groupes_dateModif` (`dateModif`),
  ADD KEY `lignes_budgetaires_groupes_ibfk_1` (`codeLigneBudgetaire`),
  ADD KEY `lignes_budgetaires_groupes_ibfk_2` (`codeRessource`),
  ADD KEY `lignes_budgetaires_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `login_prof`
--
ALTER TABLE `login_prof`
  ADD PRIMARY KEY (`codeProf`);

--
-- Index pour la table `matieres`
--
ALTER TABLE `matieres`
  ADD PRIMARY KEY (`codeMatiere`),
  ADD KEY `matieres_del` (`deleted`),
  ADD KEY `matieres_dateModif` (`dateModif`),
  ADD KEY `matieres_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `matieres_diplomes`
--
ALTER TABLE `matieres_diplomes`
  ADD KEY `matieres_diplomes_del` (`deleted`),
  ADD KEY `matieres_diplomes_dateModif` (`dateModif`),
  ADD KEY `matieres_diplomes_ibfk_1` (`codeMatiere`),
  ADD KEY `matieres_diplomes_ibfk_2` (`codeDiplome`),
  ADD KEY `matieres_diplomes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `matieres_diplomes_durees`
--
ALTER TABLE `matieres_diplomes_durees`
  ADD KEY `matieres_diplomes_durees_del` (`deleted`),
  ADD KEY `matieres_diplomes_durees_dateModif` (`dateModif`),
  ADD KEY `matieres_diplomes_durees_ibfk_1` (`codeMatiere`),
  ADD KEY `matieres_diplomes_durees_ibfk_2` (`codeDiplome`),
  ADD KEY `matieres_diplomes_durees_ibfk_3` (`codeTypeActivite`),
  ADD KEY `matieres_diplomes_durees_ibfk_4` (`codeProprietaire`);

--
-- Index pour la table `niveaux`
--
ALTER TABLE `niveaux`
  ADD PRIMARY KEY (`codeNiveau`),
  ADD KEY `niveaux_del` (`deleted`),
  ADD KEY `niveaux_dateModif` (`dateModif`),
  ADD KEY `niveaux_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `periodes`
--
ALTER TABLE `periodes`
  ADD PRIMARY KEY (`codePeriode`),
  ADD KEY `periodes_del` (`deleted`),
  ADD KEY `periodes_dateModif` (`dateModif`),
  ADD KEY `periodes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `periodes_dates`
--
ALTER TABLE `periodes_dates`
  ADD KEY `periodes_dates_del` (`deleted`),
  ADD KEY `periodes_dates_dateModif` (`dateModif`),
  ADD KEY `periodes_dates_del_ibfk_1` (`codePeriode`),
  ADD KEY `periodes_dates_del_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`codeReservation`),
  ADD KEY `reservations_del` (`deleted`),
  ADD KEY `reservations_dateModif` (`dateModif`),
  ADD KEY `reservations_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_enseignements`
--
ALTER TABLE `reservations_enseignements`
  ADD KEY `reservations_enseignements_del` (`deleted`),
  ADD KEY `reservations_enseignements_dateModif` (`dateModif`),
  ADD KEY `reservations_enseignements_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_enseignements_ibfk_2` (`codeRessource`),
  ADD KEY `reservations_enseignements_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_filieres`
--
ALTER TABLE `reservations_filieres`
  ADD PRIMARY KEY (`codeReservation`),
  ADD KEY `reservations_filieres_del` (`deleted`),
  ADD KEY `reservations_filieres_dateModif` (`dateModif`),
  ADD KEY `reservations_filieres_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_groupes`
--
ALTER TABLE `reservations_groupes`
  ADD KEY `reservations_groupes_del` (`deleted`),
  ADD KEY `reservations_groupes_dateModif` (`dateModif`),
  ADD KEY `reservations_groupes_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_groupes_ibfk_2` (`codeRessource`),
  ADD KEY `reservations_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_historique`
--
ALTER TABLE `reservations_historique`
  ADD KEY `reservations_historique_del` (`deleted`),
  ADD KEY `reservations_historique_dateModif` (`dateModif`),
  ADD KEY `reservations_historique_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_historique_ibfk_2` (`codeProprietaireModifieur`),
  ADD KEY `reservations_historique_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_materiels`
--
ALTER TABLE `reservations_materiels`
  ADD KEY `reservations_materiels_del` (`deleted`),
  ADD KEY `reservations_materiels_dateModif` (`dateModif`),
  ADD KEY `reservations_materiels_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_materiels_ibfk_2` (`codeRessource`),
  ADD KEY `reservations_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_profs`
--
ALTER TABLE `reservations_profs`
  ADD KEY `reservations_profs_del` (`deleted`),
  ADD KEY `reservations_profs_dateModif` (`dateModif`),
  ADD KEY `reservations_profs_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_profs_ibfk_2` (`codeRessource`),
  ADD KEY `reservations_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `reservations_salles`
--
ALTER TABLE `reservations_salles`
  ADD KEY `reservations_salles_del` (`deleted`),
  ADD KEY `reservations_salles_dateModif` (`dateModif`),
  ADD KEY `reservations_salles_ibfk_1` (`codeReservation`),
  ADD KEY `reservations_salles_ibfk_2` (`codeRessource`),
  ADD KEY `reservations_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_etudiants`
--
ALTER TABLE `ressources_etudiants`
  ADD PRIMARY KEY (`codeEtudiant`),
  ADD KEY `ressources_etudiants_del` (`deleted`),
  ADD KEY `ressources_etudiants_dateModif` (`dateModif`),
  ADD KEY `ressources_etudiants_ibfk_2` (`codeComposante`),
  ADD KEY `ressources_etudiants_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_groupes`
--
ALTER TABLE `ressources_groupes`
  ADD PRIMARY KEY (`codeGroupe`),
  ADD KEY `ressources_groupes_del` (`deleted`),
  ADD KEY `ressources_groupes_dateModif` (`dateModif`),
  ADD KEY `ressources_groupes_ibfk_2` (`codeComposante`),
  ADD KEY `ressources_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_groupes_etudiants`
--
ALTER TABLE `ressources_groupes_etudiants`
  ADD PRIMARY KEY (`code`),
  ADD KEY `ressources_groupes_etudiants_del` (`deleted`),
  ADD KEY `ressources_groupes_etudiants_dateModif` (`dateModif`),
  ADD KEY `ressources_groupes_etudiants_ibfk_1` (`codeEtudiant`),
  ADD KEY `ressources_groupes_etudiants_ibfk_2` (`codeGroupe`),
  ADD KEY `ressources_groupes_etudiants_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_groupes_etudiants_exceptions`
--
ALTER TABLE `ressources_groupes_etudiants_exceptions`
  ADD KEY `ressources_groupes_etudiants_exceptions_del` (`deleted`),
  ADD KEY `ressources_groupes_etudiants_exceptions_dateModif` (`dateModif`),
  ADD KEY `ressources_groupes_etudiants_exceptions_ibfk_1` (`codeEtudiant`),
  ADD KEY `ressources_groupes_etudiants_exceptions_ibfk_2` (`codeGroupe`),
  ADD KEY `ressources_groupes_etudiants_exceptions_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_materiels`
--
ALTER TABLE `ressources_materiels`
  ADD PRIMARY KEY (`codeMateriel`),
  ADD KEY `ressources_materiels_del` (`deleted`),
  ADD KEY `ressources_materiels_dateModif` (`dateModif`),
  ADD KEY `ressources_materiels_ibfk_1` (`codeComposante`),
  ADD KEY `ressources_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_profs`
--
ALTER TABLE `ressources_profs`
  ADD PRIMARY KEY (`codeProf`),
  ADD KEY `ressources_profs_del` (`deleted`),
  ADD KEY `ressources_profs_dateModif` (`dateModif`),
  ADD KEY `ressources_profs_ibfk_1` (`codeComposante`),
  ADD KEY `ressources_profs_ibfk_2` (`codeGrade`),
  ADD KEY `ressources_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `ressources_salles`
--
ALTER TABLE `ressources_salles`
  ADD PRIMARY KEY (`codeSalle`),
  ADD KEY `ressources_salles_del` (`deleted`),
  ADD KEY `ressources_salles_dateModif` (`dateModif`),
  ADD KEY `ressources_salles_ibfk_1` (`codeComposante`),
  ADD KEY `ressources_salles_ibfk_2` (`codeZoneSalle`),
  ADD KEY `ressources_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances`
--
ALTER TABLE `seances`
  ADD PRIMARY KEY (`codeSeance`),
  ADD KEY `seances_del` (`deleted`),
  ADD KEY `seances_dateModif` (`dateModif`),
  ADD KEY `seances_ibfk_2` (`codeEnseignement`),
  ADD KEY `seances_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_groupes`
--
ALTER TABLE `seances_groupes`
  ADD KEY `seances_groupes_del` (`deleted`),
  ADD KEY `seances_groupes_dateModif` (`dateModif`),
  ADD KEY `seances_groupes_ibfk_1` (`codeSeance`),
  ADD KEY `seances_groupes_ibfk_2` (`codeRessource`),
  ADD KEY `seances_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_historique`
--
ALTER TABLE `seances_historique`
  ADD KEY `seances_historique_del` (`deleted`),
  ADD KEY `seances_historique_dateModif` (`dateModif`),
  ADD KEY `seances_historique_ibfk_1` (`codeSeance`),
  ADD KEY `seances_historique_ibfk_2` (`codeProprietaireModifieur`),
  ADD KEY `seances_historique_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_materiels`
--
ALTER TABLE `seances_materiels`
  ADD KEY `seances_materiels_del` (`deleted`),
  ADD KEY `seances_materiels_dateModif` (`dateModif`),
  ADD KEY `seances_materiels_ibfk_1` (`codeSeance`),
  ADD KEY `seances_materiels_ibfk_2` (`codeRessource`),
  ADD KEY `seances_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_profs`
--
ALTER TABLE `seances_profs`
  ADD KEY `seances_profs_del` (`deleted`),
  ADD KEY `seances_profs_dateModif` (`dateModif`),
  ADD KEY `seances_profs_ibfk_1` (`codeSeance`),
  ADD KEY `seances_profs_ibfk_2` (`codeRessource`),
  ADD KEY `seances_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_profs_non_comptabilisees`
--
ALTER TABLE `seances_profs_non_comptabilisees`
  ADD KEY `seances_profs_non_comptabilisees_del` (`deleted`),
  ADD KEY `seances_profs_non_comptabilisees_dateModif` (`dateModif`),
  ADD KEY `seances_profs_non_comptabilisees_ibfk_1` (`codeSeance`),
  ADD KEY `seances_profs_non_comptabilisees_ibfk_2` (`codeRessource`),
  ADD KEY `seances_profs_non_comptabilisees_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_profs_payees`
--
ALTER TABLE `seances_profs_payees`
  ADD KEY `seances_profs_payees_del` (`deleted`),
  ADD KEY `seances_profs_payees_dateModif` (`dateModif`),
  ADD KEY `seances_profs_payees_ibfk_1` (`codeSeance`),
  ADD KEY `seances_profs_payees_ibfk_2` (`codeRessource`),
  ADD KEY `seances_profs_payees_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `seances_salles`
--
ALTER TABLE `seances_salles`
  ADD KEY `seances_salles_del` (`deleted`),
  ADD KEY `seances_salles_dateModif` (`dateModif`),
  ADD KEY `seances_salles_ibfk_1` (`codeSeance`),
  ADD KEY `seances_salles_ibfk_2` (`codeRessource`),
  ADD KEY `seances_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `typage_materiels`
--
ALTER TABLE `typage_materiels`
  ADD KEY `typage_materiels_del` (`deleted`),
  ADD KEY `typage_materiels_dateModif` (`dateModif`),
  ADD KEY `typage_materiels_ibfk_1` (`codeType`),
  ADD KEY `typage_materiels_ibfk_2` (`codeMateriel`),
  ADD KEY `typage_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `typage_salles`
--
ALTER TABLE `typage_salles`
  ADD KEY `typage_salles_del` (`deleted`),
  ADD KEY `typage_salles_dateModif` (`dateModif`),
  ADD KEY `typage_salles_ibfk_1` (`codeType`),
  ADD KEY `typage_salles_ibfk_2` (`codeSalle`),
  ADD KEY `typage_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `types_activites`
--
ALTER TABLE `types_activites`
  ADD PRIMARY KEY (`codeTypeActivite`),
  ADD KEY `types_activites_dateModif` (`dateModif`),
  ADD KEY `types_activites_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `types_materiels`
--
ALTER TABLE `types_materiels`
  ADD PRIMARY KEY (`codeTypeMateriel`),
  ADD KEY `types_materiels_del` (`deleted`),
  ADD KEY `types_materiels_dateModif` (`dateModif`),
  ADD KEY `types_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `types_salles`
--
ALTER TABLE `types_salles`
  ADD PRIMARY KEY (`codeTypeSalle`),
  ADD KEY `types_salles_del` (`deleted`),
  ADD KEY `types_salles_dateModif` (`dateModif`),
  ADD KEY `types_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`codeUtilisateur`),
  ADD KEY `utilisateurs_ibfk_3` (`codeProprietaire`),
  ADD KEY `utilisateurs_del` (`deleted`),
  ADD KEY `utilisateurs_cdProprietaire` (`codeProprietaire`),
  ADD KEY `utilisateurs_dateModif` (`dateModif`),
  ADD KEY `utilisateurs_ibfk_2` (`codeComposante`);

--
-- Index pour la table `utilisateurs_actions`
--
ALTER TABLE `utilisateurs_actions`
  ADD PRIMARY KEY (`codeAction`),
  ADD KEY `utilisateurs_actions_del` (`deleted`),
  ADD KEY `utilisateurs_actions_ibfk_2` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_appartenances_groupes`
--
ALTER TABLE `utilisateurs_appartenances_groupes`
  ADD KEY `utilisateurs_appartenances_groupes_util` (`codeUtilisateur`),
  ADD KEY `utilisateurs_appartenances_groupes_grutil` (`codeGroupeUtilisateurs`),
  ADD KEY `utilisateurs_appartenances_groupes_del` (`deleted`);

--
-- Index pour la table `utilisateurs_calendriers_enseignements`
--
ALTER TABLE `utilisateurs_calendriers_enseignements`
  ADD KEY `utilisateurs_calendriers_enseignements_ibfk_1` (`codeRessource`),
  ADD KEY `utilisateurs_calendriers_enseignements_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_calendriers_groupes`
--
ALTER TABLE `utilisateurs_calendriers_groupes`
  ADD KEY `utilisateurs_calendriers_groupes_ibfk_1` (`codeRessource`),
  ADD KEY `utilisateurs_calendriers_groupes_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_calendriers_materiels`
--
ALTER TABLE `utilisateurs_calendriers_materiels`
  ADD KEY `utilisateurs_calendriers_materiels_ibfk_1` (`codeRessource`),
  ADD KEY `utilisateurs_calendriers_materiels_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_calendriers_profs`
--
ALTER TABLE `utilisateurs_calendriers_profs`
  ADD KEY `utilisateurs_calendriers_profs_ibfk_1` (`codeRessource`),
  ADD KEY `utilisateurs_calendriers_profs_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_calendriers_salles`
--
ALTER TABLE `utilisateurs_calendriers_salles`
  ADD KEY `utilisateurs_calendriers_salles_ibfk_1` (`codeRessource`),
  ADD KEY `utilisateurs_calendriers_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_composantes`
--
ALTER TABLE `utilisateurs_composantes`
  ADD KEY `utilisateurs_composantes_del` (`deleted`),
  ADD KEY `utilisateurs_composantes_ibfk_1` (`codeComposante`),
  ADD KEY `utilisateurs_composantes_ibfk_3` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_composantes_defaut`
--
ALTER TABLE `utilisateurs_composantes_defaut`
  ADD KEY `utilisateurs_composantes_defaut_del` (`deleted`),
  ADD KEY `utilisateurs_composantes_defaut_ibfk_1` (`codeComposante`),
  ADD KEY `utilisateurs_composantes_defaut_ibfk_3` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_connexions`
--
ALTER TABLE `utilisateurs_connexions`
  ADD PRIMARY KEY (`numeroSession`),
  ADD KEY `utilisateurs_connexions_ibfk_3` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_domaines`
--
ALTER TABLE `utilisateurs_domaines`
  ADD PRIMARY KEY (`codeDomaine`),
  ADD KEY `utilisateurs_domaines_del` (`deleted`),
  ADD KEY `utilisateurs_domaines_cddom` (`codeDomaine`);

--
-- Index pour la table `utilisateurs_domaines_groupes`
--
ALTER TABLE `utilisateurs_domaines_groupes`
  ADD KEY `utilisateurs_domaines_groupes_del` (`deleted`),
  ADD KEY `utilisateurs_domaines_groupes_ibfk_2` (`codeDomaine`),
  ADD KEY `utilisateurs_domaines_groupes_ibfk_3` (`codeGroupeUtilisateurs`);

--
-- Index pour la table `utilisateurs_filtrages`
--
ALTER TABLE `utilisateurs_filtrages`
  ADD PRIMARY KEY (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `utilisateurs_filtrages_composantes`
--
ALTER TABLE `utilisateurs_filtrages_composantes`
  ADD KEY `utilisateurs_filtrages_composantes_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_composantes_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_composantes_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_composantes_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_diplomes`
--
ALTER TABLE `utilisateurs_filtrages_diplomes`
  ADD KEY `utilisateurs_filtrages_diplomes_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_diplomes_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_diplomes_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_diplomes_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_enseignements`
--
ALTER TABLE `utilisateurs_filtrages_enseignements`
  ADD KEY `utilisateurs_filtrages_enseignements_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_enseignements_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_enseignements_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_enseignements_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_etudiants`
--
ALTER TABLE `utilisateurs_filtrages_etudiants`
  ADD KEY `utilisateurs_filtrages_etudiants_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_etudiants_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_etudiants_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_etudiants_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_groupes`
--
ALTER TABLE `utilisateurs_filtrages_groupes`
  ADD KEY `utilisateurs_filtrages_groupes_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_groupes_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_groupes_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_groupes_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_materiels`
--
ALTER TABLE `utilisateurs_filtrages_materiels`
  ADD KEY `utilisateurs_filtrages_materiels_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_materiels_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_materiels_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_materiels_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_matieres`
--
ALTER TABLE `utilisateurs_filtrages_matieres`
  ADD KEY `utilisateurs_filtrages_matieres_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_matieres_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_matieres_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_matieres_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_profs`
--
ALTER TABLE `utilisateurs_filtrages_profs`
  ADD KEY `utilisateurs_filtrages_profs_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_profs_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_profs_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_profs_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_filtrages_salles`
--
ALTER TABLE `utilisateurs_filtrages_salles`
  ADD KEY `utilisateurs_filtrages_salles_del` (`deleted`),
  ADD KEY `utilisateurs_filtrages_salles_ibfk_1` (`codeFiltrage`),
  ADD KEY `utilisateurs_filtrages_salles_ibfk_2` (`codeProprietaire`),
  ADD KEY `utilisateurs_filtrages_salles_ibfk_3` (`codeRessource`);

--
-- Index pour la table `utilisateurs_groupes`
--
ALTER TABLE `utilisateurs_groupes`
  ADD PRIMARY KEY (`codeGroupeUtilisateurs`),
  ADD KEY `utilisateurs_groupes_del` (`deleted`),
  ADD KEY `utilisateurs_groupes_grutil` (`codeGroupeUtilisateurs`);

--
-- Index pour la table `utilisateurs_groupeutilisateurs_droits`
--
ALTER TABLE `utilisateurs_groupeutilisateurs_droits`
  ADD KEY `utilisateurs_groupeutilisateurs_droits_del` (`deleted`),
  ADD KEY `utilisateurs_groupeutilisateurs_droits_ibfk_2` (`codeUtilisateur`),
  ADD KEY `utilisateurs_groupeutilisateurs_droits_ibfk_3` (`codeGroupeUtilisateurs`);

--
-- Index pour la table `utilisateurs_messages`
--
ALTER TABLE `utilisateurs_messages`
  ADD PRIMARY KEY (`codeMessage`);

--
-- Index pour la table `utilisateurs_messages_lectures`
--
ALTER TABLE `utilisateurs_messages_lectures`
  ADD KEY `idx_codePropLect` (`codeProprietaireLecteur`);

--
-- Index pour la table `utilisateurs_numeros_commandes`
--
ALTER TABLE `utilisateurs_numeros_commandes`
  ADD PRIMARY KEY (`numeroCommande`),
  ADD KEY `utilisateurs_numeros_commandes_del` (`deleted`),
  ADD KEY `utilisateurs_numeros_commandes_ibfk_2` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_parametres`
--
ALTER TABLE `utilisateurs_parametres`
  ADD KEY `utilisateurs_parametres_ibfk_2` (`codeUtilisateur`);

--
-- Index pour la table `utilisateurs_synchronisations`
--
ALTER TABLE `utilisateurs_synchronisations`
  ADD KEY `utilisateurs_synchronisations_ibfk_2` (`codeUtilisateur`);

--
-- Index pour la table `vacances`
--
ALTER TABLE `vacances`
  ADD PRIMARY KEY (`date`);

--
-- Index pour la table `zones_salles`
--
ALTER TABLE `zones_salles`
  ADD PRIMARY KEY (`codeZoneSalle`),
  ADD KEY `zones_salles_del` (`deleted`),
  ADD KEY `zones_salles_dateModif` (`dateModif`),
  ADD KEY `zones_salles_ibfk_3` (`codeProprietaire`);

--
-- Index pour la table `zones_temps`
--
ALTER TABLE `zones_temps`
  ADD KEY `zones_temps_del` (`deleted`),
  ADD KEY `zones_temps_dateModif` (`dateModif`),
  ADD KEY `zones_temps_ibfk_1` (`codeZoneSalle1`),
  ADD KEY `zones_temps_ibfk_2` (`codeZoneSalle2`),
  ADD KEY `zones_temps_ibfk_3` (`codeProprietaire`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `absences_etudiants`
--
ALTER TABLE `absences_etudiants`
  MODIFY `codeAbsence` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `absences_justifications`
--
ALTER TABLE `absences_justifications`
  MODIFY `codeJustification` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT pour la table `absences_periodes_etudiants`
--
ALTER TABLE `absences_periodes_etudiants`
  MODIFY `codeAbsence` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=916;

--
-- AUTO_INCREMENT pour la table `absences_periodes_profs`
--
ALTER TABLE `absences_periodes_profs`
  MODIFY `codeAbsence` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=916;

--
-- AUTO_INCREMENT pour la table `absences_profs`
--
ALTER TABLE `absences_profs`
  MODIFY `codeAbsence` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `absences_validations`
--
ALTER TABLE `absences_validations`
  MODIFY `codeValidation` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `bilans_profs_archives`
--
ALTER TABLE `bilans_profs_archives`
  MODIFY `numeroBilan` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_enseignements`
--
ALTER TABLE `calendriers_enseignements`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_filieres`
--
ALTER TABLE `calendriers_filieres`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_groupes`
--
ALTER TABLE `calendriers_groupes`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_materiels`
--
ALTER TABLE `calendriers_materiels`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_profs`
--
ALTER TABLE `calendriers_profs`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `calendriers_salles`
--
ALTER TABLE `calendriers_salles`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `cnu`
--
ALTER TABLE `cnu`
  MODIFY `codeCNU` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT pour la table `composantes`
--
ALTER TABLE `composantes`
  MODIFY `codeComposante` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `compteur`
--
ALTER TABLE `compteur`
  MODIFY `id_compteur` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `diplomes`
--
ALTER TABLE `diplomes`
  MODIFY `codeDiplome` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `disciplines`
--
ALTER TABLE `disciplines`
  MODIFY `codeDiscipline` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `enseignements`
--
ALTER TABLE `enseignements`
  MODIFY `codeEnseignement` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `filieres`
--
ALTER TABLE `filieres`
  MODIFY `codeFiliere` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `grades`
--
ALTER TABLE `grades`
  MODIFY `codeGrade` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12434178;

--
-- AUTO_INCREMENT pour la table `hierarchies_composantes`
--
ALTER TABLE `hierarchies_composantes`
  MODIFY `code` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `hierarchies_groupes`
--
ALTER TABLE `hierarchies_groupes`
  MODIFY `code` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `historique`
--
ALTER TABLE `historique`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `lignes_budgetaires`
--
ALTER TABLE `lignes_budgetaires`
  MODIFY `codeLigneBudgetaire` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `matieres`
--
ALTER TABLE `matieres`
  MODIFY `codeMatiere` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `niveaux`
--
ALTER TABLE `niveaux`
  MODIFY `codeNiveau` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `periodes`
--
ALTER TABLE `periodes`
  MODIFY `codePeriode` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16124526;

--
-- AUTO_INCREMENT pour la table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `codeReservation` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_etudiants`
--
ALTER TABLE `ressources_etudiants`
  MODIFY `codeEtudiant` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_groupes`
--
ALTER TABLE `ressources_groupes`
  MODIFY `codeGroupe` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_groupes_etudiants`
--
ALTER TABLE `ressources_groupes_etudiants`
  MODIFY `code` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_materiels`
--
ALTER TABLE `ressources_materiels`
  MODIFY `codeMateriel` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_profs`
--
ALTER TABLE `ressources_profs`
  MODIFY `codeProf` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ressources_salles`
--
ALTER TABLE `ressources_salles`
  MODIFY `codeSalle` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `seances`
--
ALTER TABLE `seances`
  MODIFY `codeSeance` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `types_activites`
--
ALTER TABLE `types_activites`
  MODIFY `codeTypeActivite` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `types_materiels`
--
ALTER TABLE `types_materiels`
  MODIFY `codeTypeMateriel` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `types_salles`
--
ALTER TABLE `types_salles`
  MODIFY `codeTypeSalle` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `codeUtilisateur` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_actions`
--
ALTER TABLE `utilisateurs_actions`
  MODIFY `codeAction` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_connexions`
--
ALTER TABLE `utilisateurs_connexions`
  MODIFY `numeroSession` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_domaines`
--
ALTER TABLE `utilisateurs_domaines`
  MODIFY `codeDomaine` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_filtrages`
--
ALTER TABLE `utilisateurs_filtrages`
  MODIFY `codeFiltrage` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_groupes`
--
ALTER TABLE `utilisateurs_groupes`
  MODIFY `codeGroupeUtilisateurs` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_messages`
--
ALTER TABLE `utilisateurs_messages`
  MODIFY `codeMessage` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs_numeros_commandes`
--
ALTER TABLE `utilisateurs_numeros_commandes`
  MODIFY `numeroCommande` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `zones_salles`
--
ALTER TABLE `zones_salles`
  MODIFY `codeZoneSalle` int NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `absences_etudiants`
--
ALTER TABLE `absences_etudiants`
  ADD CONSTRAINT `absences_etudiants_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  ADD CONSTRAINT `absences_etudiants_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `absences_profs`
--
ALTER TABLE `absences_profs`
  ADD CONSTRAINT `absences_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `absences_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `absences_profs_ibfk_3` FOREIGN KEY (`codeJustification`) REFERENCES `absences_justifications` (`codeJustification`);

--
-- Contraintes pour la table `absences_validations`
--
ALTER TABLE `absences_validations`
  ADD CONSTRAINT `absences_validations_ibfk_1` FOREIGN KEY (`codeProf`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `absences_validations_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_commentaires`
--
ALTER TABLE `calendriers_commentaires`
  ADD CONSTRAINT `calendriers_commentaires_ibfk_1` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_enseignements`
--
ALTER TABLE `calendriers_enseignements`
  ADD CONSTRAINT `calendriers_enseignements_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `calendriers_enseignements_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_filieres`
--
ALTER TABLE `calendriers_filieres`
  ADD CONSTRAINT `calendriers_filieres_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `filieres` (`codeFiliere`),
  ADD CONSTRAINT `calendriers_filieres_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_groupes`
--
ALTER TABLE `calendriers_groupes`
  ADD CONSTRAINT `calendriers_groupes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `calendriers_groupes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_materiels`
--
ALTER TABLE `calendriers_materiels`
  ADD CONSTRAINT `calendriers_materiels_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `calendriers_materiels_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_profs`
--
ALTER TABLE `calendriers_profs`
  ADD CONSTRAINT `calendriers_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `calendriers_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `calendriers_salles`
--
ALTER TABLE `calendriers_salles`
  ADD CONSTRAINT `calendriers_salles_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `calendriers_salles_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `cnu`
--
ALTER TABLE `cnu`
  ADD CONSTRAINT `cnu_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `composantes`
--
ALTER TABLE `composantes`
  ADD CONSTRAINT `composantes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `composantes_directeurs`
--
ALTER TABLE `composantes_directeurs`
  ADD CONSTRAINT `composantes_directeurs_ibfk_1` FOREIGN KEY (`codeDirecteur`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `composantes_directeurs_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `composantes_directeurs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `diplomes`
--
ALTER TABLE `diplomes`
  ADD CONSTRAINT `diplomes_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `diplomes_ibfk_4` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `disciplines`
--
ALTER TABLE `disciplines`
  ADD CONSTRAINT `disciplines_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `disciplines_profs`
--
ALTER TABLE `disciplines_profs`
  ADD CONSTRAINT `disciplines_profs_ibfk_1` FOREIGN KEY (`codeDiscipline`) REFERENCES `disciplines` (`codeDiscipline`),
  ADD CONSTRAINT `disciplines_profs_ibfk_2` FOREIGN KEY (`codeProf`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `disciplines_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements`
--
ALTER TABLE `enseignements`
  ADD CONSTRAINT `enseignements_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  ADD CONSTRAINT `enseignements_ibfk_4` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  ADD CONSTRAINT `enseignements_ibfk_5` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `enseignements_ibfk_8` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_groupes`
--
ALTER TABLE `enseignements_groupes`
  ADD CONSTRAINT `enseignements_groupes_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `enseignements_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_historique`
--
ALTER TABLE `enseignements_historique`
  ADD CONSTRAINT `enseignements_historique_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  ADD CONSTRAINT `enseignements_historique_ibfk_2` FOREIGN KEY (`codeTypeSalle`) REFERENCES `types_salles` (`codeTypeSalle`),
  ADD CONSTRAINT `enseignements_historique_ibfk_3` FOREIGN KEY (`codeZoneSalle`) REFERENCES `zones_salles` (`codeZoneSalle`),
  ADD CONSTRAINT `enseignements_historique_ibfk_8` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_materiels`
--
ALTER TABLE `enseignements_materiels`
  ADD CONSTRAINT `enseignements_materiels_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `enseignements_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_prerequis`
--
ALTER TABLE `enseignements_prerequis`
  ADD CONSTRAINT `enseignements_prerequis_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_prerequis_ibfk_2` FOREIGN KEY (`codePrerequis`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_prerequis_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_profs`
--
ALTER TABLE `enseignements_profs`
  ADD CONSTRAINT `enseignements_profs_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `enseignements_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_salles`
--
ALTER TABLE `enseignements_salles`
  ADD CONSTRAINT `enseignements_salles_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `enseignements_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_types_materiels`
--
ALTER TABLE `enseignements_types_materiels`
  ADD CONSTRAINT `enseignements_types_materiels_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_types_materiels_ibfk_2` FOREIGN KEY (`codeTypeRessource`) REFERENCES `types_materiels` (`codeTypeMateriel`),
  ADD CONSTRAINT `enseignements_types_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `enseignements_types_salles`
--
ALTER TABLE `enseignements_types_salles`
  ADD CONSTRAINT `enseignements_types_salles_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `enseignements_types_salles_ibfk_2` FOREIGN KEY (`codeTypeRessource`) REFERENCES `types_salles` (`codeTypeSalle`),
  ADD CONSTRAINT `enseignements_types_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `etudiants_diplomes`
--
ALTER TABLE `etudiants_diplomes`
  ADD CONSTRAINT `etudiants_diplomes_ibfk_1` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  ADD CONSTRAINT `etudiants_diplomes_ibfk_2` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  ADD CONSTRAINT `etudiants_diplomes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `grades_ponderations`
--
ALTER TABLE `grades_ponderations`
  ADD CONSTRAINT `grades_ponderations_ibfk_1` FOREIGN KEY (`codeGrade`) REFERENCES `grades` (`codeGrade`),
  ADD CONSTRAINT `grades_ponderations_ibfk_2` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  ADD CONSTRAINT `grades_ponderations_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `hierarchies_composantes`
--
ALTER TABLE `hierarchies_composantes`
  ADD CONSTRAINT `hierarchies_composantes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `hierarchies_composantes_ibfk_2` FOREIGN KEY (`codeRessourceFille`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `hierarchies_composantes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `hierarchies_groupes`
--
ALTER TABLE `hierarchies_groupes`
  ADD CONSTRAINT `hierarchies_groupes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `hierarchies_groupes_ibfk_2` FOREIGN KEY (`codeRessourceFille`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `hierarchies_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `lignes_budgetaires`
--
ALTER TABLE `lignes_budgetaires`
  ADD CONSTRAINT `lignes_budgetaires_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `lignes_budgetaires_enseignements`
--
ALTER TABLE `lignes_budgetaires_enseignements`
  ADD CONSTRAINT `lignes_budgetaires_enseignements_ibfk_1` FOREIGN KEY (`codeLigneBudgetaire`) REFERENCES `lignes_budgetaires` (`codeLigneBudgetaire`),
  ADD CONSTRAINT `lignes_budgetaires_enseignements_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `lignes_budgetaires_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `lignes_budgetaires_groupes`
--
ALTER TABLE `lignes_budgetaires_groupes`
  ADD CONSTRAINT `lignes_budgetaires_groupes_ibfk_1` FOREIGN KEY (`codeLigneBudgetaire`) REFERENCES `lignes_budgetaires` (`codeLigneBudgetaire`),
  ADD CONSTRAINT `lignes_budgetaires_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `lignes_budgetaires_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `matieres`
--
ALTER TABLE `matieres`
  ADD CONSTRAINT `matieres_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `matieres_diplomes`
--
ALTER TABLE `matieres_diplomes`
  ADD CONSTRAINT `matieres_diplomes_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  ADD CONSTRAINT `matieres_diplomes_ibfk_2` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  ADD CONSTRAINT `matieres_diplomes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `matieres_diplomes_durees`
--
ALTER TABLE `matieres_diplomes_durees`
  ADD CONSTRAINT `matieres_diplomes_durees_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  ADD CONSTRAINT `matieres_diplomes_durees_ibfk_2` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  ADD CONSTRAINT `matieres_diplomes_durees_ibfk_3` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  ADD CONSTRAINT `matieres_diplomes_durees_ibfk_4` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `niveaux`
--
ALTER TABLE `niveaux`
  ADD CONSTRAINT `niveaux_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `periodes`
--
ALTER TABLE `periodes`
  ADD CONSTRAINT `periodes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `periodes_dates`
--
ALTER TABLE `periodes_dates`
  ADD CONSTRAINT `periodes_dates_del_ibfk_1` FOREIGN KEY (`codePeriode`) REFERENCES `periodes` (`codePeriode`),
  ADD CONSTRAINT `periodes_dates_del_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_enseignements`
--
ALTER TABLE `reservations_enseignements`
  ADD CONSTRAINT `reservations_enseignements_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_enseignements_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `reservations_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_filieres`
--
ALTER TABLE `reservations_filieres`
  ADD CONSTRAINT `reservations_filieres_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_groupes`
--
ALTER TABLE `reservations_groupes`
  ADD CONSTRAINT `reservations_groupes_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `reservations_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_historique`
--
ALTER TABLE `reservations_historique`
  ADD CONSTRAINT `reservations_historique_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_historique_ibfk_2` FOREIGN KEY (`codeProprietaireModifieur`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `reservations_historique_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_materiels`
--
ALTER TABLE `reservations_materiels`
  ADD CONSTRAINT `reservations_materiels_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `reservations_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_profs`
--
ALTER TABLE `reservations_profs`
  ADD CONSTRAINT `reservations_profs_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `reservations_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `reservations_salles`
--
ALTER TABLE `reservations_salles`
  ADD CONSTRAINT `reservations_salles_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  ADD CONSTRAINT `reservations_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `reservations_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_etudiants`
--
ALTER TABLE `ressources_etudiants`
  ADD CONSTRAINT `ressources_etudiants_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `ressources_etudiants_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_groupes`
--
ALTER TABLE `ressources_groupes`
  ADD CONSTRAINT `ressources_groupes_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `ressources_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_groupes_etudiants`
--
ALTER TABLE `ressources_groupes_etudiants`
  ADD CONSTRAINT `ressources_groupes_etudiants_ibfk_1` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  ADD CONSTRAINT `ressources_groupes_etudiants_ibfk_2` FOREIGN KEY (`codeGroupe`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `ressources_groupes_etudiants_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_groupes_etudiants_exceptions`
--
ALTER TABLE `ressources_groupes_etudiants_exceptions`
  ADD CONSTRAINT `ressources_groupes_etudiants_exceptions_ibfk_1` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  ADD CONSTRAINT `ressources_groupes_etudiants_exceptions_ibfk_2` FOREIGN KEY (`codeGroupe`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `ressources_groupes_etudiants_exceptions_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_materiels`
--
ALTER TABLE `ressources_materiels`
  ADD CONSTRAINT `ressources_materiels_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `ressources_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_profs`
--
ALTER TABLE `ressources_profs`
  ADD CONSTRAINT `ressources_profs_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `ressources_profs_ibfk_2` FOREIGN KEY (`codeGrade`) REFERENCES `grades` (`codeGrade`),
  ADD CONSTRAINT `ressources_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `ressources_salles`
--
ALTER TABLE `ressources_salles`
  ADD CONSTRAINT `ressources_salles_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `ressources_salles_ibfk_2` FOREIGN KEY (`codeZoneSalle`) REFERENCES `zones_salles` (`codeZoneSalle`),
  ADD CONSTRAINT `ressources_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances`
--
ALTER TABLE `seances`
  ADD CONSTRAINT `seances_ibfk_2` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `seances_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_groupes`
--
ALTER TABLE `seances_groupes`
  ADD CONSTRAINT `seances_groupes_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `seances_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_historique`
--
ALTER TABLE `seances_historique`
  ADD CONSTRAINT `seances_historique_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_historique_ibfk_2` FOREIGN KEY (`codeProprietaireModifieur`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `seances_historique_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_materiels`
--
ALTER TABLE `seances_materiels`
  ADD CONSTRAINT `seances_materiels_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `seances_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_profs`
--
ALTER TABLE `seances_profs`
  ADD CONSTRAINT `seances_profs_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `seances_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_profs_non_comptabilisees`
--
ALTER TABLE `seances_profs_non_comptabilisees`
  ADD CONSTRAINT `seances_profs_non_comptabilisees_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_profs_non_comptabilisees_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `seances_profs_non_comptabilisees_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_profs_payees`
--
ALTER TABLE `seances_profs_payees`
  ADD CONSTRAINT `seances_profs_payees_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_profs_payees_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `seances_profs_payees_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `seances_salles`
--
ALTER TABLE `seances_salles`
  ADD CONSTRAINT `seances_salles_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  ADD CONSTRAINT `seances_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `seances_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `typage_materiels`
--
ALTER TABLE `typage_materiels`
  ADD CONSTRAINT `typage_materiels_ibfk_1` FOREIGN KEY (`codeType`) REFERENCES `types_materiels` (`codeTypeMateriel`),
  ADD CONSTRAINT `typage_materiels_ibfk_2` FOREIGN KEY (`codeMateriel`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `typage_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `typage_salles`
--
ALTER TABLE `typage_salles`
  ADD CONSTRAINT `typage_salles_ibfk_1` FOREIGN KEY (`codeType`) REFERENCES `types_salles` (`codeTypeSalle`),
  ADD CONSTRAINT `typage_salles_ibfk_2` FOREIGN KEY (`codeSalle`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `typage_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `types_activites`
--
ALTER TABLE `types_activites`
  ADD CONSTRAINT `types_activites_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `types_materiels`
--
ALTER TABLE `types_materiels`
  ADD CONSTRAINT `types_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `types_salles`
--
ALTER TABLE `types_salles`
  ADD CONSTRAINT `types_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_actions`
--
ALTER TABLE `utilisateurs_actions`
  ADD CONSTRAINT `utilisateurs_actions_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_appartenances_groupes`
--
ALTER TABLE `utilisateurs_appartenances_groupes`
  ADD CONSTRAINT `utilisateurs_appartenances_groupes_ibfk_1` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`),
  ADD CONSTRAINT `utilisateurs_appartenances_groupes_ibfk_2` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`);

--
-- Contraintes pour la table `utilisateurs_calendriers_enseignements`
--
ALTER TABLE `utilisateurs_calendriers_enseignements`
  ADD CONSTRAINT `utilisateurs_calendriers_enseignements_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  ADD CONSTRAINT `utilisateurs_calendriers_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_calendriers_groupes`
--
ALTER TABLE `utilisateurs_calendriers_groupes`
  ADD CONSTRAINT `utilisateurs_calendriers_groupes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  ADD CONSTRAINT `utilisateurs_calendriers_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_calendriers_materiels`
--
ALTER TABLE `utilisateurs_calendriers_materiels`
  ADD CONSTRAINT `utilisateurs_calendriers_materiels_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  ADD CONSTRAINT `utilisateurs_calendriers_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_calendriers_profs`
--
ALTER TABLE `utilisateurs_calendriers_profs`
  ADD CONSTRAINT `utilisateurs_calendriers_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  ADD CONSTRAINT `utilisateurs_calendriers_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_calendriers_salles`
--
ALTER TABLE `utilisateurs_calendriers_salles`
  ADD CONSTRAINT `utilisateurs_calendriers_salles_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  ADD CONSTRAINT `utilisateurs_calendriers_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_composantes`
--
ALTER TABLE `utilisateurs_composantes`
  ADD CONSTRAINT `utilisateurs_composantes_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `utilisateurs_composantes_ibfk_3` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_composantes_defaut`
--
ALTER TABLE `utilisateurs_composantes_defaut`
  ADD CONSTRAINT `utilisateurs_composantes_defaut_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  ADD CONSTRAINT `utilisateurs_composantes_defaut_ibfk_3` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_connexions`
--
ALTER TABLE `utilisateurs_connexions`
  ADD CONSTRAINT `utilisateurs_connexions_ibfk_3` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_domaines_groupes`
--
ALTER TABLE `utilisateurs_domaines_groupes`
  ADD CONSTRAINT `utilisateurs_domaines_groupes_ibfk_2` FOREIGN KEY (`codeDomaine`) REFERENCES `utilisateurs_domaines` (`codeDomaine`),
  ADD CONSTRAINT `utilisateurs_domaines_groupes_ibfk_3` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`);

--
-- Contraintes pour la table `utilisateurs_filtrages`
--
ALTER TABLE `utilisateurs_filtrages`
  ADD CONSTRAINT `utilisateurs_filtrages_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `utilisateurs_filtrages_composantes`
--
ALTER TABLE `utilisateurs_filtrages_composantes`
  ADD CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `composantes` (`codeComposante`);

--
-- Contraintes pour la table `utilisateurs_filtrages_diplomes`
--
ALTER TABLE `utilisateurs_filtrages_diplomes`
  ADD CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `diplomes` (`codeDiplome`);

--
-- Contraintes pour la table `utilisateurs_filtrages_enseignements`
--
ALTER TABLE `utilisateurs_filtrages_enseignements`
  ADD CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`);

--
-- Contraintes pour la table `utilisateurs_filtrages_etudiants`
--
ALTER TABLE `utilisateurs_filtrages_etudiants`
  ADD CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_etudiants` (`codeEtudiant`);

--
-- Contraintes pour la table `utilisateurs_filtrages_groupes`
--
ALTER TABLE `utilisateurs_filtrages_groupes`
  ADD CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`);

--
-- Contraintes pour la table `utilisateurs_filtrages_materiels`
--
ALTER TABLE `utilisateurs_filtrages_materiels`
  ADD CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`);

--
-- Contraintes pour la table `utilisateurs_filtrages_matieres`
--
ALTER TABLE `utilisateurs_filtrages_matieres`
  ADD CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `matieres` (`codeMatiere`);

--
-- Contraintes pour la table `utilisateurs_filtrages_profs`
--
ALTER TABLE `utilisateurs_filtrages_profs`
  ADD CONSTRAINT `utilisateurs_filtrages_profs_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_profs_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`);

--
-- Contraintes pour la table `utilisateurs_filtrages_salles`
--
ALTER TABLE `utilisateurs_filtrages_salles`
  ADD CONSTRAINT `utilisateurs_filtrages_salles_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  ADD CONSTRAINT `utilisateurs_filtrages_salles_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  ADD CONSTRAINT `utilisateurs_filtrages_salles_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`);

--
-- Contraintes pour la table `utilisateurs_groupeutilisateurs_droits`
--
ALTER TABLE `utilisateurs_groupeutilisateurs_droits`
  ADD CONSTRAINT `utilisateurs_groupeutilisateurs_droits_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`),
  ADD CONSTRAINT `utilisateurs_groupeutilisateurs_droits_ibfk_3` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`);

--
-- Contraintes pour la table `utilisateurs_numeros_commandes`
--
ALTER TABLE `utilisateurs_numeros_commandes`
  ADD CONSTRAINT `utilisateurs_numeros_commandes_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_parametres`
--
ALTER TABLE `utilisateurs_parametres`
  ADD CONSTRAINT `utilisateurs_parametres_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `utilisateurs_synchronisations`
--
ALTER TABLE `utilisateurs_synchronisations`
  ADD CONSTRAINT `utilisateurs_synchronisations_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`);

--
-- Contraintes pour la table `zones_salles`
--
ALTER TABLE `zones_salles`
  ADD CONSTRAINT `zones_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);

--
-- Contraintes pour la table `zones_temps`
--
ALTER TABLE `zones_temps`
  ADD CONSTRAINT `zones_temps_ibfk_1` FOREIGN KEY (`codeZoneSalle1`) REFERENCES `zones_salles` (`codeZoneSalle`),
  ADD CONSTRAINT `zones_temps_ibfk_2` FOREIGN KEY (`codeZoneSalle2`) REFERENCES `zones_salles` (`codeZoneSalle`),
  ADD CONSTRAINT `zones_temps_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
