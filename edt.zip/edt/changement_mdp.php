<?php
error_reporting(E_ALL);
include("config.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $nom_fenetre; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <?php
        if (isset($_POST['nmotpasse1']) and isset($_POST['nmotpasse2']) and isset($_POST['amotpasse']) and isset($_POST['login']) and $_POST['nmotpasse1'] == $_POST['nmotpasse2']) {
            $login = $_POST['login'];
            $ancien_mot_passe = md5($_POST['amotpasse']);
            $nouveau_mot_passe = md5($_POST['nmotpasse1']);
            $sql = "select * from login_prof where login=:login and motPasse=:ancien_mot_passe";
            $req_login = $dbh->prepare($sql);
            $req_login->execute(array(':login' => $login, ':ancien_mot_passe' => $ancien_mot_passe));
            $res_login = $req_login->fetchAll();
            if (count($res_login) > 0) {
                $sql = "update  login_prof set motPasse=:nouveau_mot_passe WHERE login=:login and motPasse=:ancien_mot_passe";
                $req_login_maj = $dbh->prepare($sql);
                $req_login_maj->execute(array(':login' => $login, ':nouveau_mot_passe' => $nouveau_mot_passe, ':ancien_mot_passe' => $ancien_mot_passe));
                echo '<div class="alert alert-success" role="alert">Mot de passe changé<br>';
                echo '<a href="index.php">Retour à la page d\'accueil</a><br></div><br>';
            } else {
                echo '<div class="alert alert-danger" role="alert">Problème : vous avez fait une erreur de saisie<br>';
                echo '<a href="index.php">Retour à la page d\'accueil</a><br></div><br>';
            }
        } else {
        ?>
        <div class="card">
            <div class="card-body">
                <form action="changement_mdp.php" method="post">
                    <div class="form-group">
                        <label for="login">Login</label>
                        <input type="text" class="form-control" id="login" name="login">
                    </div>
                    <div class="form-group">
                        <label for="amotpasse">Ancien mot de passe</label>
                        <input type="password" class="form-control" id="amotpasse" name="amotpasse">
                    </div>
                    <div class="form-group">
                        <label for="nmotpasse1">Nouveau mot de passe</label>
                        <input type="password" class="form-control" id="nmotpasse1" name="nmotpasse1">
                    </div>
                    <div class="form-group">
                        <label for="nmotpasse2">Retappez votre nouveau mot de passe</label>
                        <input type="password" class="form-control" id="nmotpasse2" name="nmotpasse2">
                    </div>
                    <button type="submit" class="btn btn-primary">Changer de mot de passe !</button>
                </form>
                <br><a href="index.php">Retour à la page d'accueil</a><br>
            </div>
        </div>
        <?php
        }
        ?>
       
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
