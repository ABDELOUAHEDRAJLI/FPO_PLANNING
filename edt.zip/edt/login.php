<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>VT Agenda Login</title>
	<!-- Add Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="login.css"> </head>

<body>
	<div class="container py-5">
		<div class="tx "><h1 class="text-center ">FPO-PLANNING</h1>
		</div>

		<?php
		//message d'erreur des étudiants
		if ($_POST['loginstudent'] != "" && $_POST['logintype'] == "student") {
			echo '<div class="alert alert-danger" role="alert">Login incorrect !</div>';
		} elseif (isset($_POST['loginstudent']) && $_POST['logintype'] == "student") {
			echo '<div class="alert alert-danger" role="alert">Login obligatoire !</div>';
		}
		//message d'erreur des profs
		if (($_POST['loginvrac'] == "" || $_POST['password'] == "") && $_POST['logintype'] == "vrac") {
			echo '<div class="alert alert-danger" role="alert">Login et mot de passe obligatoires !</div>';
		} elseif (isset($_POST['loginvrac']) && isset($_POST['password']) && $_POST['logintype'] == "vrac") {
			echo '<div class="alert alert-danger" role="alert">Mauvais login ou mot de passe !</div>';
		}
		?>
		<div class="row">
			<div class="col-md-6">
				<div class="card my-4">
					<div class="card-header">
						<h2 class="mb-0">Etudiants</h2>
					</div>
					<div class="card-body">
						<form action="index.php" method="post"
							onsubmit="document.getElementById('screen_widt').value=window.innerWidth;document.getElementById('screen_heigh').value=window.innerHeight">
							<div class="form-group">
								<label for="loginstudent">Login :</label>
								<input type="text" id="loginstudent" name="loginstudent" class="form-control">
							</div>
							<div class="form-check">
								<input type="checkbox" id="cookieetudiant" name="cookieetudiant"
									class="form-check-input" value="1">
								<label class="form-check-label" for="cookieetudiant">Rester connecté</label>
							</div>
							<input type="hidden" name="larg" id="screen_widt" value="">
							<input type="hidden" name="haut" id="screen_heigh" value="">
							<input type="hidden" name="logintype" value="student">
							<button type="submit" class="btn btn-primary mt-3">Envoyer</button><br>
						</form>
						<a href="aide.pdf">Mode d'emploi</a>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="card my-4">
					<div class="card-header">
						<h2 class="mb-0">Professeurs</h2>
					</div>
					<div class="card-body">
						<form action="index.php" method="post"
							onsubmit="document.getElementById('screen_wi').value=window.innerWidth;document.getElementById('screen_hei').value=window.innerHeight">
							<div class="form-group">
								<label for="loginvrac">Login :</label>
								<input type="text" id="loginvrac" name="loginvrac" class="form-control">
							</div>
							<div class="form-group">
								<label for="password">Mot de passe :</label>
								<input type="password" id="password" name="password" class="form-control">
							</div>
							<div class="form-check">
								<input type="checkbox" id="cookieprof" name="cookieprof" class="form-check-input"
									value="1">
								<label class="form-check-label" for="cookieprof">Rester connecté</label> <br>
							</div>
							<input type="hidden" name="larg" id="screen_wi" value="">
							<input type="hidden" name="haut" id="screen_hei" value="">
							<input type="hidden" name="logintype" value="vrac">
							<button type="submit" class="btn btn-primary mt-3">Envoyer</button>
						</form>
						<br><a href="changement_mdp.php">Changer de mot de passe</a><br>
						<a href="aide.pdf">Mode d'emploi</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Add Bootstrap JS -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>