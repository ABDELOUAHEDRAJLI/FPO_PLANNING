<?php

session_start();

include("config.php");
error_reporting(E_ALL);


//recuperation du code du prof concerné
	if(isset($_SESSION['logged_prof_perso']))
	{
	$codeProf=$_SESSION['logged_prof_perso'];
	}
	else
	{
	$codeProf="";
	}
	
	
//récupération de variables
$horizon=$_GET['horiz'];
$lar=$_GET['lar'];
$hau=$_GET['hau'];
$selec_prof=$_GET['selec_prof'];
$selec_groupe=$_GET['selec_groupe'];
$selec_salle=$_GET['selec_salle'];
$selec_materiel=$_GET['selec_materiel'];
$current_year=$_GET['current_year'];
$current_week=$_GET['current_week'];
if(!isset($_GET['disconnect']))
{
$_GET['disconnect']="";
}


//recupération variables pour savoir si on affiche les séances dans l'ordre chronologique ou trié par matière
if(isset($_GET['chrono']))
	{
	$chrono=$_GET['chrono'];
	}
else
	{
	$chrono='0';
	}


$salles_multi=array();
if (isset ($_GET['salles_multi']))
{
$salles_multi=$_GET['salles_multi'];
}
$groupes_multi=array(); 	
if(isset($_GET['groupes_multi']))
{
 $groupes_multi=$_GET['groupes_multi'];
}
$profs_multi=array(); 	
if(isset($_GET['profs_multi']))
{
 $profs_multi=$_GET['profs_multi'];
}	

$materiels_multi=array(); 	
if(isset($_GET['materiels_multi']))
{
 $materiels_multi=$_GET['materiels_multi'];
}	

if (isset ($_GET['jour']))
{
$jour_jour_j=$_GET['jour'];
}
else 
{
$jour_jour_j=0;
}	

 //création du profs
 $echec=0;
 $type_echec=0;
 

 
 
if (isset($_GET['maj']))
{




if (isset($_GET['nom']))
{
	if ($_GET['nom']!="")
	{
$nom=trim(strtoupper($_GET['nom']));
	}
	else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['prenom']))
{
		if ($_GET['prenom']!="")
	{
$prenom=trim(strtoupper($_GET['prenom']));
	}
	else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['prenom2']))
{
$prenom2=trim(strtoupper($_GET['prenom2']));
}
else
{
$prenom2=null;
}

if (isset($_GET['identifiant']))
{
		if ($_GET['identifiant']!="" && ctype_digit($_GET['identifiant']))
	{
$identifiant=trim($_GET['identifiant']);
	}
	else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['identifiant_national']))
{
$identifiant_national=trim($_GET['identifiant_national']);
}
else
{
$identifiant_national=null;
}

if (isset($_GET['sexe']))
{
$sexe=$_GET['sexe'];
}
else
{
$sexe=0;
}

if (isset($_GET['composante']))
{
		if ($_GET['composante']!="")
	{
$composante=$_GET['composante'];
	}
	else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['grade']))
{
		if ($_GET['grade']!="")
	{
$grade=$_GET['grade'];
	}
	else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['titulaire']))
{
$titulaire=$_GET['titulaire'];
}
else
{
	$titulaire=0;
}


if (isset($_GET['vol_specifique']))
{
$vol_specifique=$_GET['vol_specifique'];
}
else
{
	$vol_specifique=0;
}

if (isset($_GET['vol_horaire_specifique_heure']))
{
$vol_horaire_specifique_heure=$_GET['vol_horaire_specifique_heure'];
}
else
{
	$vol_horaire_specifique_heure=0;
}

if (isset($_GET['vol_horaire_specifique_min']))
{
$vol_horaire_specifique_min=$_GET['vol_horaire_specifique_min'];
}
else
{
	$vol_horaire_specifique_min=0;
}

if (isset($_GET['vol_horaire_complementaire_heure']))
{
$vol_horaire_complementaire_heure=$_GET['vol_horaire_complementaire_heure'];
}
else
{
	$vol_horaire_complementaire_heure=0;
}

if (isset($_GET['vol_horaire_complementaire_min']))
{
$vol_horaire_complementaire_min=$_GET['vol_horaire_complementaire_min'];
}
else
{
	$vol_horaire_complementaire_min=0;
}





if (isset($_GET['cnu']))
{
$cnu=$_GET['cnu'];
}
else
{
	$cnu=0;
}


if (isset($_GET['naissance']))
{
$naissance=$_GET['naissance'];
}
else
{
	$naissance="1982-01-01";
}

if (isset($_GET['debut_contrat']))
{
$debut_contrat=$_GET['debut_contrat'];
}
else
{
	$debut_contrat="2023-01-01";
}

if (isset($_GET['fin_contrat']))
{
$fin_contrat=$_GET['fin_contrat'];
}
else
{
	$fin_contrat="2040-01-01";
}

if (isset($_GET['validation_dossier']))
{
$validation_dossier=$_GET['validation_dossier'];
}
else
{
	$validation_dossier="2023-01-01";
}




if (isset($_GET['proprietaire']))
{
		if ($_GET['proprietaire']!="")
	{
$proprietaire=$_GET['proprietaire'];
}
else
{
	$echec=1;
}
}
else
{
	$echec=1;
}

if (isset($_GET['couleur_fond']))
{
	//j'enlève le # du début
$couleur_fond=substr($_GET['couleur_fond'],1);
	//la couleur dans VT est codée à l'envers.	
$couleur_fond =  substr($couleur_fond,-2,2). substr($couleur_fond,-4,2).substr($couleur_fond,-6,2);	
$couleur_fond=hexdec($couleur_fond);


}
else
{
	$couleur_fond=16777215;
}

if (isset($_GET['couleur_police']))
{
	//j'enlève le # du début
$couleur_police=substr($_GET['couleur_police'],1);
	//la couleur dans VT est codée à l'envers.	
$couleur_police =  substr($couleur_police,-2,2). substr($couleur_police,-4,2).substr($couleur_police,-6,2);	
$couleur_police=hexdec($couleur_police);	

}
else
{
	$couleur_police=0;
}

if (isset($_GET['numero']))
{
		if (ctype_digit($_GET['numero']))
	{
$numero=$_GET['numero'];
	}
	else
{
$numero=0;
}
}
else
{
$numero=0;
}

if (isset($_GET['rue']))
{
$rue=trim(strtoupper($_GET['rue']));
}
else
{
$rue=null;
}

if (isset($_GET['cp']))
{
	if (ctype_digit($_GET['cp']))
	{
$cp=$_GET['cp'];
	}
	else
{
$cp=0;
}
}
else
{
$cp=0;
}

if (isset($_GET['ville']))
{
$ville=trim(strtoupper($_GET['ville']));
}
else
{
$ville=null;
}

if (isset($_GET['pays']))
{
$pays=trim(strtoupper($_GET['pays']));
}
else
{
$pays=null;
}

if (isset($_GET['tel1']))
{
		if (ctype_digit($_GET['tel1']))
	{
$tel1=trim($_GET['tel1']);
	}
	else
{
$tel1=0;
}
}
else
{
$tel1=0;
}

if (isset($_GET['tel2']))
{
		if (ctype_digit($_GET['tel2']))
	{
$tel2=trim($_GET['tel2']);
	}
	else
{
$tel2=0;
}
}
else
{
$tel2=0;
}

if (isset($_GET['email']))
{
$email=trim($_GET['email']);
}
else
{
$email=null;
}

//test si prof existe déjà
//même identifiant
if (isset($identifiant))
	{
	$sql="SELECT * FROM ressources_profs WHERE deleted='0' and identifiant=:identifiant";
	$req_identifiant_test=$dbh->prepare($sql);
	$req_identifiant_test->execute(array(':identifiant'=>$identifiant));
	$res_identifiant_test=$req_identifiant_test->fetchAll();
	foreach ($res_identifiant_test as $identifiant_test)
		{
		if ($identifiant_test['identifiant']==$identifiant)
			{
			$echec=1;
			$type_echec=1;
			}
		}
	}
else
	{
	$echec=1;	
	}
//test si prof existe déjà
//même nom et même prénom	
if (isset($nom) && isset($prenom))
	{
	$sql="SELECT * FROM ressources_profs WHERE deleted='0' and nom=:nom and prenom=:prenom";
	$req_nom_prenom_test=$dbh->prepare($sql);
	$req_nom_prenom_test->execute(array(':nom'=>$nom,':prenom'=>$prenom));
	$res_nom_prenom_test=$req_nom_prenom_test->fetchAll();
	foreach ($res_nom_prenom_test as $nom_prenom_test)
		{
		if ($nom_prenom_test['nom']==$nom  && $nom_prenom_test['prenom']==$prenom)
			{
			$echec=1;
			$type_echec=2;
			}
		}
	}
else
	{
	$echec=1;	
	}	
	
	

if ($echec==0)
{
//création de l'alias`
$alias=$nom.substr($prenom,0,1);
$alias = str_replace( array( '%','_','-',',', '@', '\'', ';', '<', '>' ), ' ', $alias);
$alias=strtoupper($alias);	
//transformation des volumes horaires en minutes
$vol_horaire_statutaire=$vol_horaire_specifique_heure*60+$vol_horaire_specifique_min;
$vol_horaire_complementaire=$vol_horaire_complementaire_heure*60+$vol_horaire_complementaire_min;


$sql="INSERT INTO `ressources_profs` (`codeProf`, `couleurFond`, `couleurPolice`, `nom`, `prenom`, `codeGrade`, `numero`, `rue`, `codePostal`, `ville`, `pays`, `telephone1`, `telephone2`, `codeCnu`, `alias`, `dateModif`, `deleted`, `identifiant`, `codeProprietaire`, `email`, `dateCreation`, `commentaire`, `codeComposante`, `titulaire`, `dateValidationDossier`, `volStatSpecif`, `volCompSpecif`, `identifiantNational`, `prenom2`, `dateNaissance`, `dateDebutContrat`, `dateFinContrat`, `sexe`, `volSpecif`) VALUES (NULL, :couleur_fond, :couleur_police, :nom, :prenom, :grade, :numero, :rue, :cp, :ville, :pays, :tel1, :tel2, :cnu, :alias, CURRENT_TIMESTAMP, '0', :identifiant, :proprietaire, :email, CURRENT_TIMESTAMP, '', :composante, :titulaire,:validation_dossier, :vol_horaire_statutaire, :vol_horaire_complementaire, :identifiant_national, :prenom2, :naissance, :debut_contrat, :fin_contrat, :sexe, :vol_specifique)"; 

	$req_ajout_prof=$dbh->prepare($sql);
	$req_ajout_prof->execute(array(':nom'=>$nom,':prenom'=>$prenom,':prenom2'=>$prenom2,':couleur_fond'=>$couleur_fond,':couleur_police'=>$couleur_police,':grade'=>$grade,':numero'=>$numero,':rue'=>$rue,':cp'=>$cp,':ville'=>$ville,':pays'=>$pays,':tel1'=>$tel1,':tel2'=>$tel2,':cnu'=>$cnu,':alias'=>$alias,':identifiant'=>$identifiant,':proprietaire'=>$proprietaire,':email'=>$email,':composante'=>$composante,':titulaire'=>$titulaire,':identifiant_national'=>$identifiant_national,':sexe'=>$sexe,':debut_contrat'=>$debut_contrat,':fin_contrat'=>$fin_contrat,':validation_dossier'=>$validation_dossier,':naissance'=>$naissance,':vol_horaire_statutaire'=>$vol_horaire_statutaire,':vol_horaire_complementaire'=>$vol_horaire_complementaire,':vol_specifique'=>$vol_specifique));

}	
	

	
}








?>


<?php
if ((stristr($_SERVER['HTTP_USER_AGENT'], "iPhone") || strpos($_SERVER['HTTP_USER_AGENT'], "iPod") || stristr($_SERVER['HTTP_USER_AGENT'], "Mini")  || stristr($_SERVER['HTTP_USER_AGENT'], "Sony")  || stristr($_SERVER['HTTP_USER_AGENT'], "Nokia")  || stristr($_SERVER['HTTP_USER_AGENT'], "BlackBerry")  || stristr($_SERVER['HTTP_USER_AGENT'], "HTC")  || stristr($_SERVER['HTTP_USER_AGENT'], "Android")   || stristr($_SERVER['HTTP_USER_AGENT'], "MOT")  || stristr($_SERVER['HTTP_USER_AGENT'], "SGH")    ) ) 
{ 
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">';
}
else
{
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> ';
}
?>




<html>

<head>
<link rel="stylesheet" media="all" type="text/css" href="menu/hover_drop_2.css">

<script src="menu/iefix.js" type="text/javascript"></script>
<link rel="icon" type="image/x-icon" href="favicon.png" >

<title><?php echo $nom_fenetre; ?></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 


<?php
if (stristr($_SERVER['HTTP_USER_AGENT'], "iPhone")  
|| strpos($_SERVER['HTTP_USER_AGENT'], "iPod")) { 
 echo '<meta name="viewport" content="initial-scale=1.0">';
} 
?>
<link rel="stylesheet" href="css/ma_config.css" type="text/css" >


</head>

<body  style="margin: 0px;">
<?php

if (isset($_SESSION['logged_prof_perso']))
{
if ($_SESSION['logged_prof_perso']!='')
{
//bandeau du haut
//outils qu'il est possible d'afficher
$afficher_admin=1;
$afficher_ajouter_prof=0;
$afficher_mes_modules=1;
$afficher_mes_droits=1;
$afficher_mes_heures=1;
$afficher_bilan_par_formation=1;
$afficher_ose=1;
$afficher_flux_rss=1;
$afficher_ma_config=1;
$afficher_occupation_des_salles=1;
$afficher_dialogue=1;
$nom_de_la_fenetre="Ajouter des profs";
include('menu_outil.php');
	
?>


<div style="text-align:center;width:100%;">





<form name="form2" id="form2" action="index.php" method="get" >


	
	<input type="hidden" name="lar" id="screen_w" value="<?php echo $lar; ?>">
	<input type="hidden" name="hau" id="screen_hi" value="<?php echo $hau; ?>">
	<input type="hidden" name="selec_prof" id="selec_pr" value="<?php echo $selec_prof; ?>">
	<input type="hidden" name="selec_groupe" id="selec_grou" value="<?php echo $selec_groupe; ?>">
	<input type="hidden" name="selec_salle" id="selec_sa" value="<?php echo $selec_salle; ?>">
		<input type="hidden" name="selec_materiel" id="selec_ma" value="<?php echo $selec_materiel; ?>">
	<input type="hidden" name="current_week" id="current_w" value="<?php echo $current_week; ?>">
	<input type="hidden" name="current_year" id="current_y" value="<?php echo $current_year; ?>">
	<input type="hidden" name="horiz" id="ho" value="<?php echo $horizon; ?>">
	<?php
		for ($i=0; $i<count($groupes_multi); $i++)
		{ 
		echo '<input type="hidden" name="groupes_multi['.$i.']" value="'.$groupes_multi[$i].'">';
		}
		 for ($i=0; $i<count($salles_multi); $i++)
		{ 
		echo '<input type="hidden" name="salles_multi['.$i.']" value="'.$salles_multi[$i].'">';
		}
		 for ($i=0; $i<count($profs_multi); $i++)
		{ 
		echo '<input type="hidden" name="profs_multi['.$i.']" value="'.$profs_multi[$i].'">';
		}
		 for ($i=0; $i<count($materiels_multi); $i++)
		{ 
		echo '<input type="hidden" name="materiels_multi['.$i.']" value="'.$materiels_multi[$i].'">';
		}		
	?>
	<input type="hidden" name="jour" id="jours" value="<?php echo $jour_jour_j; ?>">
	
	 </form><br><br>
	 
	<?php 
if (isset($_GET['maj']))
{	

if ($echec==1)
{
	if($type_echec==0)
	{
?>	
<p style="text-align:center; color:red;"><span style="font-size:12px; font-weight:bold;">ERREUR ! Nom, prénom ou identifiant (numérique) manquant.</span></p>
<?php
	}
	elseif($type_echec==1)
	{
?>	
<p style="text-align:center; color:red;"><span style="font-size:12px; font-weight:bold;">ERREUR ! Un prof ayant le même identifiant existe déjà.</span></p>
<?php		
	}
	elseif($type_echec==2)
	{
?>	
<p style="text-align:center; color:red;"><span style="font-size:12px; font-weight:bold;">ERREUR ! Un prof ayant le même nom et le même prénom existe déjà.</span></p>
<?php		
	}
}
else{	

?>	
<p style="text-align:center; color:blue;"><span style="font-size:12px; font-weight:bold;">Prof ajouté. Vous pouvez retourner à l'emploi du temps.</span></p>
<?php
}
 

}?>	  
	 
<form name="form1" id="form1" action="ajouter_prof.php" method="get" >


		
	<input type="hidden" name="lar" id="scree_w" value="<?php echo $lar; ?>">
	<input type="hidden" name="hau" id="scree_hi" value="<?php echo $hau; ?>">
	<input type="hidden" name="selec_prof" id="selec_p" value="<?php echo $selec_prof; ?>">
	<input type="hidden" name="selec_groupe" id="selec_gro" value="<?php echo $selec_groupe; ?>">
	<input type="hidden" name="selec_salle" id="selec_s" value="<?php echo $selec_salle; ?>">
		<input type="hidden" name="selec_materiel" id="selec_m" value="<?php echo $selec_materiel; ?>">
	<input type="hidden" name="current_week" id="curren_w" value="<?php echo $current_week; ?>">
	<input type="hidden" name="current_year" id="curren_y" value="<?php echo $current_year; ?>">
	<input type="hidden" name="horiz" id="h" value="<?php echo $horizon; ?>">
	<?php
		for ($i=0; $i<count($groupes_multi); $i++)
		{ 
		echo '<input type="hidden" name="groupes_multi['.$i.']" value="'.$groupes_multi[$i].'">';
		}
		 for ($i=0; $i<count($salles_multi); $i++)
		{ 
		echo '<input type="hidden" name="salles_multi['.$i.']" value="'.$salles_multi[$i].'">';
		}
		 for ($i=0; $i<count($profs_multi); $i++)
		{ 
		echo '<input type="hidden" name="profs_multi['.$i.']" value="'.$profs_multi[$i].'">';
		}
		 for ($i=0; $i<count($materiels_multi); $i++)
		{ 
		echo '<input type="hidden" name="materiels_multi['.$i.']" value="'.$materiels_multi[$i].'">';
		}			
	?>
	<p style="text-align:center; color:black;"><span style="font-size:10px; font-weight:bold;">Sélection du prof qui servira de modèle </span></p>
	
	
	<select name="selec_prof_filtre"  class="prof" onchange="document.form1.submit();">


<?php

if (isset($_GET['selec_prof_filtre']))
	{
	$selec_prof_filtre=$_GET['selec_prof_filtre'];
	}
	else{
		$selec_prof_filtre=Null;
	}


$sql="SELECT * FROM composantes WHERE deleted='0' order by nom";




$req_affectation=$dbh->query($sql);
$res_affectations=$req_affectation->fetchAll();
 echo '<option value="TOUS"';
    if ($selec_prof_filtre=="TOUS")
{
        echo " SELECTED";
} 
 echo '>TOUS</option>';
 
foreach ($res_affectations as $res)

    {

	 echo '<option value="'.$res['codeComposante'].'"';
    if ($res['codeComposante']==$selec_prof_filtre)
{
        echo " SELECTED";
}
echo '>'.$res['nom'].'</option>';
	
	
   

   

    }

?>
    </select><br><br>





<select name="prof_modele"  onchange="document.form1.submit();" >





<?php


if (isset($_GET['prof_modele']))
	{
	$prof_modele=$_GET['prof_modele'];
	}
	else{
		$prof_modele=Null;
	}
	


 
	 
if ($selec_prof_filtre!="TOUS" && $selec_prof_filtre!="" )
	{
	

$sql="SELECT * FROM ressources_profs WHERE ressources_profs.deleted='0' and ressources_profs.codeComposante=:selec_prof  ORDER BY ressources_profs.nom,ressources_profs.prenom";


	
	$req_profbis2=$dbh->prepare($sql);
	$req_profbis2->execute(array(':selec_prof'=>$selec_prof_filtre));
	$res_profbis=$req_profbis2->fetchAll();
	}
else
	{
	$sql="SELECT * FROM ressources_profs WHERE ressources_profs.deleted='0' ORDER BY ressources_profs.nom,ressources_profs.prenom";
	$req_profbis2=$dbh->query($sql);
	$res_profbis=$req_profbis2->fetchAll();
	}
	



	
	
	


foreach ($res_profbis as $res)

    {

    echo '<option value="'.$res['codeProf'].'"';

 

	

		if ($res['codeProf']==$prof_modele)

		{

        echo " SELECTED";

		}

	echo '>'.$res['nom'].' '.ucfirst(mb_strtolower($res['prenom'], 'UTF-8')).'</option>

    ';

    }
	
	
	
?>


    </select>	<br><br>	

	 </form><br><br>
<?php
//Récupération des données issu du modèle s'il a été sélectionné.
if (isset($_GET['prof_modele']))
	{
	$prof_modele=$_GET['prof_modele'];
	
$sql="SELECT * FROM ressources_profs WHERE ressources_profs.deleted='0' and ressources_profs.codeProf=:selec_prof  ";
$req_prof_modele=$dbh->prepare($sql);
	$req_prof_modele->execute(array(':selec_prof'=>$prof_modele));
	$res_prof_modele=$req_prof_modele->fetchAll();
foreach ($res_prof_modele as $modele)
{
	$modele_composante=$modele['codeComposante'];
	$modele_grade=$modele['codeGrade'];
	$modele_proprietaire=$modele['codeProprietaire'];
	$modele_couleur_fond=$modele['couleurFond'];
	$modele_couleur_police=$modele['couleurPolice'];
	$modele_titulaire=$modele['titulaire'];
	$modele_sexe=$modele['sexe'];
	$modele_cnu=$modele['codeCnu'];
	$modele_vol_specifique=$modele['volSpecif'];
	$modele_vol_horaire_specifique=$modele['volStatSpecif'];
	$modele_vol_horaire_complementaire=$modele['volCompSpecif'];
	//transformation des volume horaires spécifiques stockés en min en heures et minutes.
$modele_vol_horaire_specifique_heure=intdiv($modele_vol_horaire_specifique,60);
$modele_vol_horaire_specifique_minute=$modele_vol_horaire_specifique%60;
$modele_vol_horaire_complementaire_heure=intdiv($modele_vol_horaire_complementaire,60);
$modele_vol_horaire_complementaire_minute=$modele_vol_horaire_complementaire%60;	
	
	
	
}
	}
	else{
		$modele_composante=null;
		$modele_grade=null;
		$modele_proprietaire=null;
		$modele_couleur_fond=null;
		$modele_couleur_police=null;
		$modele_titulaire=null;
		$modele_sexe=null;
		$modele_cnu=null;
		$modele_vol_specifique=null;
		$modele_vol_horaire_specifique=null;
		$modele_vol_horaire_complementaire=null;
		$modele_vol_horaire_specifique_heure=0;
		$modele_vol_horaire_specifique_minute=0;
		$modele_vol_horaire_complementaire_heure=0;
		$modele_vol_horaire_complementaire_minute=0;	
	}

//transformation des volume horaires spécifiques stockés en min en heures et minutes.
$modele_vol_horaire_specifique_heure=intdiv($modele_vol_horaire_specifique,60);
$modele_vol_horaire_specifique_minute=$modele_vol_horaire_specifique%60;




?>	
	
	<p style="text-align:center; color:black;"><span style="font-size:10px; font-weight:bold;">Données du prof à créer (* = obligatoire) </span></p>	
	
<form name="form3" id="form3" action="ajouter_prof.php" method="get" >


		<input type="hidden" name="maj" id="mise_a_jour" value="1">
	<input type="hidden" name="lar" id="scree_w" value="<?php echo $lar; ?>">
	<input type="hidden" name="hau" id="scree_hi" value="<?php echo $hau; ?>">
	<input type="hidden" name="selec_prof" id="selec_p" value="<?php echo $selec_prof; ?>">
	<input type="hidden" name="selec_groupe" id="selec_gro" value="<?php echo $selec_groupe; ?>">
	<input type="hidden" name="selec_salle" id="selec_s" value="<?php echo $selec_salle; ?>">
		<input type="hidden" name="selec_materiel" id="selec_m" value="<?php echo $selec_materiel; ?>">
	<input type="hidden" name="current_week" id="curren_w" value="<?php echo $current_week; ?>">
	<input type="hidden" name="current_year" id="curren_y" value="<?php echo $current_year; ?>">
	<input type="hidden" name="horiz" id="h" value="<?php echo $horizon; ?>">
	<?php
		for ($i=0; $i<count($groupes_multi); $i++)
		{ 
		echo '<input type="hidden" name="groupes_multi['.$i.']" value="'.$groupes_multi[$i].'">';
		}
		 for ($i=0; $i<count($salles_multi); $i++)
		{ 
		echo '<input type="hidden" name="salles_multi['.$i.']" value="'.$salles_multi[$i].'">';
		}
		 for ($i=0; $i<count($profs_multi); $i++)
		{ 
		echo '<input type="hidden" name="profs_multi['.$i.']" value="'.$profs_multi[$i].'">';
		}
		 for ($i=0; $i<count($materiels_multi); $i++)
		{ 
		echo '<input type="hidden" name="materiels_multi['.$i.']" value="'.$materiels_multi[$i].'">';
		}			
	?>	
	
	
	
Nom du nouveau prof <b>*</b> : <input name="nom" type="text"  maxlength="25"  class="text"  value="" required> <br><br>
Prénom du nouveau prof <b>*</b> : <input name="prenom" type="text"  maxlength="25"  class="text"  value="" required> <br><br>
Deuxième prénom du nouveau prof : <input name="prenom2" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Date de naissance : <input type="date" name="naissance" value="1982-01-01" min="1900-01-01" max="2100-12-31" /> <br><br>


Identifiant <b>*</b> : <input name="identifiant" type="text"  maxlength="25"  class="text"  value="" required> <br><br>
Identifiant national : <input name="identifiant_national" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Sexe : <select name="sexe">
<option value="0" 	<?php if ($modele_sexe==0) echo " SELECTED";?>  >Inconnu</option>
<option value="1" 	<?php if ($modele_sexe==1) echo " SELECTED";?>  >Homme</option>
<option value="2" <?php if ($modele_sexe==2) echo " SELECTED";?>>Femme</option>
</select><br><br>
	
Composante <b>*</b> : <select name="composante">
	
<?php
$sql="SELECT * FROM composantes WHERE deleted='0' order by nom";
$req_composante=$dbh->query($sql);
$res_composantes=$req_composante->fetchAll();
foreach ($res_composantes as $composantes)
{
	
	echo '<option value="'.$composantes['codeComposante'].'"';
	if ($composantes['codeComposante']==$modele_composante)
	{
		echo " SELECTED";
	}
	echo '>'.$composantes['nom'].'</option>'."\n";
}
?>
</select><br><br>

	Grade <b>*</b> : <select name="grade">
	
<?php
$sql="SELECT * FROM grades WHERE deleted='0' order by grade";
$req_grade=$dbh->query($sql);
$res_grades=$req_grade->fetchAll();
foreach ($res_grades as $grades)
{
	echo '<option value="'.$grades['codeGrade'].'"';
	if ($grades['codeGrade']==$modele_grade)
	{
		echo " SELECTED";
	}
	echo '>'.$grades['grade'].'</option>';
}
?>
</select><br><br>


	Titulaire : <input type="checkbox" name="titulaire" value="1" <?php if ($modele_titulaire=='1') echo "checked"; ?> ><br><br>

	Propriétaire <b>*</b> : <select name="proprietaire">
	
<?php
$sql="SELECT * FROM utilisateurs WHERE deleted='0' order by nom";
$req_proprietaire=$dbh->query($sql);
$res_proprietaires=$req_proprietaire->fetchAll();
foreach ($res_proprietaires as $proprietaires)
{
	echo '<option value="'.$proprietaires['codeProprietaire'].'"';
	if ($proprietaires['codeProprietaire']==$modele_proprietaire)
	{
		echo " SELECTED";
	}
	
	echo '>'.$proprietaires['nom']." ".$proprietaires['prenom']." ".$proprietaires['commentaire'].'</option>';
}
?>
</select><br><br>

Section CNU <b>*</b> : <select name="cnu" style="width:300px;">
	
<?php
$sql="SELECT * FROM cnu WHERE deleted='0' order by section";
$req_cnu=$dbh->query($sql);
$res_cnu=$req_cnu->fetchAll();
foreach ($res_cnu as $cnu)
{
	echo '<option value="'.$cnu['codeCNU'].'"';
	if ($cnu['codeCNU']==$modele_cnu)
	{
		echo " SELECTED";
	}
	echo '>'.$cnu['section']." ".$cnu['nom'].'</option>';
}
?>
</select><br><br>
	
Date de début de contrat : <input type="date" name="debut_contrat" value="<?php echo date('Y-m-d'); ?>" /><br><br>
Date de fin de contrat : <input type="date" name="fin_contrat" value="2040-01-01"  /> <br><br>
Date de validation du dossier : <input type="date" name="validation_dossier" value="<?php echo date('Y-m-d'); ?>"  /> <br><br>
Volume horaire spécifique : <input type="number" style="width: 4em" name="vol_horaire_specifique_heure" value="<?php echo $modele_vol_horaire_specifique_heure; ?>"  min="0" max="999" step="1" >heures  <input type="number" style="width: 3em" name="vol_horaire_specifique_min"  min="0" max="59"  value="<?php echo $modele_vol_horaire_specifique_minute; ?>" step="15">min<br><br>
Volume horaire complémentaire spécifique :  <input type="number" style="width: 4em" name="vol_horaire_complementaire_heure" value="<?php echo $modele_vol_horaire_complementaire_heure; ?>" min="0" max="999" step="1" >heures  <input type="number" style="width: 3em" name="vol_horaire_complementaire_min"  min="0" max="59"  value="<?php echo $modele_vol_horaire_complementaire_minute; ?>" step="15">min<br><br>
Prendre en compte le volume horaire spécifique : <input type="checkbox" name="vol_specifique" value="1" <?php if ($modele_vol_specifique=='1') echo "checked"; ?> ><br><br>


	Couleur du fond : 
	

<?php
If (isset($modele_couleur_fond))
{
	
	$dechex=dechex($modele_couleur_fond);

while (strlen($dechex)<6) 
	{
	$dechex = "0".$dechex;
	}
//la couleur dans VT est codée à l'envers.	
$couleur =  substr($dechex,-2,2). substr($dechex,-4,2).substr($dechex,-6,2);		

?>
<input type="color" name="couleur_fond" value="#<?php echo $couleur?>" />	
<?php
}
else
{
	?>
<input type="color" name="couleur_fond" value="#FFFFFF" />	
<?php
}


?>		
	
	
	
</select><br><br>



	


	Couleur de la police : 

<?php
If (isset($modele_couleur_police))
{
	$dechex=dechex($modele_couleur_police);

while (strlen($dechex)<6) 
	{
	$dechex = "0".$dechex;
	}
//la couleur dans VT est codée à l'envers.	
$couleur =  substr($dechex,-2,2). substr($dechex,-4,2).substr($dechex,-6,2);	


?>
<input type="color" name="couleur_police" value="#<?php echo $couleur ?>" />	
<?php
}
else
{
	?>
<input type="color" name="couleur_police" value="#000000" />	
<?php
}


?>	

</select><br><br>
	<p style="text-align:center; color:black;"><span style="font-size:10px; font-weight:bold;">Coordonnées du prof à créer</span></p>
Numéro : <input name="numero" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Rue : <input name="rue" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Code postal : <input name="cp" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Ville : <input name="ville" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Pays : <input name="pays" type="text"  maxlength="25"  class="text"  value=""> <br><br>
Tél 1 : <input name="tel1" type="tel"  pattern="[0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2}" placeholder="01 23 45 67 89"> <br><br>
Tél 2 : <input name="tel2" type="tel"  pattern="[0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2}" placeholder="01 23 45 67 89"> <br><br>
Email : <input name="email" type="email"  maxlength="25"  class="text"  value=""> <br><br>



	<input name="" value="Ajouter le prof" type="submit">
	 </form><br><br>	 

	 
</div>

<?php
}
}
else
{
echo 'Vous avez été déconnecté. Cliquez <a style="color:#0000EE" href="index.php">ICI </a> pour retourner à la page principale ';
}
?>
</body>
</html>


	




