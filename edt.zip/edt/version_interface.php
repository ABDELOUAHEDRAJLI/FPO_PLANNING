<?php

//Version de l'interface web
$version_interface='6.6.3';
?>