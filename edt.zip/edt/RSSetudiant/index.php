<html>
<head>

</head>
<body onload="document.location.href='http://ufrsitec.u-paris10.fr/edtpst'">
	Redirection vers la page d'accueil ....
</body>
</html>