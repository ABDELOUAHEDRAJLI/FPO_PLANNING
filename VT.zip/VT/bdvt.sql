/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50136
Source Host           : localhost:3306
Source Database       : bdvt

Target Server Type    : MYSQL
Target Server Version : 50136
File Encoding         : 65001

Date: 2022-09-10 06:56:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `absences_etudiants`
-- ----------------------------
DROP TABLE IF EXISTS `absences_etudiants`;
CREATE TABLE `absences_etudiants` (
  `codeAbsence` int(11) NOT NULL AUTO_INCREMENT,
  `codeRessource` int(11) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int(5) NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL,
  `codeJustification` int(11) DEFAULT NULL,
  `typeAbsence` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`codeAbsence`),
  KEY `absences_etudiants_del` (`deleted`) USING BTREE,
  KEY `absences_etudiants_dateModif` (`dateModif`) USING BTREE,
  KEY `absences_etudiants_ibfk_2` (`codeProprietaire`) USING BTREE,
  KEY `absences_etudiants_ibfk_1` (`codeRessource`) USING BTREE,
  KEY `absences_etudiants_ibfk_3` (`codeJustification`) USING BTREE,
  CONSTRAINT `absences_etudiants_ibfk_1` FOREIGN KEY (`codeJustification`) REFERENCES `absences_justifications` (`codeJustification`),
  CONSTRAINT `absences_etudiants_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  CONSTRAINT `absences_etudiants_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=97031 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of absences_etudiants
-- ----------------------------

-- ----------------------------
-- Table structure for `absences_justifications`
-- ----------------------------
DROP TABLE IF EXISTS `absences_justifications`;
CREATE TABLE `absences_justifications` (
  `codeJustification` int(11) NOT NULL AUTO_INCREMENT,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `libelle` varchar(250) NOT NULL DEFAULT '',
  `typeJustification` smallint(6) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  PRIMARY KEY (`codeJustification`),
  KEY `absences_justifications_del` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of absences_justifications
-- ----------------------------
INSERT INTO `absences_justifications` VALUES ('2', '307', '0', '2019-07-02 14:40:37', 'congé de maladie', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('3', '307', '0', '2019-07-02 14:40:39', 'congé  de longue maladie ou de longue durée', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('4', '307', '0', '2019-07-02 14:40:40', 'congé de maternité ou d’adoption', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('5', '307', '0', '2019-07-02 14:40:41', ' congé de paternité et d\'accueil de l\'enfant', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('6', '307', '0', '2019-07-02 14:40:42', 'congé de formation professionnelle', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('7', '307', '0', '2019-07-02 14:40:45', 'congé pour validation des acquis de l\'expérience', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('8', '307', '0', '2019-07-02 14:40:46', ' congé pour bilan de compétences', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('9', '307', '0', '2019-07-02 14:40:47', 'congé pour formation syndicale', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('10', '307', '0', '2019-07-02 14:40:48', 'congé d\'une durée maximale de deux jours ouvrables pendant la durée de son mandat, s\'il est représentant du personnel au sein des instances compétentes en matière d\'hygiène, de sécurité et de conditions de travail', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('11', '307', '0', '2019-07-02 14:40:49', 'congé pour siéger, comme représentant d\'une association déclarée en application de la loi du 1er juillet 1901 relative au contrat d\'association ou d\'une mutuelle au sens du code de la mutualité, dans une instance, consultative ou non, instituée par u', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('12', '307', '0', '2019-07-02 14:40:51', 'congé pour accomplir soit une période de service militaire, d\'instruction militaire ou d\'activité dans la réserve opérationnelle, soit une période d\'activité dans la réserve de sécurité civile, soit une période d\'activité dans la réserve sanitaire, s', '1', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('13', '307', '0', '2019-07-02 14:40:52', 'congé pour décès ou de maladie très grave du conjoint, d\'un ascendant ou d\'un descendant', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('14', '307', '0', '2019-07-02 14:40:53', 'congé de solidarité familiale lorsqu\'un ascendant, un descendant, un frère, une sœur, une personne partageant le même domicile ou l\'ayant désigné comme sa personne de confiance au sens de l\'article L. 1111-6 du code de la santé publique', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('15', '307', '0', '2019-07-02 14:40:54', 'congé de six jours ouvrables par an accordé, sur sa demande, au fonctionnaire de moins de vingt-cinq ans, pour participer aux activités des organisations de jeunesse et d\'éducation populaire, des fédérations et des associations sportives ...', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('16', '307', '0', '2019-07-02 14:40:55', 'pour soigner un enfant malade: congé de présence parentale', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('17', '307', '0', '2019-07-02 14:40:57', 'pour évènement familial en cas de mariage ou de PACS', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('18', '307', '0', '2019-07-02 14:40:58', 'pour évènement familial en cas de cohabitation avec une personne atteinte de maladie contagieuse', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('19', '307', '0', '2019-07-02 14:40:58', 'pour examens médicaux obligatoires (surveillance médicale de la grossesse notamment)', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('20', '307', '0', '2019-07-02 14:40:59', 'pour préparer un examen ou un concours', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('21', '307', '0', '2019-07-02 14:41:02', 'pour participer à un jury de cour d\'assises', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('22', '307', '0', '2019-07-02 14:41:03', 'en qualité de candidat à une fonction publique élective', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('23', '307', '0', '2019-07-02 14:41:05', 'en qualité de candidat à une fonction publique élective', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('24', '307', '0', '2019-07-02 14:41:06', 'pour motif syndical', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('25', '307', '0', '2019-07-02 14:41:06', 'pour participer à un jury d\'examen ou de concours', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('26', '307', '0', '2019-07-02 14:41:07', 'pour participer aux organismes consultatifs (CAP, Comités techniques...)', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('27', '307', '0', '2019-07-02 14:41:08', 'pour effectuer un déplacement hors de France', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('28', '307', '0', '2020-09-07 14:50:01', 'Formation dans l\'entreprise d\'accueil de l\'apprenti', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('29', '307', '0', '2019-07-02 14:41:10', 'en qualité de sapeur pompier volontaire', '2', '3000-01-01 00:00:01');
INSERT INTO `absences_justifications` VALUES ('30', '307', '0', '2019-07-02 14:41:11', 'PROBLEME DE TRANSPORT', '3', '2017-09-27 12:26:19');
INSERT INTO `absences_justifications` VALUES ('31', '307', '0', '2019-07-02 14:41:12', 'PROBLEME OU CONVOCATION MEDICAL', '3', '2017-09-27 12:28:09');
INSERT INTO `absences_justifications` VALUES ('36', '307', '0', '2019-07-02 14:41:13', 'PROBLEME ADMINISTRATIF', '3', '2017-09-27 12:55:04');
INSERT INTO `absences_justifications` VALUES ('48', '307', '0', '2019-07-02 14:41:14', 'PROBLEME PERSONNEL', '3', '2017-09-27 14:20:56');
INSERT INTO `absences_justifications` VALUES ('50', '307', '0', '2019-07-02 14:41:16', 'AUCUN', '3', '2017-09-29 10:05:14');
INSERT INTO `absences_justifications` VALUES ('55', '307', '0', '2019-07-02 14:41:18', 'EXCLUSION DU COURS', '3', '2017-10-11 12:42:59');
INSERT INTO `absences_justifications` VALUES ('64', '307', '0', '2019-07-02 14:41:20', 'DECES DANS LA FAMILLE', '3', '2017-11-24 12:24:31');
INSERT INTO `absences_justifications` VALUES ('71', '307', '0', '2019-07-02 14:41:22', 'STAGE', '3', '2018-03-12 16:16:45');
INSERT INTO `absences_justifications` VALUES ('75', '307', '0', '2019-07-02 14:41:24', 'ENTRETIEN', '3', '2018-06-01 15:14:12');
INSERT INTO `absences_justifications` VALUES ('76', '4048', '0', '2019-09-04 08:19:44', 'CERTIFICAT MEDICAL', '3', '2019-09-04 08:19:44');
INSERT INTO `absences_justifications` VALUES ('78', '4048', '0', '2019-09-09 10:05:59', 'RDV MEDICAL', '3', '2019-09-09 10:05:59');
INSERT INTO `absences_justifications` VALUES ('79', '4048', '0', '2019-09-10 09:25:36', 'CONVOCATION SPORTIVE HAUT-NIVEAU', '3', '2019-09-10 09:25:36');
INSERT INTO `absences_justifications` VALUES ('80', '4048', '0', '2019-09-16 16:05:37', 'CONVOCATION PERMIS', '3', '2019-09-16 16:05:37');
INSERT INTO `absences_justifications` VALUES ('81', '4048', '0', '2019-09-16 16:14:40', 'RDV  BVE POUR TITRE DE SEJOUR', '3', '2019-09-16 16:14:40');
INSERT INTO `absences_justifications` VALUES ('82', '4048', '0', '2019-09-26 13:18:56', 'PASSAGE A L INFIRMERIE', '3', '2019-09-26 13:18:56');
INSERT INTO `absences_justifications` VALUES ('83', '4048', '0', '2019-10-04 10:34:38', 'MISSION DE LA FEV', '3', '2019-10-04 10:34:38');
INSERT INTO `absences_justifications` VALUES ('84', '4048', '0', '2019-10-17 13:01:26', 'ATTESTATION ASSO ETUDIANTS SENEGALAIS', '3', '2019-10-17 13:01:26');
INSERT INTO `absences_justifications` VALUES ('85', '4048', '0', '2019-11-21 14:21:41', 'HOSPITALISATION', '3', '2019-11-21 14:21:41');
INSERT INTO `absences_justifications` VALUES ('86', '4048', '0', '2019-12-13 09:36:37', 'CONVOCATION JDC', '3', '2019-12-13 09:36:37');
INSERT INTO `absences_justifications` VALUES ('87', '4048', '0', '2019-12-13 11:39:58', 'ABSENCE AU DS', '3', '2019-12-13 11:39:58');
INSERT INTO `absences_justifications` VALUES ('88', '4048', '0', '2020-09-09 10:07:06', 'RDV SOUS PREFECTURE', '3', '2020-09-09 10:07:06');
INSERT INTO `absences_justifications` VALUES ('89', '4048', '0', '2020-10-06 15:48:38', 'CONVOCATION LECON DE CONDUITE OGLIGATOIRE', '3', '2020-10-06 15:48:38');
INSERT INTO `absences_justifications` VALUES ('90', '4048', '0', '2020-10-20 14:37:03', 'CONVOCATION SOUS LES DRAPEAUX', '3', '2020-10-20 14:37:03');
INSERT INTO `absences_justifications` VALUES ('91', '4048', '0', '2020-10-20 14:45:56', 'CONVOCATION AU CODE', '3', '2020-10-20 14:45:56');
INSERT INTO `absences_justifications` VALUES ('92', '4048', '0', '2020-10-22 09:17:32', 'PB DE CONNEXION POUR LE DISTANCIEL', '3', '2020-10-22 09:17:32');

-- ----------------------------
-- Table structure for `absences_profs`
-- ----------------------------
DROP TABLE IF EXISTS `absences_profs`;
CREATE TABLE `absences_profs` (
  `codeAbsence` int(11) NOT NULL AUTO_INCREMENT,
  `codeRessource` int(11) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` int(5) NOT NULL,
  `dateFin` date NOT NULL,
  `heureFin` int(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `justifiee` tinyint(1) NOT NULL,
  `codeJustification` int(11) NOT NULL,
  `typeAbsence` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`codeAbsence`),
  KEY `absences_profs_del` (`deleted`),
  KEY `absences_profs_dateModif` (`dateModif`),
  KEY `absences_profs_ibfk_1` (`codeRessource`),
  KEY `absences_profs_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `absences_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `absences_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of absences_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `absences_validations`
-- ----------------------------
DROP TABLE IF EXISTS `absences_validations`;
CREATE TABLE `absences_validations` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeProf` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `codeValidation` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`codeValidation`),
  KEY `absences_validations_del` (`deleted`),
  KEY `absences_validations_ibfk_1` (`codeProf`),
  KEY `absences_validations_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `absences_validations_ibfk_1` FOREIGN KEY (`codeProf`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `absences_validations_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=18800 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of absences_validations
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs`;
CREATE TABLE `bilans_profs` (
  `codeRessource` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bilan` blob NOT NULL,
  `codeProprietaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of bilans_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs_archives`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs_archives`;
CREATE TABLE `bilans_profs_archives` (
  `numeroBilan` int(11) NOT NULL AUTO_INCREMENT,
  `archive` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `commentaire` varchar(255) NOT NULL DEFAULT '-',
  `avecSeances` tinyint(1) NOT NULL DEFAULT '0',
  `avecForfaits` tinyint(1) NOT NULL DEFAULT '0',
  `avecSyntheses` tinyint(1) NOT NULL DEFAULT '0',
  `methodeDeCalcul` tinyint(2) NOT NULL DEFAULT '1',
  `avecPrevisionnels` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`numeroBilan`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bilans_profs_archives
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs_forfaits`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs_forfaits`;
CREATE TABLE `bilans_profs_forfaits` (
  `codeEnseignement` int(11) NOT NULL,
  `dureeForfaitaire` int(5) NOT NULL,
  `public` varchar(5) NOT NULL,
  `dureeStatutaire` int(5) NOT NULL,
  `dureeComplementaire` int(5) NOT NULL,
  `nbEtudiants` int(5) NOT NULL,
  `typeActivite` varchar(6) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `libelleComposante` varchar(150) NOT NULL,
  `libelleProf` varchar(150) NOT NULL,
  `libelleDiplome` varchar(150) NOT NULL,
  `libelleMatiere` varchar(150) NOT NULL,
  `numeroBilan` int(11) NOT NULL,
  `codeProf` int(11) NOT NULL,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `codeDiplome` int(11) NOT NULL DEFAULT '0',
  `codeMatiere` int(11) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `libelleEnseignement` varchar(150) NOT NULL DEFAULT '',
  KEY `idx_for_numeroBilan` (`numeroBilan`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bilans_profs_forfaits
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs_previsionnels`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs_previsionnels`;
CREATE TABLE `bilans_profs_previsionnels` (
  `codeEnseignement` int(11) NOT NULL,
  `dureeForfaitaire` int(5) NOT NULL,
  `public` varchar(5) NOT NULL,
  `dureePrevisionnelle` int(5) NOT NULL,
  `nbEtudiants` int(5) NOT NULL,
  `typeActivite` varchar(6) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `libelleComposante` varchar(150) NOT NULL,
  `libelleProf` varchar(150) NOT NULL,
  `libelleDiplome` varchar(150) NOT NULL,
  `libelleMatiere` varchar(150) NOT NULL,
  `numeroBilan` int(11) NOT NULL,
  `codeProf` int(11) NOT NULL,
  `codeDiplome` int(11) NOT NULL DEFAULT '0',
  `codeMatiere` int(11) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `libelleEnseignement` varchar(150) NOT NULL DEFAULT '',
  KEY `idx_prev_numeroBilan` (`numeroBilan`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bilans_profs_previsionnels
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs_seances`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs_seances`;
CREATE TABLE `bilans_profs_seances` (
  `codeSeance` int(11) NOT NULL,
  `dateSeance` date NOT NULL,
  `heureSeance` int(5) NOT NULL,
  `dureeSeance` int(5) NOT NULL,
  `numeroBilan` int(11) NOT NULL,
  `libelleMatiere` varchar(150) NOT NULL,
  `typeActivite` varchar(6) NOT NULL,
  `nbEtudiants` int(5) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dureeStatutaire` int(5) NOT NULL,
  `dureeComplementaire` int(5) NOT NULL,
  `public` varchar(5) NOT NULL,
  `libelleComposante` varchar(150) NOT NULL,
  `libelleProf` varchar(150) NOT NULL,
  `libelleDiplome` varchar(150) NOT NULL,
  `codeProf` int(11) NOT NULL,
  `codeDiplome` int(11) NOT NULL DEFAULT '0',
  `codeMatiere` int(11) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  KEY `idx_numeroBilan` (`numeroBilan`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bilans_profs_seances
-- ----------------------------

-- ----------------------------
-- Table structure for `bilans_profs_syntheses`
-- ----------------------------
DROP TABLE IF EXISTS `bilans_profs_syntheses`;
CREATE TABLE `bilans_profs_syntheses` (
  `dureeStatutaire` int(5) NOT NULL,
  `dureeComplementaire` int(5) NOT NULL,
  `dureeForfaitaire` int(5) NOT NULL,
  `dureeNonRemuneree` int(5) NOT NULL,
  `numeroBilan` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `libelleProf` varchar(150) NOT NULL,
  `commentaire` varchar(255) NOT NULL DEFAULT '-',
  `libelleComposante` varchar(150) NOT NULL,
  `dateServiceRealise` date NOT NULL,
  `methodeCalcul` varchar(150) NOT NULL DEFAULT '?',
  `dureeTotale` int(5) NOT NULL,
  `libelleGrade` varchar(150) NOT NULL,
  `dureeStatutaireAutorisee` int(5) NOT NULL,
  `dureeComplementaireAutorisee` int(5) NOT NULL,
  `libelleCNU` varchar(150) NOT NULL,
  `debutContrat` date NOT NULL,
  `finContrat` date NOT NULL,
  `titulaire` tinyint(1) NOT NULL DEFAULT '0',
  `dateValidationDossier` date NOT NULL,
  `codeProf` int(11) NOT NULL,
  `codeComposante` int(11) NOT NULL,
  `codeCNU` int(11) NOT NULL,
  `codeGrade` int(11) NOT NULL,
  KEY `idx_synth_numeroBilan` (`numeroBilan`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bilans_profs_syntheses
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_commentaires`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_commentaires`;
CREATE TABLE `calendriers_commentaires` (
  `codeRessource` int(11) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `deleted` int(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date` date NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_commentaires_ibfk_1` (`codeProprietaire`),
  CONSTRAINT `calendriers_commentaires_ibfk_1` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_commentaires
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_enseignements`;
CREATE TABLE `calendriers_enseignements` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_enseignements_del` (`deleted`),
  KEY `calendriers_enseignements_dateModif` (`dateModif`),
  KEY `calendriers_enseignements_ibfk_1` (`codeRessource`),
  KEY `calendriers_enseignements_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_enseignements_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `calendriers_enseignements_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_filieres`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_filieres`;
CREATE TABLE `calendriers_filieres` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_filieres_del` (`deleted`),
  KEY `calendriers_filieres_dateModif` (`dateModif`),
  KEY `calendriers_filieres_ibfk_1` (`codeRessource`),
  KEY `calendriers_filieres_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_filieres_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `filieres` (`codeFiliere`),
  CONSTRAINT `calendriers_filieres_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_filieres
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_groupes`;
CREATE TABLE `calendriers_groupes` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_groupes_del` (`deleted`),
  KEY `calendriers_groupes_dateModif` (`dateModif`),
  KEY `calendriers_groupes_ibfk_1` (`codeRessource`),
  KEY `calendriers_groupes_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_groupes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `calendriers_groupes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_materiels`;
CREATE TABLE `calendriers_materiels` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_materiels_del` (`deleted`),
  KEY `calendriers_materiels_dateModif` (`dateModif`),
  KEY `calendriers_materiels_ibfk_1` (`codeRessource`),
  KEY `calendriers_materiels_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_materiels_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `calendriers_materiels_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_profs`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_profs`;
CREATE TABLE `calendriers_profs` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_profs_del` (`deleted`),
  KEY `calendriers_profs_dateModif` (`dateModif`),
  KEY `calendriers_profs_ibfk_1` (`codeRessource`),
  KEY `calendriers_profs_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `calendriers_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `calendriers_salles`
-- ----------------------------
DROP TABLE IF EXISTS `calendriers_salles`;
CREATE TABLE `calendriers_salles` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '3000-01-01',
  `etat` tinyint(2) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `calendriers_salles_del` (`deleted`),
  KEY `calendriers_salles_dateModif` (`dateModif`),
  KEY `calendriers_salles_ibfk_1` (`codeRessource`),
  KEY `calendriers_salles_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `calendriers_salles_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `calendriers_salles_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendriers_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `cnu`
-- ----------------------------
DROP TABLE IF EXISTS `cnu`;
CREATE TABLE `cnu` (
  `codeCNU` int(11) NOT NULL AUTO_INCREMENT,
  `section` int(11) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `identifiant` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`codeCNU`),
  KEY `cnu_del` (`deleted`),
  KEY `cnu_dateModif` (`dateModif`),
  KEY `cnu_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `cnu_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=2034 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cnu
-- ----------------------------
INSERT INTO `cnu` VALUES ('1823', '1', 'DROIT PRIVE ET SCIENCES CRIMINELLES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1824', '2', 'DROIT PUBLIC', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1825', '3', 'HISTOIRE DU DROIT ET DES INSTITUTIONS', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1826', '4', 'SCIENCE POLITIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1827', '5', 'SCIENCES ECONOMIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1828', '6', 'SCIENCES DE GESTION', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1829', '7', 'SCIENCES DU LANGAGE LINGUISTIQUE ET PHONETIQUE GENERALES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1830', '8', 'LANGUES ET LITTERATURES ANCIENNES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1831', '9', 'LANGUE ET LITTERATURE FRANCAISES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1832', '10', 'LITTERATURES COMPAREES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1833', '11', 'LANGUES ET LITTERATURES ANGLAISES ET ANGLO-SAXONNES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1834', '12', 'LANGUES ET LITTERATURES GERMANIQUES ET SCANDINAVES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1835', '13', 'LANGUES ET LITTERATURES SLAVES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1836', '14', 'LANGUES ET LITTRATURES ROMANES  ESPAGNOL ITALIEN PORTUGAIS AUTRES LANGUES ROMANES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1837', '15', 'LANGUES ET LITTERATURES ARABES CHINOISES JAPONAISES HIBRAIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1838', '16', 'PSYCHOLOGIE PSYCHOLOGIE CLINIQUE PSYCHOLOGIE SOCIALE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1839', '17', 'PHILOSOPHIE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1840', '18', 'ARTS  PLASTIQUES DU SPECTACLE MUSIQUE MUSICOLOGIE ESTHTIQUE SCIENCES DE L ART', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1841', '19', 'SOCIOLOGIE DEMOGRAPHIE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1842', '20', 'ANTHROPOLOGIE ETHNOLOGIE PREHISTOIRE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1843', '21', 'HISTOIRE ET CIVILISATIONS  HISTOIRE ET ARCHEOLOGIE DES MONDES ANCIENS ET DES MONDES MEDIEVAUX', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1844', '22', 'HISTOIRE ET CIVILISATIONS  HISTOIRE DES MONDES MODERNES HISTOIRE DU MONDE CONTEMPORAIN', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1845', '23', 'GEOGRAPHIE PHYSIQUE HUMAINE ECONOMIQUE ET REGIONALE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1846', '24', 'AMENAGEMENT DE L ESPACE ET URBANISME', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1847', '25', 'MATHEMATIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1848', '26', 'MATHEMATIQUES APPLIQUEES ET APPLICATIONS DES MATHEMATIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1849', '27', 'INFORMATIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1850', '28', 'MILIEUX DENSES ET MATERIAUX', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1851', '29', 'CONSTITUANTS ELEMENTAIRES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1852', '30', 'MILIEUX DILUES ET OPTIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1853', '31', 'CHIMIE THEORIQUE ET PHYSIQUE ANALYTIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1854', '32', 'CHIMIE ORGANIQUE MINERALE INDUSTRIELLE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1855', '33', 'CHIMIE DES MATERIAUX', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1856', '34', 'ASTRONOMIE ASTROPHYSIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1857', '35', 'STRUCTURE ET EVOLUTION DE LA TERRE ET DES AUTRES PLANETES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1858', '36', 'TERRE SOLIDE  GEODYNAMIQUE DES ENVELOPPES SUPERIEURES PALEOBIOSPHERE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1859', '37', 'METOROLOGIE OCEANOGRAPHIE PHYSIQUE ET PHYSIQUE DE L ENVIRONNEMENT', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1860', '39', 'SCIENCES PHYSICO-CHIMIQUES ET TECHNOLOGIES PHARMACEUTIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1861', '40', 'SCIENCES DU MDICAMENT', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1862', '41', 'SCIENCES BIOLOGIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1863', '60', 'MECANIQUE GENIE MECANIQUE GENIE CIVIL', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1864', '61', 'GENIE INFORMATIQUE AUTOMATIQUE ET TRAITEMENT DU SIGNAL', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1865', '62', 'ENERGETIQUE GENIE DES PROCEDES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1866', '63', 'ELECTRONIQUE OPTRONIQUE ET SYSTEMES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1867', '64', 'BIOCHIMIE ET BIOLOGIE MOLECULAIRE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1868', '65', 'BIOLOGIE CELLULAIRE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1869', '66', 'PHYSIOLOGIE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1870', '67', 'BIOLOGIE DES POPULATIONS ET ECOLOGIE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1871', '68', 'BIOLOGIE DES ORGANISMES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1872', '69', 'NEUROSCIENCES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1873', '70', 'SCIENCES DE L EDUCATION', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1874', '71', 'SCIENCES DE L INFORMATION ET DE LA COMMUNICATION', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1875', '72', 'EPISTEMOLOGIE HISTOIRE DES SCIENCES ET DES TECHNIQUES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1876', '73', 'CULTURES ET LANGUES REGIONALES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1877', '74', 'SCIENCES ET TECHNIQUES DES ACTIVITES PHYSIQUES ET SPORTIVES', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1878', '76', 'THEOLOGIE CATHOLIQUE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('1913', '77', 'THEOLOGIE PROTESTANTE', '2017-09-23 08:04:56', '2011-03-03 18:10:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2000', '0', 'CNU INCONNUE', '2017-09-23 08:04:56', '2011-03-03 18:10:36', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2001', '201', 'LETTRES CLASSIQUES - GRAMMAIRE', '2017-09-23 08:04:56', '2011-10-11 05:40:14', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2002', '202', 'LETTRES MODERNES', '2017-09-23 08:04:56', '2011-10-11 05:40:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2003', '421', 'ALLEMAND', '2017-09-23 08:04:56', '2011-10-11 05:41:03', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2004', '422', 'ANGLAIS', '2017-09-23 08:04:56', '2011-10-11 05:41:31', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2005', '426', 'ESPAGNOL', '2017-09-23 08:04:56', '2011-10-11 05:41:48', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2006', '429', 'ITALIEN', '2017-09-23 08:04:56', '2011-10-11 05:42:06', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2007', '1100', 'SCIENCES ECONOMIQUES ET SOCIALES', '2017-09-23 08:04:56', '2011-10-11 05:42:39', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2008', '1300', 'MATHEMATIQUES', '2017-09-23 08:04:56', '2011-10-11 05:43:58', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2009', '1400', 'TECHNOLOGIE', '2017-09-23 08:04:56', '2011-10-11 05:44:19', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2010', '1500', 'PHYSIQUE - CHIMIE', '2017-09-23 08:04:56', '2011-10-11 05:44:55', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2011', '1510', 'SCIENCES PHYSIQUES - PHYSIQUE APPLIQUEE', '2017-09-23 08:04:56', '2011-10-11 05:45:43', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2012', '1800', 'ARTS PLASTIQUES', '2017-09-23 08:04:56', '2011-10-11 05:46:10', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2013', '1900', 'EDUCATION PHYSIQUE ET SPORTIVE', '2017-09-23 08:04:56', '2011-10-11 05:46:31', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2014', '4100', 'GENIE MECANIQUE - MECANIQUE', '2017-09-23 08:04:56', '2011-10-11 05:47:30', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2015', '4201', 'MECANIQUE GENERALE', '2017-09-23 08:04:56', '2011-10-11 05:47:46', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2016', '5100', 'GENIE ELECTRIQUE', '2017-09-23 08:04:56', '2011-10-11 05:48:05', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2017', '8010', 'ECONOMIE ET GESTION', '2017-09-23 08:04:56', '2011-10-11 05:48:29', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2018', '8030', 'INFORMATIQUE ET GESTION', '2017-09-23 08:04:56', '2011-10-11 05:49:03', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2019', '3000', 'GENIE CIVIL', '2017-09-23 08:04:56', '2012-03-05 10:37:37', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2020', '9969', 'AUTOMATIQUE', '2017-09-23 08:04:56', '2012-03-05 11:21:04', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2022', '200', 'LETTRES', '2017-09-23 08:04:56', '2012-10-02 08:53:56', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2023', '6980', 'AUDIO VISUEL', '2017-09-23 08:04:56', '2014-09-10 14:37:19', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2024', '7100', 'BIOCHIMIE GENIE BIOLOGIQUE', '2017-09-23 08:04:56', '2015-09-09 09:46:13', '0', '900009019', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2026', '1411', 'SII ARCHITECTURE ET CONSTRUCTION ', '2022-01-20 11:57:04', '2022-01-20 11:57:04', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2027', '1412', 'SII ENERGIE', '2022-01-20 11:57:20', '2022-01-20 11:57:20', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2028', '1413', 'SII INFORMATIQUE ET NUMERIQUE', '2022-01-20 11:57:42', '2022-01-20 11:57:42', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2029', '1414', 'SII INGENIERIE MECANIQUE', '2022-01-20 11:58:02', '2022-01-20 11:58:02', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2030', '1415', 'SII INGENIERIE ELECTRIQUE', '2022-01-20 11:58:14', '2022-01-20 11:58:14', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2031', '4550', 'G. MECA MAINT. SYS MECO ET AUTO', '2022-01-31 11:16:01', '2022-01-31 11:16:01', '0', '910009056', '', '0', '0', '', '');
INSERT INTO `cnu` VALUES ('2032', '58', 'ODONTO REHABILITATION ORALE', '2022-02-03 16:26:31', '2022-02-03 16:26:31', '0', '910009056', '', '0', '0', '', '');

-- ----------------------------
-- Table structure for `composantes`
-- ----------------------------
DROP TABLE IF EXISTS `composantes`;
CREATE TABLE `composantes` (
  `codeComposante` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `typeComposante` tinyint(3) NOT NULL DEFAULT '2',
  `volMaxFI` int(8) NOT NULL DEFAULT '0',
  `volMaxFC` int(8) NOT NULL DEFAULT '0',
  `volMaxFA` int(8) NOT NULL DEFAULT '0',
  `volMaxAUTRE` int(8) NOT NULL DEFAULT '0',
  `reference` int(8) NOT NULL DEFAULT '0',
  `referencePonderee` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeComposante`),
  KEY `composantes_del` (`deleted`),
  KEY `composantes_dateModif` (`dateModif`),
  KEY `composantes_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `composantes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=2392 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of composantes
-- ----------------------------
INSERT INTO `composantes` VALUES ('2390', '16777088', '0', 'COMPOSANTE1', '2022-09-09 09:37:37', '2022-09-09 09:36:04', '0', '99999', 'COMPO1', '', 'COMPO1', '2', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `composantes_directeurs`
-- ----------------------------
DROP TABLE IF EXISTS `composantes_directeurs`;
CREATE TABLE `composantes_directeurs` (
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `codeDirecteur` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  KEY `composantes_directeurs_del` (`deleted`),
  KEY `composantes_directeurs_dateModif` (`dateModif`),
  KEY `composantes_directeurs_ibfk_2` (`codeComposante`),
  KEY `composantes_directeurs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `composantes_directeurs_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `composantes_directeurs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of composantes_directeurs
-- ----------------------------

-- ----------------------------
-- Table structure for `diplomes`
-- ----------------------------
DROP TABLE IF EXISTS `diplomes`;
CREATE TABLE `diplomes` (
  `codeDiplome` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `codeNiveau` int(11) NOT NULL DEFAULT '0',
  `codeResponsable` int(11) NOT NULL DEFAULT '0',
  `typePublic` tinyint(1) NOT NULL DEFAULT '1',
  `codeSuper` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `reference` int(8) NOT NULL DEFAULT '0',
  `referencePonderee` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeDiplome`),
  KEY `diplomes_del` (`deleted`),
  KEY `diplomes_dateModif` (`dateModif`),
  KEY `diplomes_ibfk_1` (`codeComposante`),
  KEY `diplomes_ibfk_4` (`codeProprietaire`),
  CONSTRAINT `diplomes_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `diplomes_ibfk_4` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=5900 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of diplomes
-- ----------------------------

-- ----------------------------
-- Table structure for `disciplines`
-- ----------------------------
DROP TABLE IF EXISTS `disciplines`;
CREATE TABLE `disciplines` (
  `codeDiscipline` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  PRIMARY KEY (`codeDiscipline`),
  KEY `disciplines_del` (`deleted`),
  KEY `disciplines_dateModif` (`dateModif`),
  KEY `disciplines_ibfk_2` (`codeProprietaire`),
  CONSTRAINT `disciplines_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of disciplines
-- ----------------------------

-- ----------------------------
-- Table structure for `disciplines_profs`
-- ----------------------------
DROP TABLE IF EXISTS `disciplines_profs`;
CREATE TABLE `disciplines_profs` (
  `codeDiscipline` int(11) NOT NULL,
  `codeProf` int(11) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL,
  KEY `disciplines_profs_del` (`deleted`),
  KEY `disciplines_profs_dateModif` (`dateModif`),
  KEY `disciplines_profs_ibfk_1` (`codeDiscipline`),
  KEY `disciplines_profs_ibfk_2` (`codeProf`),
  KEY `disciplines_profs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `disciplines_profs_ibfk_1` FOREIGN KEY (`codeDiscipline`) REFERENCES `disciplines` (`codeDiscipline`),
  CONSTRAINT `disciplines_profs_ibfk_2` FOREIGN KEY (`codeProf`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `disciplines_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of disciplines_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements`;
CREATE TABLE `enseignements` (
  `codeEnseignement` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL DEFAULT 'ENS?',
  `codeMatiere` int(11) NOT NULL DEFAULT '0',
  `dureeTotale` int(5) NOT NULL DEFAULT '2000',
  `dureeSeance` int(5) NOT NULL DEFAULT '100',
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `alias` varchar(100) NOT NULL DEFAULT 'ENS?',
  `codeTypeSalle` int(11) NOT NULL DEFAULT '0',
  `codeZoneSalle` int(11) NOT NULL DEFAULT '0',
  `nbSeancesHebdo` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `typePublic` tinyint(5) NOT NULL DEFAULT '0',
  `forfaitaire` tinyint(1) NOT NULL DEFAULT '0',
  `dureeForfaitaire` int(5) NOT NULL DEFAULT '0',
  `volumeReparti` int(1) NOT NULL DEFAULT '1',
  `codeTypeActivite` int(5) NOT NULL DEFAULT '2',
  `codeComposante` int(11) NOT NULL DEFAULT '-1',
  `codeNiveau` int(11) NOT NULL,
  `dateDebut` date NOT NULL DEFAULT '2014-01-01',
  `dateFin` date NOT NULL DEFAULT '2030-01-01',
  `article6` tinyint(1) NOT NULL DEFAULT '0',
  `codeTypeMateriel` int(11) NOT NULL DEFAULT '0',
  `dureeAjoutee` int(5) NOT NULL DEFAULT '0',
  `codeDiplome` int(11) NOT NULL DEFAULT '0',
  `operateurTypesSalles` tinyint(1) NOT NULL DEFAULT '0',
  `operateurTypesMateriels` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeEnseignement`),
  KEY `enseignements_del` (`deleted`),
  KEY `enseignements_dateModif` (`dateModif`),
  KEY `enseignements_ibfk_1` (`codeMatiere`),
  KEY `enseignements_ibfk_4` (`codeTypeActivite`),
  KEY `enseignements_ibfk_5` (`codeComposante`),
  KEY `enseignements_ibfk_8` (`codeProprietaire`),
  CONSTRAINT `enseignements_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  CONSTRAINT `enseignements_ibfk_4` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  CONSTRAINT `enseignements_ibfk_5` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `enseignements_ibfk_8` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=28208882 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_groupes`;
CREATE TABLE `enseignements_groupes` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_groupes_del` (`deleted`),
  KEY `enseignements_groupes_dateModif` (`dateModif`),
  KEY `enseignements_groupes_ibfk_1` (`codeEnseignement`),
  KEY `enseignements_groupes_ibfk_2` (`codeRessource`),
  KEY `enseignements_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `enseignements_groupes_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `enseignements_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_historique`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_historique`;
CREATE TABLE `enseignements_historique` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'ENS?',
  `codeMatiere` int(11) NOT NULL DEFAULT '0',
  `dureeTotale` int(5) NOT NULL DEFAULT '0',
  `dureeSeance` int(5) NOT NULL DEFAULT '0',
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT 'ENS?',
  `codeTypeSalle` int(11) NOT NULL DEFAULT '0',
  `codeZoneSalle` int(11) NOT NULL DEFAULT '0',
  `nbSeancesHebdo` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) DEFAULT NULL,
  `codeProprietaireModifieur` int(11) DEFAULT NULL,
  KEY `enseignements_historique_del` (`deleted`),
  KEY `enseignements_historique_dateModif` (`dateModif`),
  KEY `enseignements_historique_ibfk_1` (`codeMatiere`),
  KEY `enseignements_historique_ibfk_2` (`codeTypeSalle`),
  KEY `enseignements_historique_ibfk_3` (`codeZoneSalle`),
  KEY `enseignements_historique_ibfk_8` (`codeProprietaire`),
  CONSTRAINT `enseignements_historique_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  CONSTRAINT `enseignements_historique_ibfk_2` FOREIGN KEY (`codeTypeSalle`) REFERENCES `types_salles` (`codeTypeSalle`),
  CONSTRAINT `enseignements_historique_ibfk_3` FOREIGN KEY (`codeZoneSalle`) REFERENCES `zones_salles` (`codeZoneSalle`),
  CONSTRAINT `enseignements_historique_ibfk_8` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_historique
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_materiels`;
CREATE TABLE `enseignements_materiels` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_materiels_del` (`deleted`),
  KEY `enseignements_materiels_dateModif` (`dateModif`),
  KEY `enseignements_materiels_ibfk_1` (`codeEnseignement`),
  KEY `enseignements_materiels_ibfk_2` (`codeRessource`),
  KEY `enseignements_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `enseignements_materiels_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `enseignements_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_prerequis`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_prerequis`;
CREATE TABLE `enseignements_prerequis` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codePrerequis` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `typePrerequis` tinyint(4) NOT NULL DEFAULT '1',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_prerequis_del` (`deleted`),
  KEY `enseignements_prerequis_dateModif` (`dateModif`),
  KEY `enseignements_prerequis_ibfk_1` (`codeEnseignement`),
  KEY `enseignements_prerequis_ibfk_2` (`codePrerequis`),
  KEY `enseignements_prerequis_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `enseignements_prerequis_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_prerequis_ibfk_2` FOREIGN KEY (`codePrerequis`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_prerequis_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_prerequis
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_profs`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_profs`;
CREATE TABLE `enseignements_profs` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_profs_del` (`deleted`),
  KEY `enseignements_profs_dateModif` (`dateModif`),
  KEY `enseignements_profs_ibfk_1` (`codeEnseignement`),
  KEY `enseignements_profs_ibfk_2` (`codeRessource`),
  KEY `enseignements_profs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `enseignements_profs_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `enseignements_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_salles`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_salles`;
CREATE TABLE `enseignements_salles` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_salles_del` (`deleted`),
  KEY `enseignements_salles_dateModif` (`dateModif`),
  KEY `enseignements_salles_ibfk_1` (`codeEnseignement`),
  KEY `enseignements_salles_ibfk_2` (`codeRessource`),
  KEY `enseignements_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `enseignements_salles_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `enseignements_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_types_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_types_materiels`;
CREATE TABLE `enseignements_types_materiels` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeTypeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_types_materiels_del` (`deleted`) USING BTREE,
  KEY `enseignements_types_materiels_dateModif` (`dateModif`) USING BTREE,
  KEY `enseignements_types_materiels_ibfk_1` (`codeEnseignement`) USING BTREE,
  KEY `enseignements_types_materiels_ibfk_2` (`codeTypeRessource`) USING BTREE,
  KEY `enseignements_types_materiels_ibfk_3` (`codeProprietaire`) USING BTREE,
  CONSTRAINT `enseignements_types_materiels_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `enseignements_types_materiels_ibfk_2` FOREIGN KEY (`codeTypeRessource`) REFERENCES `types_materiels` (`codeTypeMateriel`),
  CONSTRAINT `enseignements_types_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_types_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `enseignements_types_salles`
-- ----------------------------
DROP TABLE IF EXISTS `enseignements_types_salles`;
CREATE TABLE `enseignements_types_salles` (
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `codeTypeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `enseignements_types_salles_del` (`deleted`) USING BTREE,
  KEY `enseignements_types_salles_dateModif` (`dateModif`) USING BTREE,
  KEY `enseignements_types_salles_ibfk_1` (`codeEnseignement`) USING BTREE,
  KEY `enseignements_types_salles_ibfk_2` (`codeTypeRessource`) USING BTREE,
  KEY `enseignements_types_salles_ibfk_3` (`codeProprietaire`) USING BTREE,
  CONSTRAINT `enseignements_types_salles_ibfk_1` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enseignements_types_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `etudiants_diplomes`
-- ----------------------------
DROP TABLE IF EXISTS `etudiants_diplomes`;
CREATE TABLE `etudiants_diplomes` (
  `codeEtudiant` int(11) NOT NULL,
  `codeDiplome` int(11) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL,
  KEY `etudiants_diplomes_del` (`deleted`),
  KEY `etudiants_diplomes_dateModif` (`dateModif`),
  KEY `etudiants_diplomes_ibfk_1` (`codeDiplome`),
  KEY `etudiants_diplomes_ibfk_2` (`codeEtudiant`),
  KEY `etudiants_diplomes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `etudiants_diplomes_ibfk_1` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  CONSTRAINT `etudiants_diplomes_ibfk_2` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  CONSTRAINT `etudiants_diplomes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of etudiants_diplomes
-- ----------------------------

-- ----------------------------
-- Table structure for `filieres`
-- ----------------------------
DROP TABLE IF EXISTS `filieres`;
CREATE TABLE `filieres` (
  `codeFiliere` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL DEFAULT 'FILIERE?',
  `heureDebut` int(5) NOT NULL DEFAULT '0',
  `heureFin` int(5) NOT NULL DEFAULT '0',
  `finesseTemps` int(5) NOT NULL DEFAULT '0',
  `dateDebut` date NOT NULL DEFAULT '2015-01-01',
  `dateFin` date NOT NULL DEFAULT '2015-01-01',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `nbSemainesEnseignementAnnuel` int(5) NOT NULL DEFAULT '32',
  `nbJoursEnseignementHebdo` int(5) NOT NULL DEFAULT '5',
  `dureeQuotidienneLegale` int(5) NOT NULL DEFAULT '420',
  `dureeAnnuelleLegale` int(5) NOT NULL DEFAULT '96420',
  `nbJoursPourCalculAbsences` int(5) NOT NULL DEFAULT '60',
  `normalisation` tinyint(1) NOT NULL DEFAULT '1',
  `heureDebutPauseMidi` int(5) NOT NULL DEFAULT '720',
  `heureFinPauseMidi` int(5) NOT NULL DEFAULT '840',
  `dureePauseMidi` int(5) NOT NULL DEFAULT '30',
  `dureeMaxTravail` int(5) NOT NULL DEFAULT '360',
  `dureeMinPause` int(5) NOT NULL DEFAULT '30',
  `HostNameDocument` varchar(100) NOT NULL DEFAULT '',
  `PortDocument` int(5) NOT NULL DEFAULT '21',
  `UsernameDocument` varchar(100) NOT NULL DEFAULT '',
  `PasswordDocument` varchar(100) NOT NULL DEFAULT '',
  `RepertoireDocument` varchar(200) NOT NULL DEFAULT '',
  `httpDocument` varchar(200) NOT NULL DEFAULT '',
  `modeDocument` tinyint(1) NOT NULL DEFAULT '1',
  `HostNameEDT` varchar(100) NOT NULL DEFAULT '',
  `PortEDT` int(5) NOT NULL DEFAULT '21',
  `UsernameEDT` varchar(100) NOT NULL DEFAULT '',
  `PasswordEDT` varchar(100) NOT NULL DEFAULT '',
  `RepertoireEDT` varchar(200) NOT NULL DEFAULT '',
  `httpEDT` varchar(200) NOT NULL DEFAULT '',
  `modeEDT` tinyint(1) NOT NULL DEFAULT '1',
  `organisation` tinyint(1) NOT NULL DEFAULT '0',
  `organisationDateDebut1` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin1` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut2` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin2` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut3` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateFin3` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `organisationDateDebut4` datetime NOT NULL DEFAULT '1963-04-08 00:00:01',
  `organisationDateFin4` datetime NOT NULL DEFAULT '1963-04-08 00:00:01',
  PRIMARY KEY (`codeFiliere`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of filieres
-- ----------------------------
INSERT INTO `filieres` VALUES ('63', 'UNIVERSITE-2022-2023', '800', '2100', '30', '2022-07-25', '2023-08-13', '2022-06-29 15:52:25', '0', '0', '32', '5', '420', '96420', '60', '1', '750', '840', '30', '360', '15', '', '21', '', '', '', '', '1', '', '21', '', '', '', '', '1', '0', '2022-09-01 00:00:00', '2023-07-23 00:00:00', '2023-02-01 00:00:00', '2023-07-31 00:00:00', '2000-01-01 00:00:00', '2000-01-01 00:00:00', '1963-04-08 00:00:00', '1963-04-08 00:00:00');

-- ----------------------------
-- Table structure for `grades`
-- ----------------------------
DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `codeGrade` int(11) NOT NULL AUTO_INCREMENT,
  `grade` varchar(150) NOT NULL DEFAULT 'GRADE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `heuresStatutaires` int(6) NOT NULL DEFAULT '0',
  `heuresComplementaires` int(6) NOT NULL DEFAULT '0',
  `couleurFond` int(11) NOT NULL DEFAULT '15917303',
  `couleurPolice` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`codeGrade`),
  KEY `grades_del` (`deleted`),
  KEY `grades_dateModif` (`dateModif`),
  KEY `grades_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `grades_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=16000764 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of grades
-- ----------------------------

-- ----------------------------
-- Table structure for `grades_ponderations`
-- ----------------------------
DROP TABLE IF EXISTS `grades_ponderations`;
CREATE TABLE `grades_ponderations` (
  `codeGrade` int(11) NOT NULL,
  `codeTypeActivite` int(11) NOT NULL,
  `ponderation` float(10,9) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `ponderationSUP` float(10,9) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL,
  KEY `grades_ponderations_del` (`deleted`),
  KEY `grades_ponderations_dateModif` (`dateModif`),
  KEY `grades_ponderations_ibfk_1` (`codeGrade`),
  KEY `grades_ponderations_ibfk_2` (`codeTypeActivite`),
  KEY `grades_ponderations_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `grades_ponderations_ibfk_1` FOREIGN KEY (`codeGrade`) REFERENCES `grades` (`codeGrade`),
  CONSTRAINT `grades_ponderations_ibfk_2` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  CONSTRAINT `grades_ponderations_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of grades_ponderations
-- ----------------------------

-- ----------------------------
-- Table structure for `hierarchies_composantes`
-- ----------------------------
DROP TABLE IF EXISTS `hierarchies_composantes`;
CREATE TABLE `hierarchies_composantes` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `codeRessourceFille` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `hierarchies_composantes_del` (`deleted`),
  KEY `hierarchies_composantes_dateModif` (`dateModif`),
  KEY `hierarchies_composantes_ibfk_1` (`codeRessource`),
  KEY `hierarchies_composantes_ibfk_2` (`codeRessourceFille`),
  KEY `hierarchies_composantes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `hierarchies_composantes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `hierarchies_composantes_ibfk_2` FOREIGN KEY (`codeRessourceFille`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `hierarchies_composantes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hierarchies_composantes
-- ----------------------------

-- ----------------------------
-- Table structure for `hierarchies_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `hierarchies_groupes`;
CREATE TABLE `hierarchies_groupes` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `codeRessourceFille` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `hierarchies_groupe_del` (`deleted`),
  KEY `hierarchies_groupes_dateModif` (`dateModif`),
  KEY `hierarchies_groupes_ibfk_1` (`codeRessource`),
  KEY `hierarchies_groupes_ibfk_2` (`codeRessourceFille`),
  KEY `hierarchies_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `hierarchies_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hierarchies_groupes
-- ----------------------------
INSERT INTO `hierarchies_groupes` VALUES ('27989926', '27989927', '2022-09-10 06:50:01', '0', '99999', '2022-09-10 06:50:01');
INSERT INTO `hierarchies_groupes` VALUES ('27989926', '27989928', '2022-09-10 06:50:17', '0', '99999', '2022-09-10 06:50:17');
INSERT INTO `hierarchies_groupes` VALUES ('27989926', '27989929', '2022-09-10 06:50:29', '0', '99999', '2022-09-10 06:50:29');

-- ----------------------------
-- Table structure for `lignes_budgetaires`
-- ----------------------------
DROP TABLE IF EXISTS `lignes_budgetaires`;
CREATE TABLE `lignes_budgetaires` (
  `codeLigneBudgetaire` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'LIGNE?',
  `alias` varchar(50) NOT NULL DEFAULT 'LIGNE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  PRIMARY KEY (`codeLigneBudgetaire`),
  KEY `lignes_budgetaires_del` (`deleted`),
  KEY `lignes_budgetaires_dateModif` (`dateModif`),
  KEY `lignes_budgetaires_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `lignes_budgetaires_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=27785327 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lignes_budgetaires
-- ----------------------------

-- ----------------------------
-- Table structure for `lignes_budgetaires_enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `lignes_budgetaires_enseignements`;
CREATE TABLE `lignes_budgetaires_enseignements` (
  `codeLigneBudgetaire` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `lignes_budgetaires_enseignements_del` (`deleted`),
  KEY `lignes_budgetaires_enseignements_dateModif` (`dateModif`),
  KEY `lignes_budgetaires_enseignements_ibfk_1` (`codeLigneBudgetaire`),
  KEY `lignes_budgetaires_enseignements_ibfk_2` (`codeRessource`),
  KEY `lignes_budgetaires_enseignements_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `lignes_budgetaires_enseignements_ibfk_1` FOREIGN KEY (`codeLigneBudgetaire`) REFERENCES `lignes_budgetaires` (`codeLigneBudgetaire`),
  CONSTRAINT `lignes_budgetaires_enseignements_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `lignes_budgetaires_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lignes_budgetaires_enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `lignes_budgetaires_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `lignes_budgetaires_groupes`;
CREATE TABLE `lignes_budgetaires_groupes` (
  `codeLigneBudgetaire` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `lignes_budgetaires_groupes_del` (`deleted`),
  KEY `lignes_budgetaires_groupes_dateModif` (`dateModif`),
  KEY `lignes_budgetaires_groupes_ibfk_1` (`codeLigneBudgetaire`),
  KEY `lignes_budgetaires_groupes_ibfk_2` (`codeRessource`),
  KEY `lignes_budgetaires_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `lignes_budgetaires_groupes_ibfk_1` FOREIGN KEY (`codeLigneBudgetaire`) REFERENCES `lignes_budgetaires` (`codeLigneBudgetaire`),
  CONSTRAINT `lignes_budgetaires_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `lignes_budgetaires_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lignes_budgetaires_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `matieres`
-- ----------------------------
DROP TABLE IF EXISTS `matieres`;
CREATE TABLE `matieres` (
  `codeMatiere` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'MATIERE?',
  `type` int(11) NOT NULL DEFAULT '0',
  `codeCNU` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT 'MATIERE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeDiscipline` int(11) NOT NULL DEFAULT '0',
  `periode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeMatiere`),
  KEY `matieres_del` (`deleted`),
  KEY `matieres_dateModif` (`dateModif`),
  KEY `matieres_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `matieres_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=27898694 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of matieres
-- ----------------------------

-- ----------------------------
-- Table structure for `matieres_diplomes`
-- ----------------------------
DROP TABLE IF EXISTS `matieres_diplomes`;
CREATE TABLE `matieres_diplomes` (
  `codeMatiere` int(11) NOT NULL,
  `codeDiplome` int(11) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL,
  KEY `matieres_diplomes_del` (`deleted`),
  KEY `matieres_diplomes_dateModif` (`dateModif`),
  KEY `matieres_diplomes_ibfk_1` (`codeMatiere`),
  KEY `matieres_diplomes_ibfk_2` (`codeDiplome`),
  KEY `matieres_diplomes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `matieres_diplomes_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  CONSTRAINT `matieres_diplomes_ibfk_2` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  CONSTRAINT `matieres_diplomes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of matieres_diplomes
-- ----------------------------

-- ----------------------------
-- Table structure for `matieres_diplomes_durees`
-- ----------------------------
DROP TABLE IF EXISTS `matieres_diplomes_durees`;
CREATE TABLE `matieres_diplomes_durees` (
  `codeDiplome` int(11) NOT NULL,
  `codeMatiere` int(11) NOT NULL,
  `codeTypeActivite` int(11) NOT NULL,
  `duree` int(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nbGroupes` int(5) NOT NULL DEFAULT '0',
  `taux` int(5) NOT NULL DEFAULT '100',
  `reference` int(8) NOT NULL DEFAULT '0',
  `referencePonderee` int(8) NOT NULL DEFAULT '0',
  KEY `matieres_diplomes_durees_del` (`deleted`),
  KEY `matieres_diplomes_durees_dateModif` (`dateModif`),
  KEY `matieres_diplomes_durees_ibfk_1` (`codeMatiere`),
  KEY `matieres_diplomes_durees_ibfk_2` (`codeDiplome`),
  KEY `matieres_diplomes_durees_ibfk_3` (`codeTypeActivite`),
  KEY `matieres_diplomes_durees_ibfk_4` (`codeProprietaire`),
  CONSTRAINT `matieres_diplomes_durees_ibfk_1` FOREIGN KEY (`codeMatiere`) REFERENCES `matieres` (`codeMatiere`),
  CONSTRAINT `matieres_diplomes_durees_ibfk_2` FOREIGN KEY (`codeDiplome`) REFERENCES `diplomes` (`codeDiplome`),
  CONSTRAINT `matieres_diplomes_durees_ibfk_3` FOREIGN KEY (`codeTypeActivite`) REFERENCES `types_activites` (`codeTypeActivite`),
  CONSTRAINT `matieres_diplomes_durees_ibfk_4` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of matieres_diplomes_durees
-- ----------------------------

-- ----------------------------
-- Table structure for `messages_ent`
-- ----------------------------
DROP TABLE IF EXISTS `messages_ent`;
CREATE TABLE `messages_ent` (
  `codeMessage` int(11) NOT NULL,
  `codeSeance` int(10) unsigned NOT NULL,
  `idAuteur` int(10) unsigned NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL,
  `message` varchar(150) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `accord` tinyint(1) NOT NULL,
  `typeAuteur` int(2) unsigned NOT NULL,
  PRIMARY KEY (`codeMessage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of messages_ent
-- ----------------------------

-- ----------------------------
-- Table structure for `modifications`
-- ----------------------------
DROP TABLE IF EXISTS `modifications`;
CREATE TABLE `modifications` (
  `code` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL,
  `typeAction` int(11) NOT NULL,
  `numeroAction` int(11) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `typeObjet` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of modifications
-- ----------------------------

-- ----------------------------
-- Table structure for `niveaux`
-- ----------------------------
DROP TABLE IF EXISTS `niveaux`;
CREATE TABLE `niveaux` (
  `codeNiveau` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT '',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `identifiant` varchar(50) NOT NULL,
  `typeElement` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeNiveau`),
  KEY `niveaux_del` (`deleted`),
  KEY `niveaux_dateModif` (`dateModif`),
  KEY `niveaux_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `niveaux_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=27785339 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of niveaux
-- ----------------------------
INSERT INTO `niveaux` VALUES ('27785299', '16777215', '0', 'LICENCE 1', 'L1', '2022-09-10 06:55:54', '2011-03-03 18:10:35', '0', '99999', '', 'L1', '2');
INSERT INTO `niveaux` VALUES ('27785300', '16777215', '0', 'LICENCE 2', 'L2', '2022-09-10 06:55:56', '2011-03-03 18:10:35', '0', '99999', '', 'L2', '2');
INSERT INTO `niveaux` VALUES ('27785301', '16777215', '0', 'LICENCE 3', 'L3', '2022-09-10 06:55:58', '2011-03-03 18:10:35', '0', '99999', '', 'L3', '2');
INSERT INTO `niveaux` VALUES ('27785302', '16777215', '0', 'MASTER 1', 'M1', '2022-09-10 06:55:59', '2011-03-03 18:10:35', '0', '99999', '', 'M1', '2');
INSERT INTO `niveaux` VALUES ('27785303', '16777215', '0', 'MASTER 2', 'M2', '2022-09-10 06:56:08', '2011-03-03 18:10:35', '0', '99999', '', 'M2', '2');
INSERT INTO `niveaux` VALUES ('27785334', '16777215', '0', 'DOCTORAT', 'DOC', '2022-09-10 06:55:48', '2022-06-30 17:53:22', '0', '99999', '', 'DOC', '2');
INSERT INTO `niveaux` VALUES ('27785335', '16777215', '0', 'LP', 'LP', '2022-09-10 06:55:49', '2022-07-01 12:36:40', '0', '99999', '', 'LP', '2');
INSERT INTO `niveaux` VALUES ('27785337', '16777215', '0', 'NON DIPLOMANT', 'ND', '2022-09-10 06:55:52', '2022-07-01 13:01:54', '0', '99999', '', 'ND', '2');

-- ----------------------------
-- Table structure for `periodes`
-- ----------------------------
DROP TABLE IF EXISTS `periodes`;
CREATE TABLE `periodes` (
  `codePeriode` int(11) NOT NULL AUTO_INCREMENT,
  `codeProprietaire` int(11) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  PRIMARY KEY (`codePeriode`),
  KEY `periodes_del` (`deleted`),
  KEY `periodes_dateModif` (`dateModif`),
  KEY `periodes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `periodes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of periodes
-- ----------------------------

-- ----------------------------
-- Table structure for `periodes_dates`
-- ----------------------------
DROP TABLE IF EXISTS `periodes_dates`;
CREATE TABLE `periodes_dates` (
  `codePeriode` int(11) NOT NULL,
  `date` date NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `periodes_dates_del` (`deleted`),
  KEY `periodes_dates_dateModif` (`dateModif`),
  KEY `periodes_dates_del_ibfk_1` (`codePeriode`),
  KEY `periodes_dates_del_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `periodes_dates_del_ibfk_1` FOREIGN KEY (`codePeriode`) REFERENCES `periodes` (`codePeriode`),
  CONSTRAINT `periodes_dates_del_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of periodes_dates
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations`
-- ----------------------------
DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `codeReservation` int(11) NOT NULL AUTO_INCREMENT,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateReservation` date NOT NULL DEFAULT '2015-01-01',
  `heureReservation` int(5) NOT NULL DEFAULT '0',
  `dureeReservation` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`codeReservation`),
  KEY `reservations_del` (`deleted`),
  KEY `reservations_dateModif` (`dateModif`),
  KEY `reservations_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=97878 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_enseignements`;
CREATE TABLE `reservations_enseignements` (
  `codeReservation` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `reservations_enseignements_del` (`deleted`),
  KEY `reservations_enseignements_dateModif` (`dateModif`),
  KEY `reservations_enseignements_ibfk_1` (`codeReservation`),
  KEY `reservations_enseignements_ibfk_2` (`codeRessource`),
  KEY `reservations_enseignements_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_enseignements_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_enseignements_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `reservations_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_filieres`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_filieres`;
CREATE TABLE `reservations_filieres` (
  `codeReservation` int(11) NOT NULL AUTO_INCREMENT,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateReservation` date NOT NULL DEFAULT '2015-01-01',
  `heureReservation` int(5) NOT NULL DEFAULT '0',
  `dureeReservation` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeReservation`),
  KEY `reservations_filieres_del` (`deleted`),
  KEY `reservations_filieres_dateModif` (`dateModif`),
  KEY `reservations_filieres_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_filieres_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_filieres
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_groupes`;
CREATE TABLE `reservations_groupes` (
  `codeReservation` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `reservations_groupes_del` (`deleted`),
  KEY `reservations_groupes_dateModif` (`dateModif`),
  KEY `reservations_groupes_ibfk_1` (`codeReservation`),
  KEY `reservations_groupes_ibfk_2` (`codeRessource`),
  KEY `reservations_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_groupes_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `reservations_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_historique`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_historique`;
CREATE TABLE `reservations_historique` (
  `codeReservation` int(11) NOT NULL,
  `commentaire` char(250) NOT NULL DEFAULT '',
  `dateReservation` date NOT NULL DEFAULT '2015-01-01',
  `heureReservation` int(5) NOT NULL DEFAULT '0',
  `dureeReservation` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `codeProprietaireModifieur` int(11) NOT NULL,
  `indisponibilite` tinyint(1) NOT NULL DEFAULT '0',
  `idical` varchar(150) NOT NULL DEFAULT '',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1',
  KEY `reservations_historique_del` (`deleted`),
  KEY `reservations_historique_dateModif` (`dateModif`),
  KEY `reservations_historique_ibfk_1` (`codeReservation`),
  KEY `reservations_historique_ibfk_2` (`codeProprietaireModifieur`),
  KEY `reservations_historique_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_historique_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_historique_ibfk_2` FOREIGN KEY (`codeProprietaireModifieur`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `reservations_historique_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_historique
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_materiels`;
CREATE TABLE `reservations_materiels` (
  `codeReservation` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `reservations_materiels_del` (`deleted`),
  KEY `reservations_materiels_dateModif` (`dateModif`),
  KEY `reservations_materiels_ibfk_1` (`codeReservation`),
  KEY `reservations_materiels_ibfk_2` (`codeRessource`),
  KEY `reservations_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_materiels_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `reservations_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_profs`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_profs`;
CREATE TABLE `reservations_profs` (
  `codeReservation` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `reservations_profs_del` (`deleted`),
  KEY `reservations_profs_dateModif` (`dateModif`),
  KEY `reservations_profs_ibfk_1` (`codeReservation`),
  KEY `reservations_profs_ibfk_2` (`codeRessource`),
  KEY `reservations_profs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_profs_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `reservations_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `reservations_salles`
-- ----------------------------
DROP TABLE IF EXISTS `reservations_salles`;
CREATE TABLE `reservations_salles` (
  `codeReservation` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `reservations_salles_del` (`deleted`),
  KEY `reservations_salles_dateModif` (`dateModif`),
  KEY `reservations_salles_ibfk_1` (`codeReservation`),
  KEY `reservations_salles_ibfk_2` (`codeRessource`),
  KEY `reservations_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `reservations_salles_ibfk_1` FOREIGN KEY (`codeReservation`) REFERENCES `reservations` (`codeReservation`),
  CONSTRAINT `reservations_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `reservations_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservations_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_etudiants`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_etudiants`;
CREATE TABLE `ressources_etudiants` (
  `codeEtudiant` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL DEFAULT 'NOM?',
  `prenom` varchar(100) NOT NULL DEFAULT 'PRENOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `identifiant` varchar(50) NOT NULL DEFAULT '',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `typePublic` tinyint(1) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '-1',
  `boursier` tinyint(1) NOT NULL DEFAULT '0',
  `prenom2` varchar(100) NOT NULL,
  `dateNaissance` date NOT NULL DEFAULT '1900-01-01',
  `reel` tinyint(2) NOT NULL DEFAULT '1',
  `handicap` tinyint(1) NOT NULL DEFAULT '0',
  `idNational` varchar(50) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `consultation` tinyint(1) NOT NULL DEFAULT '1',
  `remediation` tinyint(1) NOT NULL DEFAULT '0',
  `sexe` tinyint(1) NOT NULL DEFAULT '0',
  `dateInscription` datetime NOT NULL DEFAULT '1963-04-08 00:00:01',
  PRIMARY KEY (`codeEtudiant`),
  KEY `ressources_etudiants_del` (`deleted`),
  KEY `ressources_etudiants_dateModif` (`dateModif`),
  KEY `ressources_etudiants_ibfk_2` (`codeComposante`),
  KEY `ressources_etudiants_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_etudiants_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `ressources_etudiants_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=52898 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_etudiants
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_groupes`;
CREATE TABLE `ressources_groupes` (
  `codeGroupe` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(250) NOT NULL DEFAULT 'NOM?',
  `quantite` int(10) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `typePublic` tinyint(2) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '-1',
  `codeNiveau` int(11) NOT NULL,
  `codeDiplome` int(11) NOT NULL,
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`codeGroupe`),
  KEY `ressources_groupes_del` (`deleted`),
  KEY `ressources_groupes_dateModif` (`dateModif`),
  KEY `ressources_groupes_ibfk_2` (`codeComposante`),
  KEY `ressources_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_groupes_ibfk_2` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `ressources_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=27989930 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_groupes
-- ----------------------------
INSERT INTO `ressources_groupes` VALUES ('27989926', '16777215', '0', 'LICENCE INFORMATIQUE', '0', 'LIC-INFO', '2022-09-10 06:49:17', '2022-09-10 06:49:17', '0', '99999', '', 'LIC-INFO', '0', '2390', '0', '0', '');
INSERT INTO `ressources_groupes` VALUES ('27989927', '16777215', '0', 'LICENCE INFORMATIQUE 1', '0', 'L1-INFO', '2022-09-10 06:50:01', '2022-09-10 06:50:01', '0', '99999', '', 'L1-INFO', '1', '2390', '0', '0', '');
INSERT INTO `ressources_groupes` VALUES ('27989928', '16777215', '0', 'LICENCE INFORMATIQUE 2', '0', 'L2-INFO', '2022-09-10 06:50:17', '2022-09-10 06:50:17', '0', '99999', '', 'L2-INFO', '1', '2390', '0', '0', '');
INSERT INTO `ressources_groupes` VALUES ('27989929', '16777215', '0', 'LICENCE INFORMATIQUE 3', '0', 'L3-INFO', '2022-09-10 06:50:29', '2022-09-10 06:50:29', '0', '99999', '', 'L3-INFO', '1', '2390', '0', '0', '');

-- ----------------------------
-- Table structure for `ressources_groupes_etudiants`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_groupes_etudiants`;
CREATE TABLE `ressources_groupes_etudiants` (
  `code` bigint(20) NOT NULL AUTO_INCREMENT,
  `codeGroupe` int(11) NOT NULL,
  `codeEtudiant` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  PRIMARY KEY (`code`),
  KEY `ressources_groupes_etudiants_del` (`deleted`),
  KEY `ressources_groupes_etudiants_dateModif` (`dateModif`),
  KEY `ressources_groupes_etudiants_ibfk_1` (`codeEtudiant`),
  KEY `ressources_groupes_etudiants_ibfk_2` (`codeGroupe`),
  KEY `ressources_groupes_etudiants_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_groupes_etudiants_ibfk_1` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  CONSTRAINT `ressources_groupes_etudiants_ibfk_2` FOREIGN KEY (`codeGroupe`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `ressources_groupes_etudiants_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=1827068 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_groupes_etudiants
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_groupes_etudiants_exceptions`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_groupes_etudiants_exceptions`;
CREATE TABLE `ressources_groupes_etudiants_exceptions` (
  `codeEtudiant` int(11) NOT NULL,
  `codeGroupe` int(11) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `ressources_groupes_etudiants_exceptions_del` (`deleted`),
  KEY `ressources_groupes_etudiants_exceptions_dateModif` (`dateModif`),
  KEY `ressources_groupes_etudiants_exceptions_ibfk_1` (`codeEtudiant`),
  KEY `ressources_groupes_etudiants_exceptions_ibfk_2` (`codeGroupe`),
  KEY `ressources_groupes_etudiants_exceptions_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_groupes_etudiants_exceptions_ibfk_1` FOREIGN KEY (`codeEtudiant`) REFERENCES `ressources_etudiants` (`codeEtudiant`),
  CONSTRAINT `ressources_groupes_etudiants_exceptions_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_groupes_etudiants_exceptions
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_materiels`;
CREATE TABLE `ressources_materiels` (
  `codeMateriel` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `codeSalle` int(11) NOT NULL DEFAULT '0',
  `mobile` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`codeMateriel`),
  KEY `ressources_materiels_del` (`deleted`),
  KEY `ressources_materiels_dateModif` (`dateModif`),
  KEY `ressources_materiels_ibfk_1` (`codeComposante`),
  KEY `ressources_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_materiels_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `ressources_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_profs`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_profs`;
CREATE TABLE `ressources_profs` (
  `codeProf` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `prenom` varchar(150) NOT NULL DEFAULT 'PRENOM?',
  `codeGrade` int(11) NOT NULL DEFAULT '0',
  `numero` int(3) NOT NULL DEFAULT '0',
  `rue` varchar(50) NOT NULL DEFAULT '',
  `codePostal` int(5) NOT NULL DEFAULT '0',
  `ville` varchar(50) NOT NULL DEFAULT 'VALENCIENNES',
  `pays` varchar(50) NOT NULL DEFAULT 'FRANCE',
  `telephone1` varchar(10) NOT NULL DEFAULT '327511234',
  `telephone2` varchar(10) NOT NULL DEFAULT '0',
  `codeCnu` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `identifiant` varchar(50) NOT NULL,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `commentaire` varchar(250) NOT NULL,
  `codeComposante` int(11) NOT NULL DEFAULT '-1',
  `photo` mediumblob,
  `titulaire` tinyint(1) NOT NULL,
  `dateValidationDossier` date NOT NULL DEFAULT '2500-01-01',
  `volStatSpecif` int(5) NOT NULL,
  `volCompSpecif` int(5) NOT NULL,
  `identifiantNational` varchar(50) NOT NULL,
  `prenom2` varchar(150) NOT NULL,
  `dateNaissance` date NOT NULL,
  `dateDebutContrat` date NOT NULL DEFAULT '2000-01-01',
  `dateFinContrat` date NOT NULL DEFAULT '5000-01-01',
  `sexe` tinyint(1) NOT NULL DEFAULT '0',
  `consultation` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeProf`),
  KEY `ressources_profs_del` (`deleted`),
  KEY `ressources_profs_dateModif` (`dateModif`),
  KEY `ressources_profs_ibfk_1` (`codeComposante`),
  KEY `ressources_profs_ibfk_2` (`codeGrade`),
  KEY `ressources_profs_ibfk_3` (`codeProprietaire`),
  KEY `ressources_profs_ibfk_4` (`codeCnu`),
  CONSTRAINT `ressources_profs_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `ressources_profs_ibfk_2` FOREIGN KEY (`codeGrade`) REFERENCES `grades` (`codeGrade`),
  CONSTRAINT `ressources_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `ressources_profs_ibfk_4` FOREIGN KEY (`codeCnu`) REFERENCES `cnu` (`codeCNU`)
) ENGINE=InnoDB AUTO_INCREMENT=24720831 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `ressources_salles`
-- ----------------------------
DROP TABLE IF EXISTS `ressources_salles`;
CREATE TABLE `ressources_salles` (
  `codeSalle` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `codeZoneSalle` int(11) NOT NULL DEFAULT '0',
  `capacite` int(5) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL DEFAULT '',
  `surface` int(8) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `codeComposante` int(11) NOT NULL DEFAULT '-1',
  `handicap` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeSalle`),
  KEY `ressources_salles_del` (`deleted`),
  KEY `ressources_salles_dateModif` (`dateModif`),
  KEY `ressources_salles_ibfk_1` (`codeComposante`),
  KEY `ressources_salles_ibfk_2` (`codeZoneSalle`),
  KEY `ressources_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `ressources_salles_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `ressources_salles_ibfk_2` FOREIGN KEY (`codeZoneSalle`) REFERENCES `zones_salles` (`codeZoneSalle`),
  CONSTRAINT `ressources_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=24349832 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ressources_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `seances`
-- ----------------------------
DROP TABLE IF EXISTS `seances`;
CREATE TABLE `seances` (
  `codeSeance` int(11) NOT NULL AUTO_INCREMENT,
  `dateSeance` date NOT NULL DEFAULT '2000-01-01',
  `heureSeance` int(5) NOT NULL DEFAULT '800',
  `dureeSeance` int(5) NOT NULL DEFAULT '100',
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` char(250) NOT NULL DEFAULT '',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `annulee` tinyint(1) NOT NULL DEFAULT '0',
  `controle` tinyint(1) NOT NULL DEFAULT '0',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1',
  `sospresentiel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeSeance`),
  KEY `seances_del` (`deleted`),
  KEY `seances_dateModif` (`dateModif`),
  KEY `seances_ibfk_2` (`codeEnseignement`),
  KEY `seances_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_ibfk_2` FOREIGN KEY (`codeEnseignement`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `seances_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=476150 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_documents`
-- ----------------------------
DROP TABLE IF EXISTS `seances_documents`;
CREATE TABLE `seances_documents` (
  `codeSeance` int(11) NOT NULL,
  `nomFichier` varchar(200) NOT NULL DEFAULT '',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateDebutAcces` datetime NOT NULL,
  `dateFinAcces` datetime NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `commentaire` varchar(150) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_documents
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `seances_groupes`;
CREATE TABLE `seances_groupes` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_groupes_del` (`deleted`),
  KEY `seances_groupes_dateModif` (`dateModif`),
  KEY `seances_groupes_ibfk_1` (`codeSeance`),
  KEY `seances_groupes_ibfk_2` (`codeRessource`),
  KEY `seances_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_groupes_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_groupes_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `seances_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_historique`
-- ----------------------------
DROP TABLE IF EXISTS `seances_historique`;
CREATE TABLE `seances_historique` (
  `codeSeance` int(11) NOT NULL,
  `dateSeance` date NOT NULL DEFAULT '2000-01-01',
  `heureSeance` int(5) NOT NULL DEFAULT '800',
  `dureeSeance` int(5) NOT NULL DEFAULT '100',
  `codeEnseignement` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `commentaire` char(250) NOT NULL DEFAULT '',
  `bloquee` tinyint(1) NOT NULL DEFAULT '0',
  `diffusable` tinyint(1) NOT NULL DEFAULT '1',
  `codeProprietaireModifieur` int(11) NOT NULL,
  `annulee` tinyint(1) NOT NULL DEFAULT '0',
  `controle` tinyint(1) NOT NULL DEFAULT '0',
  `presentiel` tinyint(1) NOT NULL DEFAULT '1',
  KEY `seances_historique_del` (`deleted`),
  KEY `seances_historique_dateModif` (`dateModif`),
  KEY `seances_historique_ibfk_1` (`codeSeance`),
  KEY `seances_historique_ibfk_2` (`codeProprietaireModifieur`),
  KEY `seances_historique_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_historique_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_historique_ibfk_2` FOREIGN KEY (`codeProprietaireModifieur`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `seances_historique_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_historique
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `seances_materiels`;
CREATE TABLE `seances_materiels` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_materiels_del` (`deleted`),
  KEY `seances_materiels_dateModif` (`dateModif`),
  KEY `seances_materiels_ibfk_1` (`codeSeance`),
  KEY `seances_materiels_ibfk_2` (`codeRessource`),
  KEY `seances_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_materiels_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_materiels_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `seances_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_profs`
-- ----------------------------
DROP TABLE IF EXISTS `seances_profs`;
CREATE TABLE `seances_profs` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_profs_del` (`deleted`),
  KEY `seances_profs_dateModif` (`dateModif`),
  KEY `seances_profs_ibfk_1` (`codeSeance`),
  KEY `seances_profs_ibfk_2` (`codeRessource`),
  KEY `seances_profs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_profs_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_profs_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `seances_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_profs_non_comptabilisees`
-- ----------------------------
DROP TABLE IF EXISTS `seances_profs_non_comptabilisees`;
CREATE TABLE `seances_profs_non_comptabilisees` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_profs_non_comptabilisees_del` (`deleted`),
  KEY `seances_profs_non_comptabilisees_dateModif` (`dateModif`),
  KEY `seances_profs_non_comptabilisees_ibfk_1` (`codeSeance`),
  KEY `seances_profs_non_comptabilisees_ibfk_2` (`codeRessource`),
  KEY `seances_profs_non_comptabilisees_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_profs_non_comptabilisees_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_profs_non_comptabilisees_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `seances_profs_non_comptabilisees_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_profs_non_comptabilisees
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_profs_payees`
-- ----------------------------
DROP TABLE IF EXISTS `seances_profs_payees`;
CREATE TABLE `seances_profs_payees` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_profs_payees_del` (`deleted`),
  KEY `seances_profs_payees_dateModif` (`dateModif`),
  KEY `seances_profs_payees_ibfk_1` (`codeSeance`),
  KEY `seances_profs_payees_ibfk_2` (`codeRessource`),
  KEY `seances_profs_payees_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_profs_payees_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_profs_payees_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `seances_profs_payees_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_profs_payees
-- ----------------------------

-- ----------------------------
-- Table structure for `seances_salles`
-- ----------------------------
DROP TABLE IF EXISTS `seances_salles`;
CREATE TABLE `seances_salles` (
  `codeSeance` int(11) NOT NULL DEFAULT '0',
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `seances_salles_del` (`deleted`),
  KEY `seances_salles_dateModif` (`dateModif`),
  KEY `seances_salles_ibfk_1` (`codeSeance`),
  KEY `seances_salles_ibfk_2` (`codeRessource`),
  KEY `seances_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `seances_salles_ibfk_1` FOREIGN KEY (`codeSeance`) REFERENCES `seances` (`codeSeance`),
  CONSTRAINT `seances_salles_ibfk_2` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `seances_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seances_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `typage_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `typage_materiels`;
CREATE TABLE `typage_materiels` (
  `codeMateriel` int(11) NOT NULL DEFAULT '0',
  `codeType` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `typage_materiels_del` (`deleted`),
  KEY `typage_materiels_dateModif` (`dateModif`),
  KEY `typage_materiels_ibfk_1` (`codeType`),
  KEY `typage_materiels_ibfk_2` (`codeMateriel`),
  KEY `typage_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `typage_materiels_ibfk_1` FOREIGN KEY (`codeType`) REFERENCES `types_materiels` (`codeTypeMateriel`),
  CONSTRAINT `typage_materiels_ibfk_2` FOREIGN KEY (`codeMateriel`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `typage_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of typage_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `typage_salles`
-- ----------------------------
DROP TABLE IF EXISTS `typage_salles`;
CREATE TABLE `typage_salles` (
  `codeSalle` int(11) NOT NULL DEFAULT '0',
  `codeType` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `typage_salles_del` (`deleted`),
  KEY `typage_salles_dateModif` (`dateModif`),
  KEY `typage_salles_ibfk_1` (`codeType`),
  KEY `typage_salles_ibfk_2` (`codeSalle`),
  KEY `typage_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `typage_salles_ibfk_1` FOREIGN KEY (`codeType`) REFERENCES `types_salles` (`codeTypeSalle`),
  CONSTRAINT `typage_salles_ibfk_2` FOREIGN KEY (`codeSalle`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `typage_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of typage_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `types_activites`
-- ----------------------------
DROP TABLE IF EXISTS `types_activites`;
CREATE TABLE `types_activites` (
  `codeTypeActivite` int(11) NOT NULL AUTO_INCREMENT,
  `identifiant` varchar(50) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `couleurFond` bigint(20) NOT NULL,
  `couleurPolice` bigint(20) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `ponderation` float(10,9) DEFAULT '1.000000000',
  `forfaitPossible` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  PRIMARY KEY (`codeTypeActivite`),
  KEY `types_activites_dateModif` (`dateModif`),
  KEY `types_activites_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `types_activites_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of types_activites
-- ----------------------------
INSERT INTO `types_activites` VALUES ('1', '1', 'Cours magistral', 'CM', '', '15132415', '0', '2020-07-02 08:40:41', '1002', '0', '1.500000000', '0', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('2', '2', 'Travaux dirigés', 'TD', '', '16771304', '0', '2020-07-02 08:40:41', '1002', '0', '1.000000000', '0', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('3', '3', 'Travaux pratiques', 'TP', '', '13172680', '0', '2020-07-15 07:54:45', '1002', '0', '1.000000000', '0', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('4', '4', 'Projets', 'PRO', '', '11337644', '0', '2020-07-02 08:40:42', '1002', '0', '1.000000000', '1', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('6', '6', 'Stages', 'STA', '', '13434879', '0', '2020-07-02 08:40:43', '1002', '0', '1.000000000', '1', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('7', '7', 'Administration', 'ADM', '', '14277081', '0', '2020-07-02 08:40:43', '1002', '0', '0.000000000', '1', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('8', '8', 'Tutorat', 'TUT', '', '7321599', '0', '2020-07-02 08:40:44', '1002', '0', '1.000000000', '1', '2000-01-01 00:00:00');
INSERT INTO `types_activites` VALUES ('9', '9', 'Devoir surveillé', 'DS', '', '255', '16777215', '2020-07-02 08:40:44', '1002', '0', '0.000000000', '0', '2000-01-01 00:00:00');

-- ----------------------------
-- Table structure for `types_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `types_materiels`;
CREATE TABLE `types_materiels` (
  `codeTypeMateriel` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  PRIMARY KEY (`codeTypeMateriel`),
  KEY `types_materiels_del` (`deleted`),
  KEY `types_materiels_dateModif` (`dateModif`),
  KEY `types_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `types_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of types_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `types_salles`
-- ----------------------------
DROP TABLE IF EXISTS `types_salles`;
CREATE TABLE `types_salles` (
  `codeTypeSalle` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  PRIMARY KEY (`codeTypeSalle`),
  KEY `types_salles_del` (`deleted`),
  KEY `types_salles_dateModif` (`dateModif`),
  KEY `types_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `types_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=1903 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of types_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE `utilisateurs` (
  `codeUtilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL DEFAULT 'NOM?',
  `password` varchar(50) NOT NULL DEFAULT 'PASS?',
  `droits` varchar(250) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `arret` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL DEFAULT '',
  `intervalleSynchronisation` int(11) NOT NULL DEFAULT '600000',
  `estConnecte` tinyint(1) NOT NULL DEFAULT '0',
  `nom` varchar(100) NOT NULL DEFAULT '',
  `prenom` varchar(100) NOT NULL DEFAULT 'PRENOM?',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `historique` tinyint(1) NOT NULL,
  `delaiModification` int(5) NOT NULL DEFAULT '9999',
  `versionImposee` varchar(10) NOT NULL,
  `estModele` tinyint(1) NOT NULL DEFAULT '0',
  `fonctionnel` tinyint(1) NOT NULL DEFAULT '0',
  `initParam` int(3) NOT NULL DEFAULT '-1',
  `dureeMaxConnexion` int(10) NOT NULL DEFAULT '999999',
  `adresseMAC` varchar(20) NOT NULL,
  `verifNouvelleVersion` tinyint(1) NOT NULL DEFAULT '1',
  `methodeDeCalcul` tinyint(1) NOT NULL DEFAULT '1',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `alarme1` int(5) NOT NULL DEFAULT '-1',
  `alarme2` int(5) NOT NULL DEFAULT '-1',
  `dateDebut` date NOT NULL DEFAULT '2000-01-01',
  `dateFin` date NOT NULL DEFAULT '3000-01-01',
  `HostNameDocument` varchar(100) NOT NULL DEFAULT '',
  `PortDocument` int(5) NOT NULL DEFAULT '21',
  `UsernameDocument` varchar(100) NOT NULL DEFAULT '',
  `PasswordDocument` varchar(100) NOT NULL DEFAULT '',
  `RepertoireDocument` varchar(200) NOT NULL DEFAULT '',
  `httpDocument` varchar(200) NOT NULL DEFAULT '',
  `modeDocument` tinyint(1) NOT NULL DEFAULT '1',
  `sosPass` varchar(50) NOT NULL DEFAULT '',
  `consultationWeb` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeUtilisateur`),
  KEY `utilisateurs_ibfk_3` (`codeProprietaire`),
  KEY `utilisateurs_del` (`deleted`),
  KEY `utilisateurs_cdProprietaire` (`codeProprietaire`),
  KEY `utilisateurs_dateModif` (`dateModif`),
  KEY `utilisateurs_ibfk_2` (`codeComposante`)
) ENGINE=InnoDB AUTO_INCREMENT=1260 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs
-- ----------------------------
INSERT INTO `utilisateurs` VALUES ('1', 'ADMIN', 'kGyxMVAmCEMGwUvhVgAsJA==', '1111111111111111110110100101011101111111111111111111111011100001111111011101100111111111011011111110111111111111111011111110110100111111001011', '2022-09-10 06:54:53', '0', '0', '99999', '', '2022-09-09 -- 24/08/2022 16:51:04', '600000', '0', 'ADMIN', 'ADMIN', '', '0', '30', '', '0', '0', '1', '600', '', '1', '2', '0', '5', '10', '2021-01-27', '2024-01-27', '', '21', '', '', '', '', '1', '', '0');

-- ----------------------------
-- Table structure for `utilisateurs-sos`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs-sos`;
CREATE TABLE `utilisateurs-sos` (
  `codeUtilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL DEFAULT 'NOM?',
  `password` varchar(50) NOT NULL DEFAULT 'PASS?',
  `droits` varchar(250) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `arret` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL DEFAULT '',
  `intervalleSynchronisation` int(11) NOT NULL DEFAULT '600000',
  `estConnecte` tinyint(1) NOT NULL DEFAULT '0',
  `nom` varchar(100) NOT NULL DEFAULT '',
  `prenom` varchar(100) NOT NULL DEFAULT 'PRENOM?',
  `commentaire` varchar(250) NOT NULL DEFAULT '',
  `historique` tinyint(1) NOT NULL,
  `delaiModification` int(5) NOT NULL DEFAULT '9999',
  `versionImposee` varchar(10) NOT NULL,
  `estModele` tinyint(1) NOT NULL DEFAULT '0',
  `fonctionnel` tinyint(1) NOT NULL DEFAULT '0',
  `initParam` int(3) NOT NULL DEFAULT '-1',
  `dureeMaxConnexion` int(10) NOT NULL DEFAULT '999999',
  `adresseMAC` varchar(20) NOT NULL,
  `verifNouvelleVersion` tinyint(1) NOT NULL DEFAULT '1',
  `methodeDeCalcul` tinyint(1) NOT NULL DEFAULT '1',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `alarme1` int(5) NOT NULL DEFAULT '-1',
  `alarme2` int(5) NOT NULL DEFAULT '-1',
  `dateDebut` date NOT NULL DEFAULT '2000-01-01',
  `dateFin` date NOT NULL DEFAULT '3000-01-01',
  `HostNameDocument` varchar(100) NOT NULL DEFAULT '',
  `PortDocument` int(5) NOT NULL DEFAULT '21',
  `UsernameDocument` varchar(100) NOT NULL DEFAULT '',
  `PasswordDocument` varchar(100) NOT NULL DEFAULT '',
  `RepertoireDocument` varchar(200) NOT NULL DEFAULT '',
  `httpDocument` varchar(200) NOT NULL DEFAULT '',
  `modeDocument` tinyint(1) NOT NULL DEFAULT '1',
  `sosPass` varchar(50) NOT NULL DEFAULT '',
  `consultationWeb` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codeUtilisateur`),
  KEY `utilisateurs_ibfk_3` (`codeProprietaire`),
  KEY `utilisateurs_del` (`deleted`),
  KEY `utilisateurs_cdProprietaire` (`codeProprietaire`),
  KEY `utilisateurs_dateModif` (`dateModif`),
  KEY `utilisateurs_ibfk_2` (`codeComposante`)
) ENGINE=InnoDB AUTO_INCREMENT=1257 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs-sos
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_actions`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_actions`;
CREATE TABLE `utilisateurs_actions` (
  `codeAction` int(11) NOT NULL AUTO_INCREMENT,
  `dateDebut` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateFin` datetime NOT NULL,
  `achevee` tinyint(1) NOT NULL DEFAULT '0',
  `typeAction` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = ajout; 2 = modification; 3 = destruction',
  `codeUtilisateur` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `numeroCommande` int(11) NOT NULL,
  PRIMARY KEY (`codeAction`),
  KEY `utilisateurs_actions_del` (`deleted`),
  KEY `utilisateurs_actions_ibfk_2` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_actions_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=400271 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_actions
-- ----------------------------
INSERT INTO `utilisateurs_actions` VALUES ('400263', '2022-09-09 09:36:04', '2022-09-09 09:36:04', '1', '1', '1', '0', '3284243');
INSERT INTO `utilisateurs_actions` VALUES ('400264', '2022-09-09 09:37:37', '2022-09-09 09:37:37', '1', '2', '1', '0', '3284244');
INSERT INTO `utilisateurs_actions` VALUES ('400265', '2022-09-09 09:39:55', '2022-09-09 09:39:55', '1', '1', '1', '0', '3284245');
INSERT INTO `utilisateurs_actions` VALUES ('400266', '2022-09-10 06:49:17', '2022-09-10 06:49:17', '1', '1', '1', '0', '3284246');
INSERT INTO `utilisateurs_actions` VALUES ('400267', '2022-09-10 06:50:01', '2022-09-10 06:50:01', '1', '1', '1', '0', '3284247');
INSERT INTO `utilisateurs_actions` VALUES ('400268', '2022-09-10 06:50:17', '2022-09-10 06:50:17', '1', '1', '1', '0', '3284248');
INSERT INTO `utilisateurs_actions` VALUES ('400269', '2022-09-10 06:50:29', '2022-09-10 06:50:29', '1', '1', '1', '0', '3284249');
INSERT INTO `utilisateurs_actions` VALUES ('400270', '2022-09-10 06:53:03', '2022-09-10 06:53:03', '1', '4', '1', '0', '3284250');

-- ----------------------------
-- Table structure for `utilisateurs_appartenances_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_appartenances_groupes`;
CREATE TABLE `utilisateurs_appartenances_groupes` (
  `codeUtilisateur` int(11) NOT NULL DEFAULT '0',
  `codeGroupeUtilisateurs` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  KEY `utilisateurs_appartenances_groupes_util` (`codeUtilisateur`),
  KEY `utilisateurs_appartenances_groupes_grutil` (`codeGroupeUtilisateurs`),
  KEY `utilisateurs_appartenances_groupes_del` (`deleted`),
  CONSTRAINT `utilisateurs_appartenances_groupes_ibfk_1` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_appartenances_groupes_ibfk_2` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_appartenances_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_calendriers_enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_calendriers_enseignements`;
CREATE TABLE `utilisateurs_calendriers_enseignements` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `utilisateurs_calendriers_enseignements_ibfk_1` (`codeRessource`),
  KEY `utilisateurs_calendriers_enseignements_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_calendriers_enseignements_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`),
  CONSTRAINT `utilisateurs_calendriers_enseignements_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_calendriers_enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_calendriers_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_calendriers_groupes`;
CREATE TABLE `utilisateurs_calendriers_groupes` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `utilisateurs_calendriers_groupes_ibfk_1` (`codeRessource`),
  KEY `utilisateurs_calendriers_groupes_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_calendriers_groupes_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`),
  CONSTRAINT `utilisateurs_calendriers_groupes_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_calendriers_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_calendriers_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_calendriers_materiels`;
CREATE TABLE `utilisateurs_calendriers_materiels` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `utilisateurs_calendriers_materiels_ibfk_1` (`codeRessource`),
  KEY `utilisateurs_calendriers_materiels_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_calendriers_materiels_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`),
  CONSTRAINT `utilisateurs_calendriers_materiels_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_calendriers_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_calendriers_profs`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_calendriers_profs`;
CREATE TABLE `utilisateurs_calendriers_profs` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `utilisateurs_calendriers_profs_ibfk_1` (`codeRessource`),
  KEY `utilisateurs_calendriers_profs_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_calendriers_profs_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`),
  CONSTRAINT `utilisateurs_calendriers_profs_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_calendriers_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_calendriers_salles`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_calendriers_salles`;
CREATE TABLE `utilisateurs_calendriers_salles` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `deleted` int(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `utilisateurs_calendriers_salles_ibfk_1` (`codeRessource`),
  KEY `utilisateurs_calendriers_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_calendriers_salles_ibfk_1` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`),
  CONSTRAINT `utilisateurs_calendriers_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_calendriers_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_composantes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_composantes`;
CREATE TABLE `utilisateurs_composantes` (
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `codeUtilisateur` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  KEY `utilisateurs_composantes_del` (`deleted`),
  KEY `utilisateurs_composantes_ibfk_1` (`codeComposante`),
  KEY `utilisateurs_composantes_ibfk_3` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_composantes_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `utilisateurs_composantes_ibfk_3` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_composantes
-- ----------------------------
INSERT INTO `utilisateurs_composantes` VALUES ('2390', '1', '0');

-- ----------------------------
-- Table structure for `utilisateurs_composantes_defaut`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_composantes_defaut`;
CREATE TABLE `utilisateurs_composantes_defaut` (
  `codeUtilisateur` int(11) NOT NULL DEFAULT '0',
  `codeComposante` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL,
  `typeDonnee` tinyint(2) NOT NULL,
  KEY `utilisateurs_composantes_defaut_del` (`deleted`),
  KEY `utilisateurs_composantes_defaut_ibfk_1` (`codeComposante`),
  KEY `utilisateurs_composantes_defaut_ibfk_3` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_composantes_defaut_ibfk_1` FOREIGN KEY (`codeComposante`) REFERENCES `composantes` (`codeComposante`),
  CONSTRAINT `utilisateurs_composantes_defaut_ibfk_3` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_composantes_defaut
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_connexions`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_connexions`;
CREATE TABLE `utilisateurs_connexions` (
  `codeUtilisateur` int(11) NOT NULL DEFAULT '0',
  `dateConnexion` datetime NOT NULL DEFAULT '3000-01-01 01:01:01',
  `dateDeconnexion` datetime NOT NULL DEFAULT '2000-01-01 01:01:01',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `numeroSession` int(11) NOT NULL AUTO_INCREMENT,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `adresseMac` varchar(20) NOT NULL,
  PRIMARY KEY (`numeroSession`),
  KEY `utilisateurs_connexions_ibfk_3` (`codeUtilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=337590 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_connexions
-- ----------------------------
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:35:16', '2022-09-09 09:36:25', '0.0.0.0', '337581', '2022-09-09 09:36:25', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:37:14', '2022-09-09 09:40:57', '0.0.0.0', '337582', '2022-09-09 09:40:57', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:46:04', '2022-09-09 09:46:35', '0.0.0.0', '337583', '2022-09-09 09:46:35', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:47:43', '2022-09-09 09:48:27', '0.0.0.0', '337584', '2022-09-09 09:48:27', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:54:03', '2022-09-09 09:54:45', '0.0.0.0', '337585', '2022-09-09 09:54:45', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 09:55:58', '2022-09-09 09:57:09', '0.0.0.0', '337586', '2022-09-09 09:57:09', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-09 10:07:08', '2022-09-09 10:09:12', '0.0.0.0', '337587', '2022-09-09 10:09:12', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-10 06:48:34', '2022-09-10 06:53:24', '0.0.0.0', '337588', '2022-09-10 06:53:24', '00-0C-29-2F-E6-12');
INSERT INTO `utilisateurs_connexions` VALUES ('1', '2022-09-10 06:53:41', '2022-09-10 06:54:53', '0.0.0.0', '337589', '2022-09-10 06:54:53', '00-0C-29-2F-E6-12');

-- ----------------------------
-- Table structure for `utilisateurs_domaines`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_domaines`;
CREATE TABLE `utilisateurs_domaines` (
  `codeDomaine` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`codeDomaine`),
  KEY `utilisateurs_domaines_del` (`deleted`),
  KEY `utilisateurs_domaines_cddom` (`codeDomaine`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_domaines
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_domaines_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_domaines_groupes`;
CREATE TABLE `utilisateurs_domaines_groupes` (
  `codeDomaine` int(11) NOT NULL,
  `codeGroupeUtilisateurs` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  KEY `utilisateurs_domaines_groupes_del` (`deleted`),
  KEY `utilisateurs_domaines_groupes_ibfk_2` (`codeDomaine`),
  KEY `utilisateurs_domaines_groupes_ibfk_3` (`codeGroupeUtilisateurs`),
  CONSTRAINT `utilisateurs_domaines_groupes_ibfk_2` FOREIGN KEY (`codeDomaine`) REFERENCES `utilisateurs_domaines` (`codeDomaine`),
  CONSTRAINT `utilisateurs_domaines_groupes_ibfk_3` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_domaines_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages`;
CREATE TABLE `utilisateurs_filtrages` (
  `codeFiltrage` int(11) NOT NULL AUTO_INCREMENT,
  `nomFiltrage` varchar(150) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL,
  `codeProprietaire` int(11) NOT NULL,
  `typeDeDonnees` tinyint(2) NOT NULL,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `selectionDefaut` tinyint(1) NOT NULL,
  PRIMARY KEY (`codeFiltrage`),
  KEY `utilisateurs_filtrages_del` (`deleted`),
  KEY `utilisateurs_filtrages_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=3958 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_composantes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_composantes`;
CREATE TABLE `utilisateurs_filtrages_composantes` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_composantes_del` (`deleted`),
  KEY `utilisateurs_filtrages_composantes_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_composantes_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_composantes_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_composantes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `composantes` (`codeComposante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_composantes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_diplomes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_diplomes`;
CREATE TABLE `utilisateurs_filtrages_diplomes` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_diplomes_del` (`deleted`),
  KEY `utilisateurs_filtrages_diplomes_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_diplomes_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_diplomes_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_diplomes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `diplomes` (`codeDiplome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_diplomes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_enseignements`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_enseignements`;
CREATE TABLE `utilisateurs_filtrages_enseignements` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_enseignements_del` (`deleted`),
  KEY `utilisateurs_filtrages_enseignements_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_enseignements_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_enseignements_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_enseignements_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `enseignements` (`codeEnseignement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_enseignements
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_etudiants`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_etudiants`;
CREATE TABLE `utilisateurs_filtrages_etudiants` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_etudiants_del` (`deleted`),
  KEY `utilisateurs_filtrages_etudiants_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_etudiants_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_etudiants_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_etudiants_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_etudiants` (`codeEtudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_etudiants
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_groupes`;
CREATE TABLE `utilisateurs_filtrages_groupes` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_groupes_del` (`deleted`),
  KEY `utilisateurs_filtrages_groupes_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_groupes_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_groupes_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_groupes_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_groupes` (`codeGroupe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_materiels`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_materiels`;
CREATE TABLE `utilisateurs_filtrages_materiels` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_materiels_del` (`deleted`),
  KEY `utilisateurs_filtrages_materiels_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_materiels_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_materiels_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_materiels_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_materiels` (`codeMateriel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_materiels
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_matieres`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_matieres`;
CREATE TABLE `utilisateurs_filtrages_matieres` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_matieres_del` (`deleted`),
  KEY `utilisateurs_filtrages_matieres_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_matieres_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_matieres_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_matieres_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `matieres` (`codeMatiere`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_matieres
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_niveaux`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_niveaux`;
CREATE TABLE `utilisateurs_filtrages_niveaux` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_niveaux
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_profs`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_profs`;
CREATE TABLE `utilisateurs_filtrages_profs` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_profs_del` (`deleted`),
  KEY `utilisateurs_filtrages_profs_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_profs_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_profs_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_profs_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_profs_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_profs_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_profs` (`codeProf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_filtrages_salles`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_filtrages_salles`;
CREATE TABLE `utilisateurs_filtrages_salles` (
  `codeProprietaire` int(11) NOT NULL,
  `codeRessource` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `codeFiltrage` int(11) NOT NULL,
  KEY `utilisateurs_filtrages_salles_del` (`deleted`),
  KEY `utilisateurs_filtrages_salles_ibfk_1` (`codeFiltrage`),
  KEY `utilisateurs_filtrages_salles_ibfk_2` (`codeProprietaire`),
  KEY `utilisateurs_filtrages_salles_ibfk_3` (`codeRessource`),
  CONSTRAINT `utilisateurs_filtrages_salles_ibfk_1` FOREIGN KEY (`codeFiltrage`) REFERENCES `utilisateurs_filtrages` (`codeFiltrage`),
  CONSTRAINT `utilisateurs_filtrages_salles_ibfk_2` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`),
  CONSTRAINT `utilisateurs_filtrages_salles_ibfk_3` FOREIGN KEY (`codeRessource`) REFERENCES `ressources_salles` (`codeSalle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_filtrages_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_groupes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_groupes`;
CREATE TABLE `utilisateurs_groupes` (
  `codeGroupeUtilisateurs` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL DEFAULT 'NOM?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `commentaire` varchar(250) NOT NULL,
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `dateDebut` date NOT NULL DEFAULT '2000-01-01',
  `dateFin` date NOT NULL DEFAULT '3000-01-01',
  PRIMARY KEY (`codeGroupeUtilisateurs`),
  KEY `utilisateurs_groupes_del` (`deleted`),
  KEY `utilisateurs_groupes_grutil` (`codeGroupeUtilisateurs`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_groupes
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_groupeutilisateurs_droits`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_groupeutilisateurs_droits`;
CREATE TABLE `utilisateurs_groupeutilisateurs_droits` (
  `codeUtilisateur` int(11) NOT NULL,
  `codeGroupeUtilisateurs` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `droits` varchar(250) NOT NULL,
  `dateDebut` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateFin` datetime NOT NULL DEFAULT '3000-01-01 00:00:00',
  KEY `utilisateurs_groupeutilisateurs_droits_del` (`deleted`),
  KEY `utilisateurs_groupeutilisateurs_droits_ibfk_2` (`codeUtilisateur`),
  KEY `utilisateurs_groupeutilisateurs_droits_ibfk_3` (`codeGroupeUtilisateurs`),
  CONSTRAINT `utilisateurs_groupeutilisateurs_droits_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_groupeutilisateurs_droits_ibfk_3` FOREIGN KEY (`codeGroupeUtilisateurs`) REFERENCES `utilisateurs_groupes` (`codeGroupeUtilisateurs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_groupeutilisateurs_droits
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_messages`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_messages`;
CREATE TABLE `utilisateurs_messages` (
  `codeMessage` bigint(10) NOT NULL AUTO_INCREMENT,
  `dateCreation` datetime NOT NULL,
  `dateModification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `debutDiffusion` datetime NOT NULL,
  `finDiffusion` datetime NOT NULL,
  `message` text NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaireRedacteur` bigint(10) NOT NULL,
  `objet` varchar(255) NOT NULL DEFAULT '',
  `nbAffichages` int(3) NOT NULL DEFAULT '2',
  PRIMARY KEY (`codeMessage`)
) ENGINE=InnoDB AUTO_INCREMENT=30387 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_messages
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_messages_lectures`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_messages_lectures`;
CREATE TABLE `utilisateurs_messages_lectures` (
  `codeProprietaireLecteur` bigint(10) NOT NULL,
  `codeMessage` bigint(10) NOT NULL,
  `dateLecture` datetime NOT NULL DEFAULT '2000-01-01 00:00:01',
  `nbAffichagesFaits` int(3) NOT NULL DEFAULT '0',
  KEY `idx_codePropLect` (`codeProprietaireLecteur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_messages_lectures
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_modeles`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_modeles`;
CREATE TABLE `utilisateurs_modeles` (
  `codeUtilisateur` int(11) NOT NULL,
  `codeModele` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_modeles
-- ----------------------------

-- ----------------------------
-- Table structure for `utilisateurs_numeros_commandes`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_numeros_commandes`;
CREATE TABLE `utilisateurs_numeros_commandes` (
  `numeroCommande` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `typeCommande` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = ajout; 2 = modification; 3 = destruction',
  `codeUtilisateur` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`numeroCommande`),
  KEY `utilisateurs_numeros_commandes_del` (`deleted`),
  KEY `utilisateurs_numeros_commandes_ibfk_2` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_numeros_commandes_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=3284251 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_numeros_commandes
-- ----------------------------
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284243', '2022-09-09 09:36:04', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284244', '2022-09-09 09:37:37', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284245', '2022-09-09 09:39:55', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284246', '2022-09-10 06:49:17', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284247', '2022-09-10 06:50:01', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284248', '2022-09-10 06:50:17', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284249', '2022-09-10 06:50:29', '1', '1', '0');
INSERT INTO `utilisateurs_numeros_commandes` VALUES ('3284250', '2022-09-10 06:53:03', '1', '1', '0');

-- ----------------------------
-- Table structure for `utilisateurs_parametres`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_parametres`;
CREATE TABLE `utilisateurs_parametres` (
  `nomParametre` int(5) NOT NULL,
  `valeurParametre` varchar(50) NOT NULL DEFAULT '',
  `commentaireParametre` varchar(250) NOT NULL DEFAULT '',
  `codeUtilisateur` int(11) NOT NULL,
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rubriqueParametre` int(5) NOT NULL,
  `champParametre` varchar(50) NOT NULL,
  `adresseMAC` varchar(20) DEFAULT NULL,
  KEY `utilisateurs_parametres_ibfk_2` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_parametres_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_parametres
-- ----------------------------
INSERT INTO `utilisateurs_parametres` VALUES ('1', '-23#8#1#3#2#', '', '1', '2022-09-09 09:36:23', '0', 'AFFICHAGE PERSONALISE', null);
INSERT INTO `utilisateurs_parametres` VALUES ('2', '-23#8#1#3#2#', '', '1', '2022-09-09 09:36:23', '0', 'IMPRESSION PERSONALISE', null);
INSERT INTO `utilisateurs_parametres` VALUES ('44', '3306', 'K_PORT_DATABASE', '1', '2022-09-10 06:54:51', '4', '', null);
INSERT INTO `utilisateurs_parametres` VALUES ('19', 'bdvt', 'K_NOM_DATABASE', '1', '2022-09-10 06:54:51', '2', '', null);
INSERT INTO `utilisateurs_parametres` VALUES ('20', '127.0.0.1', 'K_SERVEUR_DATABASE', '1', '2022-09-10 06:54:51', '2', '', null);
INSERT INTO `utilisateurs_parametres` VALUES ('21', 'root', 'K_USERNAME_DATABASE', '1', '2022-09-10 06:54:51', '2', '', null);
INSERT INTO `utilisateurs_parametres` VALUES ('22', 'C:\\VT\\', 'K_REPERTOIRE_DEFAUT', '1', '2022-09-10 06:54:51', '2', '', null);

-- ----------------------------
-- Table structure for `utilisateurs_synchronisations`
-- ----------------------------
DROP TABLE IF EXISTS `utilisateurs_synchronisations`;
CREATE TABLE `utilisateurs_synchronisations` (
  `codeUtilisateur` int(11) NOT NULL,
  `dateSynchronisation` datetime NOT NULL,
  KEY `utilisateurs_synchronisations_ibfk_2` (`codeUtilisateur`),
  CONSTRAINT `utilisateurs_synchronisations_ibfk_2` FOREIGN KEY (`codeUtilisateur`) REFERENCES `utilisateurs` (`codeUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of utilisateurs_synchronisations
-- ----------------------------

-- ----------------------------
-- Table structure for `visiteurs`
-- ----------------------------
DROP TABLE IF EXISTS `visiteurs`;
CREATE TABLE `visiteurs` (
  `codeRessource` int(11) NOT NULL DEFAULT '0',
  `heureEtDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of visiteurs
-- ----------------------------

-- ----------------------------
-- Table structure for `volumes_composantes_profs`
-- ----------------------------
DROP TABLE IF EXISTS `volumes_composantes_profs`;
CREATE TABLE `volumes_composantes_profs` (
  `codeProf` int(11) NOT NULL,
  `codeComposante` int(11) NOT NULL,
  `volume` int(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `codeProprietaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of volumes_composantes_profs
-- ----------------------------

-- ----------------------------
-- Table structure for `zones_salles`
-- ----------------------------
DROP TABLE IF EXISTS `zones_salles`;
CREATE TABLE `zones_salles` (
  `codeZoneSalle` int(11) NOT NULL AUTO_INCREMENT,
  `couleurFond` bigint(20) NOT NULL DEFAULT '0',
  `couleurPolice` bigint(20) NOT NULL DEFAULT '0',
  `nom` varchar(150) NOT NULL DEFAULT 'ZONE?',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(50) NOT NULL,
  `commentaire` varchar(250) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  PRIMARY KEY (`codeZoneSalle`),
  KEY `zones_salles_del` (`deleted`),
  KEY `zones_salles_dateModif` (`dateModif`),
  KEY `zones_salles_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `zones_salles_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=1389587 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zones_salles
-- ----------------------------

-- ----------------------------
-- Table structure for `zones_temps`
-- ----------------------------
DROP TABLE IF EXISTS `zones_temps`;
CREATE TABLE `zones_temps` (
  `codeZoneSalle1` int(11) NOT NULL DEFAULT '0',
  `codeZoneSalle2` int(11) NOT NULL DEFAULT '0',
  `tempsInterZone` int(5) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `codeProprietaire` int(11) NOT NULL DEFAULT '0',
  `dateModif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreation` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  KEY `zones_temps_del` (`deleted`),
  KEY `zones_temps_dateModif` (`dateModif`),
  KEY `zones_temps_ibfk_1` (`codeZoneSalle1`),
  KEY `zones_temps_ibfk_2` (`codeZoneSalle2`),
  KEY `zones_temps_ibfk_3` (`codeProprietaire`),
  CONSTRAINT `zones_temps_ibfk_1` FOREIGN KEY (`codeZoneSalle1`) REFERENCES `zones_salles` (`codeZoneSalle`),
  CONSTRAINT `zones_temps_ibfk_2` FOREIGN KEY (`codeZoneSalle2`) REFERENCES `zones_salles` (`codeZoneSalle`),
  CONSTRAINT `zones_temps_ibfk_3` FOREIGN KEY (`codeProprietaire`) REFERENCES `utilisateurs` (`codeProprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zones_temps
-- ----------------------------
