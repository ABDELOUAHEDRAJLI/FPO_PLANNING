<?php

session_start();

include("config.php");
error_reporting(E_ALL);
//récupération de variables

$lar=$_GET['lar'];
$hau=$_GET['hau'];
$current_year=$_GET['current_year'];
$current_week=$_GET['current_week'];

if(isset($_GET['horiz']))
{
 $horizon=$_GET['horiz'];
}
else 
{
$horizon=1;
}

if(isset($_GET['jour']))
{
 $jour=$_GET['jour'];
}
else 
{
$jour=0;
}

if(isset($_GET['classement']))
{
 $classement=$_GET['classement'];
}
else 
{
$classement="chrono";
}
if(!isset($_GET['disconnect']))
{
$_GET['disconnect']="";
}
if(isset($_GET['code_seance']))
{
 $code_de_la_seance=$_GET['code_seance'];
}
else 
{
$code_de_la_seance=0;
}
if (isset ($_GET['annee_scolaire']))
{
$annee_scolaire_choisie=$_GET['annee_scolaire'];
}
else 
{
$annee_scolaire_choisie=$nbdebdd-1;
}

if (isset($_GET['current_student']))
{
$current_student=$_GET['current_student'];
}
//initialisation variables
$nom_prof_avant="";
$nom_groupe_avant="";
$nom_salle_avant="";
$nom_type_seance_avant="";

//choix de la BDD
$dbh=null;

	$base_a_utiliser=$base[$annee_scolaire_choisie];
		try
		{
		$dbh=new PDO("mysql:host=$serveur;dbname=$base_a_utiliser;charset=UTF8",$user,$pass);
		$dbh->exec('SET NAMES utf8');
		}

		catch(PDOException $e)
		{
		die("erreur ! : " .$e->getMessage());
		}



//recuperation de la date du jour pour l'afficher au dessus du tableau
$jour=date('d');
$mois=date('m');
$annee=date('y');
$heure=date('H');
$minute=date('i');
	
	
	






$fichier="";













if (isset ($_GET['selec_module']))
{

$nom_module=$_GET['selec_module']."\_"; // j'ai mis un \ devant le _ afin d'echapper le caractère


$fichier="";
	$nom_du_module=explode("_",$_GET['selec_module']);
	
$fichier.="Détails du module ".$nom_du_module[1]."\n";	
$fichier.="Généré le ".$jour."/".$mois."/".$annee." à ".$heure."h".$minute."\n"."\n";

$fichier.='Date;Semaine;Groupe;Type;Enseignement;Profs;Salles;Commentaires;Heure de début;Durée;Présentiel;Effectué;Cumul'."\n";			






//classement par salle
if($classement=="salle")
{
$sql="SELECT *,  enseignements.nom as nom_enseignement, seances.presentiel,seances.dureeSeance as seanceDuree, seances.commentaire as seancesCommentaire, enseignements.commentaire as commentaire_enseignement, enseignements.diffusionCommentaire as diffusion_commentaire  FROM seances LEFT JOIN (enseignements) ON (seances.codeEnseignement=enseignements.codeEnseignement) LEFT JOIN (seances_salles) ON (seances_salles.codeSeance=seances.codeSeance)  LEFT JOIN (ressources_salles) ON (seances_salles.codeRessource=ressources_salles.codeSalle)   WHERE  ressources_salles.deleted='0'  and  seances_salles.deleted='0' and seances.deleted='0' and seances.codeSeance!=''  AND enseignements.deleted='0' and enseignements.nom like :nom_module order by  ressources_salles.nom,seances.dateSeance,seances.heureSeance ";	
}


//classement par prof
elseif($classement=="prof")
{
$sql="SELECT *, enseignements.nom as nom_enseignement, seances.presentiel,seances.dureeSeance as seanceDuree, seances.commentaire as seancesCommentaire, enseignements.commentaire as commentaire_enseignement, enseignements.diffusionCommentaire as diffusion_commentaire  FROM seances LEFT JOIN (enseignements) ON (seances.codeEnseignement=enseignements.codeEnseignement) LEFT JOIN (seances_profs) ON (seances_profs.codeSeance=seances.codeSeance)  LEFT JOIN (ressources_profs) ON (seances_profs.codeRessource=ressources_profs.codeProf)   WHERE  ressources_profs.deleted='0' and  seances_profs.deleted='0' and  seances.deleted='0' and seances.codeSeance!=''  AND enseignements.deleted='0' and enseignements.nom like :nom_module order by  ressources_profs.nom,seances.dateSeance,seances.heureSeance ";	
}

//classement par groupe
elseif($classement=="groupe")
{
$sql="SELECT *,  enseignements.nom as nom_enseignement, seances.presentiel,seances.dureeSeance as seanceDuree, seances.commentaire as seancesCommentaire, enseignements.commentaire as commentaire_enseignement, enseignements.diffusionCommentaire as diffusion_commentaire  FROM seances LEFT JOIN (enseignements) ON (seances.codeEnseignement=enseignements.codeEnseignement) LEFT JOIN (seances_groupes) ON (seances_groupes.codeSeance=seances.codeSeance)  LEFT JOIN (ressources_groupes) ON (seances_groupes.codeRessource=ressources_groupes.codeGroupe)  WHERE  ressources_groupes.deleted='0' and  seances_groupes.deleted='0' and seances.deleted='0' and seances.codeSeance!=''  AND enseignements.deleted='0' and enseignements.nom like :nom_module order by  ressources_groupes.nom,seances.dateSeance,seances.heureSeance ";	
}

//classement par type
elseif ($classement=="type")
{
$sql="SELECT *,  enseignements.nom as nom_enseignement, seances.presentiel,seances.dureeSeance as seanceDuree, seances.commentaire as seancesCommentaire, enseignements.commentaire as commentaire_enseignement, enseignements.diffusionCommentaire as diffusion_commentaire  FROM seances LEFT JOIN (enseignements) ON (seances.codeEnseignement=enseignements.codeEnseignement)   where seances.deleted='0' and seances.codeSeance!=''  AND enseignements.deleted='0' and enseignements.nom like :nom_module order by enseignements.codeTypeActivite,seances.dateSeance,seances.heureSeance ";	
}

//classement par ordre chronomogique
else
{
$sql="SELECT *,  enseignements.nom as nom_enseignement, seances.presentiel,seances.dureeSeance as seanceDuree, seances.commentaire as seancesCommentaire, enseignements.commentaire as commentaire_enseignement, enseignements.diffusionCommentaire as diffusion_commentaire  FROM seances LEFT JOIN (enseignements) ON (seances.codeEnseignement=enseignements.codeEnseignement)   where seances.deleted='0' and seances.codeSeance!=''  AND enseignements.deleted='0' and enseignements.nom like :nom_module order by seances.dateSeance,seances.heureSeance ";	
}

$req4=$dbh->prepare($sql);
$req4->execute(array(':nom_module'=>$nom_module."%"));
$res_4=$req4->fetchAll();
//preparation des requetes des boucles suiantes
$sql="SELECT * from seances_profs left join ressources_profs on (seances_profs.codeRessource=ressources_profs.codeProf) WHERE seances_profs.codeSeance=:code_seance and seances_profs.deleted='0' and ressources_profs.deleted='0' order by ressources_profs.nom"; 
$req5=$dbh->prepare($sql);
$sql="SELECT * from ressources_profs WHERE codeProf=:code_prof and deleted='0'"; 
$req6=$dbh->prepare($sql);			
$sql="SELECT * from seances_salles left join ressources_salles on (seances_salles.codeRessource=ressources_salles.codeSalle)  WHERE seances_salles.codeSeance=:code_seance and seances_salles.deleted='0' and ressources_salles.deleted='0' order by ressources_salles.nom";
$req7=$dbh->prepare($sql);			
$sql="SELECT * from ressources_salles WHERE codeSalle=:code_salle and deleted='0'"; 
$req8=$dbh->prepare($sql);			
$sql="SELECT * from seances_groupes left join ressources_groupes on (seances_groupes.codeRessource=ressources_groupes.codeGroupe) WHERE seances_groupes.codeSeance=:code_seance and seances_groupes.deleted='0' and ressources_groupes.deleted='0' order by ressources_groupes.nom" ;
$req9=$dbh->prepare($sql);			
$sql="SELECT * from ressources_groupes WHERE codeGroupe=:code_groupe and deleted='0'";
$req10=$dbh->prepare($sql);	


//initialisation de la variable qui vérifie si on a déjà tracé le trait de séparation entre les sénaces passées et futures et si des séances passées existent
$trait_dessine="0";
$seance_passe_existe="0";
$cumul_en_min=0;

	foreach ($res_4 as $res4)	
    {
	//mise en forme de la date
		$annee=substr($res4['dateSeance'],0,4);
		$mois=substr($res4['dateSeance'],5,2);
		$jour=substr($res4['dateSeance'],8,2);
		$nom_jour=date("l", mktime(0, 0, 0, $mois, $jour, $annee));
		$semaine=date("W", mktime(0, 0, 0, $mois, $jour, $annee));
		//traduction francais du nom du jour
		if ($nom_jour=='Monday')
			{
			$nom_jour='Lundi';
			}
		if ($nom_jour=='Tuesday')
			{
			$nom_jour='Mardi';
			}
		if ($nom_jour=='Wednesday')
			{
			$nom_jour='Mercredi';
			}
		if ($nom_jour=='Thursday')
			{
			$nom_jour='Jeudi';
			}
		if ($nom_jour=='Friday')
			{
			$nom_jour='Vendredi';
			}
		if ($nom_jour=='Saturday')
			{
			$nom_jour='Samedi';
			}
		if ($nom_jour=='Sunday')
			{
			$nom_jour='Dimanche';
			}
			
			
		//commentaire séance

If ($res4['commentaire_enseignement']!="" && $res4['diffusion_commentaire']==1)	
{
	if ($res4['seancesCommentaire']!="")
	{
		
		
 $commentaire=$res4['commentaire_enseignement'].". ".$res4['seancesCommentaire'];	
	}
	else{
		$commentaire=$res4['commentaire_enseignement'];	
	}
 
 
}
else
{
	 $commentaire=$res4['seancesCommentaire'];	
}	
			
	// type de seance
	

	
	unset($req_type);
	$sql="SELECT * FROM types_activites WHERE codeTypeActivite=:type_activite" ;
	$req_type=$dbh->prepare($sql);	
	$req_type->execute(array(':type_activite'=>$res4['codeTypeActivite']));
	$res_types=$req_type->fetchAll();		
		      
		foreach($res_types as $res_type)
	{
	$nom_type_seance = $res_type['alias'];
	}	
	
	
	
	
	// enseignement
	$type=explode("_",$res4['nom_enseignement']);
	$enseignement=$type[1];
	
	//mise en forme de la duree des seances
		
	if (strlen($res4['seanceDuree'])==4)
		{
			$heureduree=substr($res4['seanceDuree'],0,2);
			$minduree=substr($res4['seanceDuree'],2,2);
		}
	if (strlen($res4['seanceDuree'])==3)
		{
			$heureduree=substr($res4['seanceDuree'],0,1);
			$minduree=substr($res4['seanceDuree'],1,2);

		}
	if (strlen($res4['seanceDuree'])==2)
		{
			$heureduree=0;
			$minduree=$res4['seanceDuree'];
		}
	if (strlen($heureduree)==1)
		{
			$heureduree="0".$heureduree;
		}	
	$duree=$heureduree."h".$minduree;
	$cumul_en_min=$heureduree*60+$minduree+$cumul_en_min;
	
	//mise en forme de l'heure de début des seances
		
	
				if (strlen($res4['heureSeance'])==4)
					{
						$heuredebut=substr($res4['heureSeance'],0,2);
						$mindebut=substr($res4['heureSeance'],2,2);
					}
				if (strlen($res4['heureSeance'])==3)
					{
						$heuredebut=substr($res4['heureSeance'],0,1);
						$mindebut=substr($res4['heureSeance'],1,2);

					}
				if (strlen($res4['heureSeance'])==2)
					{
						$heuredebut=0;
						$mindebut=$res4['heureSeance'];
					}
				if (strlen($heuredebut)==1)
					{
						$heuredebut="0".$heuredebut;
						
					}
	$heure=$heuredebut."h".$mindebut;	
	
	//recherche du prof associé à la seance
$code_seance=$res4['codeSeance'];
if($classement!="prof")
{
$req5->execute(array(':code_seance'=>$code_seance));
$res_5=$req5->fetchAll();
	
	$nom_prof="";
	$compteur_prof=1;
	foreach ($res_5 as $res5)
	{
	
	$code_prof=$res5['codeRessource'];
	$req6->execute(array(':code_prof'=>$code_prof));
$res_6=$req6->fetchAll();	
	
	foreach ($res_6 as $res6)

		{
		$nom=ucwords(mb_strtolower($res6['prenom'], 'UTF-8')) ;
	


		$nom_prof=$nom_prof.$nom." ".$res6['nom'];
			if(count($res_5)>$compteur_prof)
			{
			$nom_prof.=" / ";
			}
		$compteur_prof+=1;	
		}
	}
}
else
{

		$nom=ucwords(mb_strtolower($res4['prenom'], 'UTF-8')) ;


		$nom_prof=$nom." ".$res4['nom']." ";

}



	//recherche de la salle associée à la seance
if($classement!="salle")
{
	$nom_salle="";
	$compteur_salle=1;
$req7->execute(array(':code_seance'=>$code_seance));
$res_7=$req7->fetchAll();
	foreach ($res_7 as $res7)
	
	{
	$code_salle=$res7['codeRessource'];
	
$req8->execute(array(':code_salle'=>$code_salle));
$res_8=$req8->fetchAll();	
	
	
	
	foreach ($res_8 as $res8)
		{
		//$nom_salle=$nom_salle.$res8['nom']." ";
		$nom_salle=$nom_salle.$res8['nom'];
		if(count($res_7)>$compteur_salle)
		{
			$nom_salle.=" / ";
		}
			$compteur_salle+=1;
		}
	}
	
}
else
{
$nom_salle=$res4['nom'];
}	

	
//date du jour actuel pour tracer un trait de séparation entre les séances passées et les séances futures.
$date_actuelle=date('Y').date('m').date('d');
$date_seance=$annee.$mois.$jour;
	
		//recherche du groupe associée à la seance
		
if($classement!="groupe")
{
$req9->execute(array(':code_seance'=>$code_seance));
$res_9=$req9->fetchAll();	
	

	$nom_groupe="";
	$compteur_groupe=1;
	foreach ($res_9 as $res9)
	{
	$code_groupe=$res9['codeRessource'];

$req10->execute(array(':code_groupe'=>$code_groupe));
$res_10=$req10->fetchAll();	

	
	
	foreach ($res_10 as $res10)
		{
		//$nom_groupe=$nom_groupe.$res10['nom']." ";
		$nom_groupe=$nom_groupe.$res10['nom'];
		if(count($res_9)>$compteur_groupe)
		{
			$nom_groupe.=" / ";
		}
			$compteur_groupe+=1;
		}
	}
}
else
{
$nom_groupe=$res4['nom'];
}
	

	
	
//test si changement de prof pour tracer le trait bleu de séparation lors du classement par prof
if ($classement=="prof")
{
	if ($nom_prof_avant!=$nom_prof && $classement=="prof" && $nom_prof_avant!="")
	{

	$nom_prof_avant=$nom_prof;
	$cumul_en_min=$heureduree*60+$minduree;
	}
	else
	{
	$nom_prof_avant=$nom_prof;

	}	
}

//test si changement de groupe pour tracer le trait bleu de séparation lors du classement par groupe
if ($classement=="groupe")
{
	if ($nom_groupe_avant!=$nom_groupe && $classement=="groupe" && $nom_groupe_avant!="")
	{

	$nom_groupe_avant=$nom_groupe;
	$cumul_en_min=$heureduree*60+$minduree;
	}
	else
	{
	$nom_groupe_avant=$nom_groupe;

	}	
}
	
//test si changement de salle pour tracer le trait bleu de séparation lors du classement par salle
if ($classement=="salle")
{
	if ($nom_salle_avant!=$nom_salle && $classement=="salle" && $nom_salle_avant!="")
	{

	$nom_salle_avant=$nom_salle;
	$cumul_en_min=$heureduree*60+$minduree;
	}
	else
	{
	$nom_salle_avant=$nom_salle;

	}	
}
	
//test si changement de type pour tracer le trait bleu de séparation lors du classement par type
if ($classement=="type")
{
	if ($nom_type_seance_avant!=$nom_type_seance && $classement=="type" && $nom_type_seance_avant!="")
	{

	$nom_type_seance_avant=$nom_type_seance;
	$cumul_en_min=$heureduree*60+$minduree;
	}
	else
	{
	$nom_type_seance_avant=$nom_type_seance;

	}		
}


//mise en forme de la durée cumulé pour le classement des profs ou des groupes ou des types ou des salles
$cumul_heure=intval($cumul_en_min/60);
	$cumul_min=$cumul_en_min%60;
	if ($cumul_heure==0 and $cumul_min==0)
		{
		$cumul_heure="";
		$cumul_min="";
		}
	if (strlen($cumul_heure)==1)
		{
		$cumul_heure="0".$cumul_heure;
		}

	if (strlen($cumul_min)==1)
		{
		$cumul_min="0".$cumul_min;
		}	

//ajout des mot "presentiel", "distanciel" et "Hybride".
if ($res4['presentiel']==1 )
{
	$presentiel="Présentiel";
}
elseif ($res4['presentiel']==2)
{
	$presentiel="Distanciel";
}
elseif ($res4['presentiel']==3)
{
	$presentiel="Hybride";
}
else
{
	$presentiel="Non défini";
}

if ($date_actuelle>$date_seance)
{
	$effectue="X";
}	
else
{
	$effectue="";
}
	
	$fichier.=$nom_jour." ".$jour."-".$mois."-".$annee.";".$semaine.";".stripslashes($nom_groupe).";".stripslashes($nom_type_seance).";".stripslashes($enseignement).";".$nom_prof.";".$nom_salle.";".$commentaire.";".$heure.";".$duree.";".$presentiel.";".$effectue.";".$cumul_heure."h".$cumul_min."\n";


	

	}
	}	









$jour=date('d');

$mois=date('m');

$annee=date('y');
$heuredujour=date('H');
$minutedujour=date('i');
$nom_du_fichier=str_replace(' ', '_', $nom_du_module[1]);
	$nomfichier=$nom_du_fichier."_".$jour."_".$mois."_".$annee."-".$heuredujour."h".$minutedujour.".csv";

	
header('Content-Encoding: UTF-8');
header('Content-type: text/csv; charset=UTF-8');
header("Content-Disposition: attachment; filename=$nomfichier");
echo "\xEF\xBB\xBF"; 	
	
/*	
	header("Content-Type: application/csv-tab-delimited-table; charset=utf-8");
header("Content-disposition: filename=$nomfichier");

*/
echo $fichier;

